package test;

import agent.*;
import agent.behavior.schedule.*;
import environment.*;
import org.junit.jupiter.api.*;

import java.util.*;
import java.util.stream.*;

public class RequestSortStrategyTest {

    @Test
    void testPriority(){
        Coordinate c0 = new Coordinate(0,0);

        SlotRequest s1 = new SlotRequest(new AgentRepresentation(c0, c0, false, 980, 0,0));
        SlotRequest s2 = new SlotRequest(new AgentRepresentation(c0, c0, false, 880, 0,0));
        SlotRequest s3 = new SlotRequest(new AgentRepresentation(c0, c0, false, 780, 0,0));
        SlotRequest s4 = new SlotRequest(new AgentRepresentation(c0, c0, false, 580, 0,0));

        var requests = List.of(s1,s2,s3,s4);

        var strat = SlotRequestPriorityStrategies.lowestEnergy;

        var sorted = requests.stream().
                sorted(Comparator.comparing(o-> strat.getPriorityFor(o, null))).
                collect(Collectors.toList());

        Assertions.assertSame(s4, sorted.get(0));
    }
}
