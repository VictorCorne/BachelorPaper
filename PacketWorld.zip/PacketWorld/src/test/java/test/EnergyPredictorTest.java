package test;

import agent.behavior.learning.movement.*;
import agent.behavior.schedule.*;
import environment.*;
import org.junit.jupiter.api.*;

class EnergyPredictorTest {

    @Test
    void switchToScheduleTest(){
        AgentRepresentation notHeaded = new AgentRepresentation(new Coordinate(8,6), null, false, 785, 1, 19);
        AgentRepresentation headed = new AgentRepresentation(new Coordinate(8,6),  new Coordinate(7,7), false, 785, 1, 19);

//        EnergyPredictor.getExpectedTurnSwitchToSchedule(notHeaded,);
    }

}