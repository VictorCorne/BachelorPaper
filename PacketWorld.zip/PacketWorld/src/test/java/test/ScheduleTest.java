package test;

import agent.*;
import agent.behavior.managingSystem.communicationStrategy.informationSharing.*;
import agent.behavior.schedule.*;
import environment.*;
import org.junit.jupiter.api.*;
import util.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class ScheduleTest {
    // ATTRIBUTES

    Schedule testSched;

    TimeSlot schedItem;

    @BeforeEach
    void setUp() throws ScheduleNotFreeException{
        testSched = createTestSched();

        schedItem = new TimeSlot(10,15);
    }

    // UTILITY METHODS

    private void testNullInRange(int fromTurn, int toTurn){
        for (int i = fromTurn; i <= toTurn; i++){
            assertNull(testSched.getItemAtTurnNb(i));
        }
    }

    private void testSameInRange(int fromTurn, int toTurn) {
        testSameInRange(fromTurn, toTurn, testSched);
    }

    private void testSameInRange(int fromTurn, int toTurn, Schedule schedule){
        for (int i = fromTurn; i <= toTurn ; i++) {
            assertEquals(new TimeSlot(fromTurn, toTurn), schedule.getItemAtTurnNb(i));
        }
    }

    private void regenSchedule(){
        testSched = createTestSched();
    }

    private Schedule createTestSched() {
        Schedule schedule = new Schedule();

        try{
            schedule.addScheduledItem(new TimeSlot(2,3));
            schedule.addScheduledItem(new TimeSlot(4,4));
            schedule.addScheduledItem(new TimeSlot(5,5));
            schedule.addScheduledItem(new TimeSlot(7,10));
            schedule.addScheduledItem(new TimeSlot(17,20));
            schedule.addScheduledItem(new TimeSlot(21,25));
            schedule.addScheduledItem(new TimeSlot(30,35));

            return schedule;
        } catch (ScheduleNotFreeException e) {
            fail();
        }
        fail();
        return null;
    }


    // FREE SLOTS TEST

    @Test
    void testFreeSlotsCloseSchedule() throws ScheduleNotFreeException {
        Schedule schedule = new Schedule();
        schedule.addScheduledItem(new TimeSlot(123,132));
        schedule.addScheduledItem(new TimeSlot(133,142));
        schedule.update(80);

        for (int len = 1; len < 5; len++)
            for (int i = 123; i < 143; i++) assertEquals(143, schedule.getStartOfFirstSlotOfSizeAvailable(len, i));

        var free = schedule.getAllFreeSlots(100,160);
        assertTrue(free.contains(new TimeSlot(100,122)));
        assertTrue(free.contains(new TimeSlot(143,160)));
        assertEquals(2, free.size());
    }

    @Test
    void getAllFreeSlots() {
        for(int begin = 0; begin < 50; begin++)
            for (int end = 0; end < 50; end++)
                if (begin < end){
                    List<TimeSlot> res = testSched.getAllFreeSlots(begin, end);
                    for (TimeSlot item : res)
                        assertTrue(testSched.isFreeSlot(item.getFromTurn(), item.getToTurn()));
                }
        List<TimeSlot> res = testSched.getAllFreeSlots(4,17);
        for (int begin = 2; begin < 6; begin++)
            for (int end = 16; end < 25; end++) assertEquals(res, testSched.getAllFreeSlots(begin, end));

        assertTrue(res.contains(new TimeSlot(6,6)));
        assertTrue(res.contains(new TimeSlot(11,16)));
    }

    @Test
    void testStartOfFreeSlot() {
        for (int i = 2; i < 6; i++) assertEquals(testSched.getStartOfFirstSlotOfSizeAvailable(1, i), 6);

        for (int size = 1; size < 6; size++)
            for (int start = 7; start < 11; start++) assertEquals(testSched.getStartOfFirstSlotOfSizeAvailable(size, start), 11);
    }

    @Test
    void isFreeSlot() {
        assertFalse(testSched.isFreeSlot(5));
        assertTrue(testSched.isFreeSlot(6));
        assertFalse(testSched.isFreeSlot(7));
        assertFalse(testSched.isFreeSlot(8));
        assertFalse(testSched.isFreeSlot(9));
        assertFalse(testSched.isFreeSlot(10));
        assertTrue(testSched.isFreeSlot(11));
        assertTrue(testSched.isFreeSlot(12));

        assertFalse(testSched.isFreeSlot(1,5));
        assertFalse(testSched.isFreeSlot(5,5));
        assertFalse(testSched.isFreeSlot(7,5));
        assertTrue(testSched.isFreeSlot(6,6));
        assertTrue(testSched.isFreeSlot(11,16));
        assertTrue(testSched.isFreeSlot(16,11));
        assertFalse(testSched.isFreeSlot(5,7));
    }

    @Test
    void getSchedulableSlotsTest() throws ScheduleNotFreeException {
        Schedule newSched = new Schedule();

        for (int i = 19; i <= 23; i++) {
            assertEquals(newSched.getSchedulableSlots(5, 0,i).size(), 4);
            assertEquals(newSched.getSchedulableSlots(5, 0,i).get(3), new TimeSlot(15,19));
        }

        int i = 24;
        assertNotEquals(newSched.getSchedulableSlots(5, 0,i).size(), 4);
        assertEquals(newSched.getSchedulableSlots(5, 0,i).get(3), new TimeSlot(15,19));

        // add obstacle
        newSched.addScheduledItem(new TimeSlot(43,53));
        assertTrue(newSched.getSchedulableSlots(0,0,100).isEmpty());
        var slots = newSched.getSchedulableSlots(10, 25,77);
        assertEquals(2, slots.size());
        assertEquals(new TimeSlot(30,39), slots.get(0));
        assertEquals(new TimeSlot(60,69), slots.get(1));
    }

    // GAP SIZE TEST

    @Test
    void getFreeSlotSizeAfterItem() {
        assertEquals(testSched.getSizeOfFreeSpaceAfterTurn(2), 0);
        assertEquals(testSched.getSizeOfFreeSpaceAfterTurn(3), 0);
        assertEquals(testSched.getSizeOfFreeSpaceAfterTurn(4), 0);
        assertEquals(testSched.getSizeOfFreeSpaceAfterTurn(5), 1);
        assertEquals(testSched.getSizeOfFreeSpaceAfterTurn(6), 1);
        assertEquals(testSched.getSizeOfFreeSpaceAfterTurn(7), 6);
        assertEquals(testSched.getSizeOfFreeSpaceAfterTurn(8), 6);
        assertEquals(testSched.getSizeOfFreeSpaceAfterTurn(9), 6);
    }

    @Test
    void freeSizeAfterItemTest(){
        for (int i = 2; i <= 4; i++) assertEquals(testSched.getSizeOfFreeSpaceAfterTurn(i), 0);
        assertNull(testSched.getItemAtTurnNb(0));
    }

    @Test
    void getFreeSlotSizeAfterTurn() {
        // Before an item
        assertEquals(5,testSched.getSizeOfFreeSpaceAfterTurn(-3));
        assertEquals(4,testSched.getSizeOfFreeSpaceAfterTurn(-2));
        assertEquals(3,testSched.getSizeOfFreeSpaceAfterTurn(-1));
        assertEquals(2,testSched.getSizeOfFreeSpaceAfterTurn(0));
        assertEquals(1,testSched.getSizeOfFreeSpaceAfterTurn(1));

        // On a non-free spot
        assertEquals(0,testSched.getSizeOfFreeSpaceAfterTurn(2));
        assertEquals(0,testSched.getSizeOfFreeSpaceAfterTurn(3));
        assertEquals(1,testSched.getSizeOfFreeSpaceAfterTurn(5));

        // On a free spot
        assertEquals(1,testSched.getSizeOfFreeSpaceAfterTurn(6));

        // On another spot
        assertEquals(6,testSched.getSizeOfFreeSpaceAfterTurn(7));
        assertEquals(6,testSched.getSizeOfFreeSpaceAfterTurn(8));
        assertEquals(6,testSched.getSizeOfFreeSpaceAfterTurn(10));

        // On a free spot
        assertEquals(5,testSched.getSizeOfFreeSpaceAfterTurn(12));
        assertEquals(4,testSched.getSizeOfFreeSpaceAfterTurn(13));
        assertEquals(3,testSched.getSizeOfFreeSpaceAfterTurn(14));

        // On an infinite spot
        assertEquals(Integer.MAX_VALUE, testSched.getSizeOfFreeSpaceAfterTurn(30));
        assertEquals(Integer.MAX_VALUE, testSched.getSizeOfFreeSpaceAfterTurn(35));
        assertTrue(testSched.getSizeOfFreeSpaceAfterTurn(300) > Integer.MAX_VALUE - 1000);
    }

    @Test
    void getStartOfFirstSlotOfSizeAvailable() {
        assertEquals(0,testSched.getStartOfFirstSlotOfSizeAvailable(1));
        assertEquals(0,testSched.getStartOfFirstSlotOfSizeAvailable(2));

        assertEquals(11,testSched.getStartOfFirstSlotOfSizeAvailable(3));
        assertEquals(11,testSched.getStartOfFirstSlotOfSizeAvailable(6));

        // Advance the schedule
        testSched.update(14);

        assertEquals(14,testSched.getStartOfFirstSlotOfSizeAvailable(1));
        assertEquals(14,testSched.getStartOfFirstSlotOfSizeAvailable(2));
        assertEquals(14,testSched.getStartOfFirstSlotOfSizeAvailable(3));
        assertEquals(26,testSched.getStartOfFirstSlotOfSizeAvailable(4));

        assertEquals(36,testSched.getStartOfFirstSlotOfSizeAvailable(5));
        assertEquals(36,testSched.getStartOfFirstSlotOfSizeAvailable(50));
    }

    // FINDING ITEMS

    @Test
    void itemAtTest() {
        for (int j = 2; j <= 3; j++) assertEquals(testSched.getItemAtTurnNb(j), testSched.getScheduledItems().get(0));
        assertEquals(testSched.getItemAtTurnNb(4), testSched.getScheduledItems().get(1));
        assertEquals(testSched.getItemAtTurnNb(5), testSched.getScheduledItems().get(2));
        for (int i = 7; i <= 10; i++) assertEquals(testSched.getItemAtTurnNb(i), testSched.getScheduledItems().get(3));
        for (int i = 17; i <= 20; i++) assertEquals(testSched.getItemAtTurnNb(i), testSched.getScheduledItems().get(4));
        for (int i = 21; i <= 25; i++) assertEquals(testSched.getItemAtTurnNb(i), testSched.getScheduledItems().get(5));
        for (int i = 30; i <= 35; i++) assertEquals(testSched.getItemAtTurnNb(i), testSched.getScheduledItems().get(6));
    }

    @Test
    void isInTurnTest() {
        TimeSlot obj = new TimeSlot(5,8);
        assertFalse(obj.isTurnInSlot(3));
        assertFalse(obj.isTurnInSlot(4));
        assertTrue(obj.isTurnInSlot(5));
        assertTrue(obj.isTurnInSlot(6));
        assertTrue(obj.isTurnInSlot(7));
        assertTrue(obj.isTurnInSlot(8));
        assertFalse(obj.isTurnInSlot(9));
        assertFalse(obj.isTurnInSlot(10));
    }

    @Test
    void testGetStartOfFirstSlotOfSizeAvailable(){
        for (int j = 2; j < 6; j++)
            assertEquals(6, testSched.getStartOfFirstSlotOfSizeAvailable(1, j));

        for (int i = 2; i <= 11; i++)
            assertEquals(11, testSched.getStartOfFirstSlotOfSizeAvailable(2, i));

        for (int i = 2; i < 36; i++)
            assertEquals(36, testSched.getStartOfFirstSlotOfSizeAvailable(8, i));

        for (int size = 1; size < 5; size++)
            for (int i = 40; i < 50; i++)
                assertEquals(i, testSched.getStartOfFirstSlotOfSizeAvailable(size, i));
    }

    @Test
    void getSlotsDuringTest(){
        for (var slot : testSched.getScheduledItems()) {
            assertEquals(1, testSched.getTimeSlotsDuring(slot).size());
        }

        var slotsDuring = testSched.getTimeSlotsDuring(new TimeSlot(5,18));
        assertEquals(3, slotsDuring.size());
        assertEquals(testSched.getItemAtTurnNb(5), slotsDuring.get(0));
        assertEquals(testSched.getItemAtTurnNb(7), slotsDuring.get(1));
        assertEquals(testSched.getItemAtTurnNb(10), slotsDuring.get(1));
        assertEquals(testSched.getItemAtTurnNb(20), slotsDuring.get(2));

        slotsDuring = testSched.getTimeSlotsDuring(new TimeSlot(12,12));
        assertTrue(slotsDuring.isEmpty());
    }

    // ADVANCING SCHEDULE

    @Test
    void advanceScheduleToTime() {
        int totalBeginItems = testSched.getScheduledItems().size();
        assertEquals(totalBeginItems,7);
        testSched.update(0);
        assertEquals(7, testSched.getScheduledItems().size());
        testSched.update(2);
        assertEquals(7, testSched.getScheduledItems().size());
        testSched.update(5);
        assertEquals(5, testSched.getScheduledItems().size());

        testSched.update(6);
        assertEquals(4, testSched.getScheduledItems().size());
        testSched.update(6);
        assertEquals(4, testSched.getScheduledItems().size());

        testSched.update(7);
        assertEquals(4, testSched.getScheduledItems().size());
        testSched.update(10);
        assertEquals(4, testSched.getScheduledItems().size());

        testSched.update(11);
        assertEquals(3, testSched.getScheduledItems().size());
        testSched.update(16);
        assertEquals(3, testSched.getScheduledItems().size());
        testSched.update(18);
        assertEquals(3, testSched.getScheduledItems().size());
        testSched.update(25);
        assertEquals(2, testSched.getScheduledItems().size());

        testSched.update(28);
        assertEquals(1, testSched.getScheduledItems().size());
        testSched.update(30);
        assertEquals(1, testSched.getScheduledItems().size());
        testSched.update(35);
        assertEquals(1, testSched.getScheduledItems().size());

        testSched.update(40);
        assertEquals(0, testSched.getScheduledItems().size());
        testSched.update(110);
        assertEquals(0, testSched.getScheduledItems().size());

    }

    // ADDING ITEMS

    @Test
    void addScheduledItem() {
        assertDoesNotThrow(()->testSched.addScheduledItem(new TimeSlot(6,6)));
        assertDoesNotThrow(()->testSched.addScheduledItem(new TimeSlot(11,12)));
        assertDoesNotThrow(()->testSched.addScheduledItem(new TimeSlot(13,15)));

        assertThrows(ScheduleNotFreeException.class, ()->testSched.addScheduledItem(new TimeSlot(10,100)));
        assertThrows(ScheduleNotFreeException.class, ()->testSched.addScheduledItem(new TimeSlot(2,5)));
        assertThrows(ScheduleNotFreeException.class, ()->testSched.addScheduledItem(new TimeSlot(11,12)));
        assertThrows(ScheduleNotFreeException.class, ()->testSched.addScheduledItem(new TimeSlot(35,36)));
    }

    // ADDING SLOT WITH PRIORITY

    @Test
    void addSlotWithPriority_back() {
        // add in back of existing
        testSched.insertWithEqualPriority(new TimeSlot(9, 12));
        assertEquals(new TimeSlot(7,9), testSched.getItemAtTurnNb(7));
        assertEquals(new TimeSlot(10,12), testSched.getItemAtTurnNb(10));
    }

    @Test
    void addSlotWithPriority_front() throws ScheduleNotFreeException {
        // add in front of existing
        var schedule = createTestSched();
        var toAdd = new TimeSlot(15,18);
        schedule.insertWithEqualPriority(toAdd);
        assertEquals(new TimeSlot(15,17), schedule.getItemAtTurnNb(15));
        assertEquals(new TimeSlot(18,20), schedule.getItemAtTurnNb(18));
    }

    @Test
    void addSlotWithPriority_adjacent(){
        var toAdd = new TimeSlot(18,24);
        testSched.insertWithEqualPriority(toAdd);
        int x = testSched.getItemAtTurnNb(17).getToTurn();
        assertTrue( x == 18 || x == 19);
        assertTrue(toAdd.getFromTurn() == 19 || toAdd.getFromTurn() == 20);
        assertTrue(toAdd.getToTurn() == 22 || toAdd.getToTurn() == 23);
        x = testSched.getItemAtTurnNb(25).getFromTurn();
        assertTrue(x == 23 || x == 24);
        assertEquals(25, testSched.getItemAtTurnNb(25).getToTurn());
    }

    @Test
    void addSlotWithPriority_between(){
        var toAdd = new TimeSlot(9,18);
        testSched.insertWithEqualPriority(toAdd);
        assertEquals(new TimeSlot(7,9), testSched.getItemAtTurnNb(9));
        assertEquals(new TimeSlot(10,17), testSched.getItemAtTurnNb(10));
        assertEquals(new TimeSlot(18,20), testSched.getItemAtTurnNb(18));
    }

    @Test
    void addSlotWithPriority_differentPrio() throws ScheduleNotFreeException {
        var test = createTestSched();
        test.insertWithRelativePriority(new TimeSlot(8, 19), 0);
        assertEquals(new TimeSlot(11,16), test.getItemAtTurnNb(13));

        // Add slot with lower prio
        var newSched = createTestSched();
        var toAdd = new TimeSlot(8,19);
        int sizeBefore = toAdd.getDuration();
        newSched.insertWithRelativePriority(toAdd, 0.5d);
        assertTrue(newSched.getOverLappingSlots(toAdd).size() == 1 && newSched.getOverLappingSlots(toAdd).get(0).equals(toAdd));
        assertNotEquals(sizeBefore, toAdd.getDuration());
        assertEquals(new TimeSlot(10,17), newSched.getItemAtTurnNb(15));

        // Add slot with big prio
        newSched = createTestSched();
        toAdd = new TimeSlot(8,19);
        sizeBefore = toAdd.getDuration();
        newSched.insertWithRelativePriority(toAdd, 1.5d);
        assertTrue(newSched.getOverLappingSlots(toAdd).size() == 1 && newSched.getOverLappingSlots(toAdd).get(0).equals(toAdd));
        assertNotEquals(sizeBefore, toAdd.getDuration());
        assertEquals(new TimeSlot(9,18), newSched.getItemAtTurnNb(15));
    }

    @Test
    void addSlotWithPriorityTest_differentCalls() throws ScheduleNotFreeException {
        // add by indicating new slot
        var schedule = createTestSched();
        var toAdd = new TimeSlot(9,12);
        schedule.insertWithPriority(
                new Pair<>(toAdd, 10d),
                new HashMap<>(){{put(new TimeSlot(7,10), 10d);}}
        );
        assertEquals(new TimeSlot(7,9), schedule.getItemAtTurnNb(7));
        assertEquals(new TimeSlot(10,12), schedule.getItemAtTurnNb(10));

        // add by indicating overlap
        schedule = createTestSched();
        var overlaps = schedule.getOverLappingSlots(toAdd);
        schedule.insertWithPriority(
                new Pair<>(toAdd, 10d),
                new HashMap<>(){{put(overlaps.get(0), 10d);}}
        );
        assertEquals(new TimeSlot(7,9), schedule.getItemAtTurnNb(7));
        assertEquals(new TimeSlot(10,12), schedule.getItemAtTurnNb(10));

        // add by getting slot
        schedule = createTestSched();
        var slot = schedule.getItemAtTurnNb(10);
        schedule.insertWithPriority(
                new Pair<>(toAdd, 10d),
                new HashMap<>(){{put(slot, 10d);}}
        );
        assertEquals(new TimeSlot(7,9), schedule.getItemAtTurnNb(7));
        assertEquals(new TimeSlot(10,12), schedule.getItemAtTurnNb(10));
    }

    @Test
    void forceAddSlotTest(){
        int expectedSize = testSched.getScheduledItems().size();
        assertEquals(7, expectedSize);
        // add slot that does not delete any other
        testSched.forceAddSlot(new TimeSlot(1,2));
        expectedSize += 1;
        assertEquals(expectedSize, testSched.getScheduledItems().size());
        assertEquals(new TimeSlot(1,2), testSched.getItemAtTurnNb(1));
        assertEquals(new TimeSlot(3,3), testSched.getItemAtTurnNb(3));

        // add slot that deletes two slots
        testSched.forceAddSlot(new TimeSlot(3,5));
        expectedSize += 1 - 3;
        assertEquals(testSched.getScheduledItems().size(), expectedSize);

        // Add slot that reduces the size of two other slots
        testSched.forceAddSlot(new TimeSlot(9,17));
        expectedSize += 1;
        assertEquals(testSched.getScheduledItems().size(), expectedSize);
        assertEquals(new TimeSlot(9,17), testSched.getItemAtTurnNb(13));
        assertEquals(new TimeSlot(7,8), testSched.getItemAtTurnNb(8));
        assertEquals(new TimeSlot(18,20), testSched.getItemAtTurnNb(20));

        testSched.forceAddSlot(new TimeSlot(19,22));
        expectedSize+=1;
        assertEquals(testSched.getScheduledItems().size(), expectedSize);
        assertEquals(new TimeSlot(19,22), testSched.getItemAtTurnNb(19));
        assertEquals(new TimeSlot(23,25), testSched.getItemAtTurnNb(23));
        assertEquals(new TimeSlot(18,18), testSched.getItemAtTurnNb(18));
    }

    // ADDING SLOT WITH RULES

    @Test
    void addWithRulesTest_normalCase(){
        int itemsBefore = testSched.getNbReservations();
        var add = new TimeSlot(9,31);
        testSched.addSlotWithRules(add, o->o.getFromTurn() < 25, o->o.getDuration() <=2);
        assertEquals(testSched.getNbReservations(), itemsBefore - 3 + 1);
        for (int i = 6; i <= 8; i++) assertNull(testSched.getItemAtTurnNb(i));
        for (int i = 9; i <= 29; i++) assertEquals(testSched.getItemAtTurnNb(i), add);
        for (int i = 30; i <= 35; i++) assertEquals(testSched.getItemAtTurnNb(i), new TimeSlot(30, 35));
    }

    @Test
    void addWithRulesTest_illegalCase(){
        testSched.addSlotWithRules(new TimeSlot(6,10), o-> false, o->false);
        assertEquals(testSched.getItemAtTurnNb(6), new TimeSlot(6,6));
        for (int i = 7; i <= 10 ; i++) assertEquals(testSched.getItemAtTurnNb(i), new TimeSlot(7, 10));

        regenSchedule();
        testSched.addSlotWithRules(new TimeSlot(6,10), o-> false, o->true);
        assertEquals(testSched.getItemAtTurnNb(6), new TimeSlot(6,6));
        for (int i = 7; i <= 10 ; i++) assertEquals(testSched.getItemAtTurnNb(i), new TimeSlot(7, 10));

        regenSchedule();
        testSched.addSlotWithRules(new TimeSlot(6,10), o-> false, o->o.getDuration() <= 2);
        assertEquals(testSched.getItemAtTurnNb(6), new TimeSlot(6,6));
        for (int i = 7; i <= 10 ; i++) assertEquals(testSched.getItemAtTurnNb(i), new TimeSlot(7, 10));

        regenSchedule();
        testSched.addSlotWithRules(new TimeSlot(6,11), o-> false, o->false);
        assertNull(testSched.getItemAtTurnNb(6));
        assertNull(testSched.getItemAtTurnNb(11));
        for (int i = 7; i <= 10 ; i++) assertEquals(testSched.getItemAtTurnNb(i), new TimeSlot(7, 10));

        regenSchedule();
        testSched.addSlotWithRules(new TimeSlot(6,10, null, new Coordinate(10,100)), o->true, o->false);
        for (int i = 6; i <= 10 ; i++) assertEquals(testSched.getItemAtTurnNb(i), new TimeSlot(6, 10, null, new Coordinate(10,100)));
    }

    @Test
    void addSlotWithRulesTest_inBetween(){
        testSched.addSlotWithRules(new TimeSlot(19,22), o-> false, o->false);
        for (int i = 17; i <= 20 ; i++) assertEquals(testSched.getItemAtTurnNb(i), new TimeSlot(17, 20));
        for (int i = 21; i <= 25 ; i++) assertEquals(testSched.getItemAtTurnNb(i), new TimeSlot(21, 25));

        regenSchedule();
        testSched.addSlotWithRules(new TimeSlot(19,22), o -> o.getFromTurn() <= 20, o->o.getDuration() <= 2);
        testNullInRange(16,18);
        testSameInRange(19,20);
        testSameInRange(21,25);
    }

    @Test
    void addSlotWithRulesTest_realExample() throws ScheduleNotFreeException {
        Schedule schedule = new Schedule();
        schedule.addSlotWithRules(new TimeSlot(305, 312), o->false, o->false);
        assertEquals(schedule.getNbReservations(), 1);
        schedule.addSlotWithRules(new TimeSlot(304, 312), o->true, o->false);
        assertEquals(schedule.getNbReservations(), 1);
        testSameInRange(304,312, schedule);
        assertTrue(Schedule.isValidSchedule(schedule));

        schedule.addScheduledItem(new TimeSlot(417,424));
        assertEquals(2, schedule.getNbReservations());
        schedule.addSlotWithRules(new TimeSlot(417,425), o->true, o->false);
        assertEquals(2, schedule.getNbReservations());
        testSameInRange(417,425,schedule);

        schedule.addScheduledItem(new TimeSlot(672,680));
        schedule.addSlotWithRules(new TimeSlot(669,673), o->false, o->false);
        assertTrue(Schedule.isValidSchedule(schedule));
    }

    @Test
    void addSlotWithRulesTransitivity(){
        AgentRepresentation a1 = new AgentRepresentation(new Coordinate(0,0), null, true, 750, 1, 5);
        AgentRepresentation a2 = new AgentRepresentation(new Coordinate(0,0), null, true, 750, 2, 7);
        AgentRepresentation a3 = new AgentRepresentation(new Coordinate(0,0), null, true, 700, 3, 5);
        AgentRepresentation a4 = new AgentRepresentation(new Coordinate(0,0), null, true, 750, 4, 5);

        List<TimeSlot> askers = new ArrayList<>(){{
            add(new TimeSlot(10,15, a1, new Coordinate(10,10)));
            add(new TimeSlot(10,15, a2, new Coordinate(10,10)));
            add(new TimeSlot(10,15, a3, new Coordinate(10,10)));
            add(new TimeSlot(10,15, a4, new Coordinate(10,10)));
        }};

        EnergySchedulingLogic logic = new EnergySchedulingLogic(List.of(new EnergyStationImp(0, 10,11)));
        InformationSharingBehavior is = new InformationSharingBehavior();
        is.setSlotPriorityComparator(InformationSharingFactory.priorityComparator);
        is.setEnergySchedulingLogic(logic);
        addAllToSchedule(is, askers);
        final int reservedTo = getAgentIDWhoHasSlot(is);

        final List<List<Integer>> permutationIndexes = new ArrayList<>(){{
            add(List.of(1,2,3,4));
            add(List.of(2,1,3,4));
            add(List.of(3,1,2,4));
            add(List.of(1,3,2,4));
            add(List.of(2,3,1,4));
            add(List.of(3,2,1,4));
            add(List.of(3,2,4,1));
            add(List.of(2,3,4,1));
            add(List.of(4,3,2,1));
            add(List.of(3,4,2,1));
            add(List.of(2,4,3,1));
            add(List.of(4,2,3,1));
            add(List.of(4,1,3,2));
            add(List.of(1,4,3,2));
            add(List.of(3,4,1,2));
            add(List.of(4,3,1,2));
            add(List.of(1,3,4,2));
            add(List.of(3,1,4,2));
            add(List.of(2,1,4,3));
            add(List.of(1,2,4,3));
            add(List.of(4,2,1,3));
            add(List.of(2,4,1,3));
            add(List.of(1,4,2,3));
            add(List.of(4,1,2,3));
        }};

        List<List<TimeSlot>> permutations = new ArrayList<>(){{
            add(List.of(askers.get(0).clone(), askers.get(1).clone(), askers.get(2).clone(), askers.get(3).clone()));
            add(List.of(askers.get(0).clone(), askers.get(1).clone(), askers.get(3).clone(), askers.get(2).clone()));
            add(List.of(askers.get(1).clone(), askers.get(2).clone(), askers.get(0).clone(), askers.get(3).clone()));
            add(List.of(askers.get(3).clone(), askers.get(1).clone(), askers.get(2).clone(), askers.get(0).clone()));
            add(List.of(askers.get(0).clone(), askers.get(1).clone(), askers.get(2).clone(), askers.get(3).clone()));
            add(List.of(askers.get(0).clone(), askers.get(2).clone(), askers.get(3).clone(), askers.get(1).clone()));
        }};

        for (List<Integer> i : permutationIndexes) {
          List<TimeSlot> slots = List.of(askers.get(i.get(0)-1).clone(),
                                         askers.get(i.get(1)-1).clone(),
                                         askers.get(i.get(2)-1).clone(),
                                         askers.get(i.get(3)-1).clone()
                                         );
            var n = generateISBehavior();
            addAllToSchedule(n, slots);
            assertEquals(reservedTo, getAgentIDWhoHasSlot(n));
        }
    }

    private int getAgentIDWhoHasSlot(InformationSharingBehavior isb){
        return isb.getPercievedSchedule().get(0).getScheduledItems().get(0).getAgentRepresentation().agentID;
    }

    private InformationSharingBehavior generateISBehavior(){
        InformationSharingBehavior n = new InformationSharingBehavior();
        n.setSlotPriorityComparator(InformationSharingFactory.priorityComparator);
        n.setEnergySchedulingLogic(new EnergySchedulingLogic(List.of(new EnergyStationImp(0, 10,11))));
        return n;
    }

    private void addAllToSchedule(InformationSharingBehavior behavior, List<TimeSlot> slots){
        slots.forEach(o->behavior.addSlotToSchedule(o));
    }

    @Test
    void testBug() throws ScheduleNotFreeException {
        Schedule schedule = new Schedule(){{
            addScheduledItem(new TimeSlot(311, 319));
            addScheduledItem(new TimeSlot(320, 322));
            addScheduledItem(new TimeSlot(323, 328));
            addScheduledItem(new TimeSlot(329, 331));
            addScheduledItem(new TimeSlot(347, 355));
            addScheduledItem(new TimeSlot(356, 364));
            addScheduledItem(new TimeSlot(365, 369));
        }};

        schedule.addSlotWithRules(new TimeSlot(358, 364), o->false, o->false);
        assertTrue(Schedule.isValidSchedule(schedule));
    }


    @Test
    void priorityTest(){
        Coordinate c = new Coordinate(0,0);

        // different timebound of slot
        var t1 = new TimeSlot(10,11, new AgentRepresentation(c,c, false, 800, 1, 5),c);
        var t2 = new TimeSlot(9,15, new AgentRepresentation(c,c, false, 800, 2, 5),c);
        assertEquals(-1, InformationSharingFactory.priorityComparator.compare(t1,t2));

        // Different turn asked
        t1 = new TimeSlot(10,15, new AgentRepresentation(c,c, false, 800, 1, 4),c);
        t2 = new TimeSlot(9,17, new AgentRepresentation(c,c, false, 800, 2, 5),c);
        assertEquals(1, InformationSharingFactory.priorityComparator.compare(t1,t2));

        // Slot 1 is too short
        t1 = new TimeSlot(10,15, new AgentRepresentation(c,c, false, 800, 1, 5),c);
        t2 = new TimeSlot(9,17, new AgentRepresentation(c,c, false, 800, 2, 5),c);
        assertEquals(-1, InformationSharingFactory.priorityComparator.compare(t1,t2));

        t1 = new TimeSlot(10,15, new AgentRepresentation(c,c, false, 800, 1, 5),c);
        t2 = new TimeSlot(9,17, new AgentRepresentation(c,c, false, 800, 2, 5),c);
        assertEquals(-1, InformationSharingFactory.priorityComparator.compare(t1,t2));

        // Slots are equal in everything except agent id, expect not 0
        t1 = new TimeSlot(10,15, new AgentRepresentation(c,c, false, 800, 1, 5),c);
        t2 = new TimeSlot(10,15, new AgentRepresentation(c,c, false, 800, 2, 5),c);
        assertNotEquals(0, InformationSharingFactory.priorityComparator.compare(t1,t2));
    }

    // SLOT COMPARISON

    @Test
    void ScheduleEndsTest() {
        assertTrue(schedItem.endsBefore(16));
        assertTrue(schedItem.endsBefore(160));

        assertFalse(schedItem.endsBefore(15));
        assertFalse(schedItem.endsBefore(10));

        assertFalse(schedItem.endsAfter(15));
        assertTrue(schedItem.endsAfter(10));

        assertFalse(schedItem.endsAfter(16));
        assertFalse(schedItem.endsAfter(160));
    }

    @Test
    void ScheduleStartTest() {
        assertTrue(schedItem.startsBefore(11));
        assertTrue(schedItem.startsBefore(13));
        assertTrue(schedItem.startsBefore(20));
        assertTrue(schedItem.startsBefore(200));

        assertFalse(schedItem.startsBefore(10));
        assertFalse(schedItem.startsBefore(9));
        assertFalse(schedItem.startsBefore(8));
        assertFalse(schedItem.startsBefore(0));
        assertFalse(schedItem.startsBefore(-10));

        assertFalse(schedItem.startsAfter(10));
        assertTrue(schedItem.startsAfter(9));
        assertTrue(schedItem.startsAfter(0));

        assertFalse(schedItem.startsAfter(11));
        assertFalse(schedItem.startsAfter(13));
        assertFalse(schedItem.startsAfter(1302));
    }
}