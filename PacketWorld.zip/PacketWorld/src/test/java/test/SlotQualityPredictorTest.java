package test;

import agent.*;
import agent.behavior.learning.slotRequest.*;
import agent.behavior.schedule.*;
import environment.*;
import org.junit.jupiter.api.*;

import java.util.*;

class SlotQualityPredictorTest {

    SlotQualityPredictor predictor = new SlotQualityPredictor();
    EnergySchedulingLogic schedulingLogic;

    @BeforeEach
    void init(){
        List<EnergyStationImp> energyStations = new ArrayList<>(){{
            add(new EnergyStationImp(0,10,10));
            add(new EnergyStationImp(0,10,20));
            add(new EnergyStationImp(0,30,10));
            add(new EnergyStationImp(0,30,20));
        }};
        schedulingLogic = new EnergySchedulingLogic(energyStations);
    }

    @Test
    void qualityTest(){
        AgentRepresentation repr = new AgentRepresentation(new Coordinate(30,20), null, false, 700, 1, 20);

        TimeSlot close = new TimeSlot(72,77,null, new Coordinate(30,9));
        TimeSlot farAway = new TimeSlot(72,77,null, new Coordinate(9,9));

        Assertions.assertTrue(predictor.getQualityOfSlot(repr, close) > predictor.getQualityOfSlot(repr, farAway));
    }

    @Test
    void schedulingLogicTest() {
        Coordinate headedTo;
        headedTo = null;
//        headedTo = new Coordinate(7,7);

        AgentRepresentation repr = new AgentRepresentation(new Coordinate(8,6), headedTo, false, 785, 1, 19);

//        schedulingLogic.reserveSlotForChargerAt(new Coordinate(30,9), new TimeSlot(24,29));

        var best = schedulingLogic.getBestSlot(repr);

    }

}