package test;

import environment.*;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.abs;
import static org.junit.jupiter.api.Assertions.*;

class CoordinateTest {

    @Test
    void testEquals() {
        Coordinate fst = new Coordinate(-20,0);
        Coordinate snd = new Coordinate(-20,0);
        Coordinate trd = new Coordinate(45,7);

        assertEquals(fst, snd);
        assertEquals(fst, fst);
        assertEquals(snd, fst);
        assertNotEquals(snd, trd);
        assertNotEquals(fst, trd);
    }

    @Test
    void minTest(){
        Coordinate me = new Coordinate(0,0);

        List<Coordinate> coords = new ArrayList<>();
        coords.add(new Coordinate(15,0));
        coords.add(new Coordinate(20,0));
        coords.add(new Coordinate(0,10));
        coords.add(new Coordinate(6,7));

        Coordinate min = me.minDistanceCoord(coords);
    }

    @Test
    void AltDirectionTest(){
        for (Coordinate cc : Coordinate.neighbors) {
            assertTrue(cc.alternateDirections(2).size() == 2);
            print("\nmain coord = " + cc.toString() + "\n");
            for (Coordinate c : cc.alternateDirections(2)) {
                print(c + "\n");
            }
        }

    }

    @Test
    void weightedDirTest(){
        Coordinate c = new Coordinate(-5,20);
        int strts = 0, diags = 0;
        int max = 100;
        for (int i = 0; i < max; i++) {
            Coordinate[] alt = c.getDirectionWeighted();
            if(alt[0].equals(new Coordinate(0,1)) && alt[1].equals(new Coordinate(-1,1))) strts++;
            if(alt[1].equals(new Coordinate(0,1)) && alt[0].equals(new Coordinate(-1,1))) diags++;
        }
        print((double)strts/max);
        print((double)diags/max);
    }

    @Test
    void AltVersions(){
        Coordinate c = new Coordinate(1,2);
        assertEquals(c.getStraightVersion(), new Coordinate(0,1));
        assertEquals(c.getDiagVersion(), new Coordinate(1,1));


        c = new Coordinate(-1,2);
        assertEquals(c.getStraightVersion(), new Coordinate(0,1));
        assertEquals(c.getDiagVersion(), new Coordinate(-1,1));

        c = new Coordinate(1,-2);
        assertEquals(c.getStraightVersion(), new Coordinate(0,-1));
        assertEquals(c.getDiagVersion(), new Coordinate(1,-1));

        c = new Coordinate(-1,-2);
        assertEquals(c.getStraightVersion(), new Coordinate(0,-1));
        assertEquals(c.getDiagVersion(), new Coordinate(-1,-1));


        c = new Coordinate(-1,1);
        assertEquals(c.getStraightVersion(), new Coordinate(-1,1));
        assertEquals(c.getDiagVersion(), new Coordinate(-1,1));

        c = new Coordinate(0,1);
        assertEquals(c.getStraightVersion(), new Coordinate(0,1));
        assertEquals(c.getDiagVersion(), new Coordinate(0,1));
    }

    @Test
    void scaleTest(){
        Coordinate c = new Coordinate(13,27);
        assertEquals(c.size(), 27);
        assertEquals(c.sized(20).size(),20);
        print(c.sized(20));
    }

    @Test
    void stepTowardsTest(){
        Coordinate c = new Coordinate(10,10);

        assertEquals(new Coordinate(11,10), c.stepTowards(new Coordinate(100,10)));
        assertEquals(new Coordinate(11,10), c.stepTowards(new Coordinate(1000,10)));
        assertEquals(new Coordinate(11,10), c.stepTowards(new Coordinate(11,10)));

        assertEquals(new Coordinate(10,10), c.stepTowards(new Coordinate(10,10)));

        assertEquals(new Coordinate(9,11), c.stepTowards(new Coordinate(0,11)));
        assertEquals(new Coordinate(9,11), c.stepTowards(new Coordinate(9,11)));
        assertEquals(new Coordinate(9,11), c.stepTowards(new Coordinate(-200,110)));
        assertEquals(new Coordinate(9,11), c.stepTowards(new Coordinate(4,1100)));
    }

    void print(Object o){
        //System.out.println(o);
        }
}