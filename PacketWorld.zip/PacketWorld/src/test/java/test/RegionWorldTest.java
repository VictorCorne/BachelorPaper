package test;

import environment.*;
import environment.world.region.*;
import org.junit.jupiter.api.*;

import java.util.*;
import java.util.stream.*;

import static org.junit.jupiter.api.Assertions.*;

class RegionWorldTest {
    /**
     * The rectangle world whose regions are perfectly cut out.
     * This world is divided into six cells of size 5x5
     */
    RegionWorld niceRectangleWorld;
    /**
     * A rectangleWorld whose rectangles are not of the same size.
     * There are 3 regions in x, 4 in y
     */
    RegionWorld botchedRectangleWorld;

    /**
     * The environment in which the test is situated.
     * It is a 10 x 15 sized environment
     */
    Environment environment;

    /**
     * The locations of all energy stations
     */
    List<Coordinate> energystationLocs;
    /**
     * The voronoi world that is created with the energystation locs
     */
    RegionWorld voronoiWorld;

    @BeforeEach
    public void setup() {
        environment = new Environment(10,15);

        niceRectangleWorld = new RegionWorld(environment, new RectangularRegionsStrategy(2, 3), List.of());
        botchedRectangleWorld = new RegionWorld(environment, new RectangularRegionsStrategy(3,4),List.of() );

        energystationLocs = new ArrayList<>();
        energystationLocs.add(new Coordinate(5,5));
        energystationLocs.add(new Coordinate(7,6));
        energystationLocs.add(new Coordinate(0,0));
        energystationLocs.add(new Coordinate(9,0));
        voronoiWorld = new RegionWorld(environment, new VoronoiRegionsStrategy(energystationLocs), List.of());
    }

    // TEST REGION COUNT

    @Test
    void correctRegionCountTest(){
        assertEquals(niceRectangleWorld.getRegions().size(), 6);
        assertEquals(botchedRectangleWorld.getRegions().size(), 12);
        assertEquals(voronoiWorld.getRegions().size(), 4);
    }

    @Test
    void correctTilesCountTestNice(){
        // All the regions of the nice rectangle world should contain only 25 tiles
        for (int i = 0; i < 6; i++) {
            assertEquals(niceRectangleWorld.getRegions().get(i).getCoordinates().size(), 5 * 5);
        }
        // Together they should cover the whole world
        int sum = niceRectangleWorld.getRegions().stream().flatMapToInt(region -> IntStream.of(region.getCoordinates().size())).sum();
        assertEquals(sum,10*15);
    }

    @Test
    void findRegionOfCoordinateNice() {
        Region bottomLeft = niceRectangleWorld.findRegionOfCoordinate(new Coordinate(0,0));
        // Assert that only the coordinates of the first region are in the first region
        for (Coordinate c : environment.getCoordinates()){
            if(c.getX()<5 && c.getY() < 5) assertSame(niceRectangleWorld.findRegionOfCoordinate(c), bottomLeft);
            else assertNotSame(niceRectangleWorld.findRegionOfCoordinate(c), bottomLeft);
        }

        Region topCenter = niceRectangleWorld.findRegionOfCoordinate(new Coordinate(6,6));
        // Assert that only the coordinates of the topCenter region are in the topCenter region
        for (Coordinate c : environment.getCoordinates()){
            if(c.getX()>=5 && c.getX() < 10 && c.getY() >= 5 && c.getY() < 10) assertSame(niceRectangleWorld.findRegionOfCoordinate(c), topCenter);
            else assertNotSame(niceRectangleWorld.findRegionOfCoordinate(c), topCenter);
        }
    }
}