package test;

import agent.behavior.schedule.*;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class TimeSlotTest {
    TimeSlot slot;

    TimeSlot slot2;
    TimeSlot slot3;
    TimeSlot slot4;

    @BeforeEach
    public void setup(){
        slot = new TimeSlot(0, 10);
        slot2 = new TimeSlot(15,20);
        slot3 = new TimeSlot(7,18);
        slot4 = new TimeSlot(2,5);
    }

    // SIZE CHANGE TEST

    @Test
    public void shortenedTest(){
        // disjunct slots
        assertEquals(slot.shortened(slot2), slot);
        assertEquals(slot2.shortened(slot), slot2);

        // enveloped slots
        assertEquals(slot4.shortened(slot), null);
        assertEquals(slot.shortened(slot4), null);
        assertEquals(slot.shortened(slot), null);

        assertEquals(new TimeSlot(16,20), slot2.shortened(new TimeSlot(10,15)));
        assertEquals(new TimeSlot(17,20), slot2.shortened(new TimeSlot(10,16)));
        assertEquals(new TimeSlot(18,20), slot2.shortened(new TimeSlot(10,17)));
        assertEquals(new TimeSlot(19,20), slot2.shortened(new TimeSlot(10,18)));
        assertEquals(new TimeSlot(20,20), slot2.shortened(new TimeSlot(10,19)));
        assertEquals(slot2.shortened(new TimeSlot(10,20)), null);

    }

    @Test
    public void changeSizeTest(){
        assertEquals(slot.augmentedSizeAtEnd(10), new TimeSlot(0, 20));
        assertEquals(slot.augmentedSizeAtBegin(5), new TimeSlot(-5, 10));

        assertEquals(slot.augmentedSizeAtBegin(0), slot);
        assertEquals(slot.augmentedSizeAtEnd(0), slot);

        for (int i = 0; i < 10; i++) {
            assertEquals(new TimeSlot(0,10-i), slot.augmentedSizeAtEnd(-i));
            assertEquals(new TimeSlot(0+i,10), slot.augmentedSizeAtBegin(-i));
        }

        assertEquals(new TimeSlot(0,0), slot.augmentedSizeAtEnd(-10));
        assertEquals(new TimeSlot(10,10), slot.augmentedSizeAtBegin(-10));

        assertEquals(null, slot.augmentedSizeAtEnd(-11));
        assertEquals(null, slot.augmentedSizeAtBegin(-11));

        assertEquals(slot.augmentedSizeAtEnd(-12), null);
        assertEquals(slot.augmentedSizeAtBegin(-12), null);
    }

    @Test
    public void addTest(){
        // reflexivity
        assertEquals(slot.added(slot), slot.added(slot));
        assertEquals(slot.added(slot2), slot2.added(slot));
        assertEquals(slot.added(slot3), slot3.added(slot));
        assertEquals(slot.added(slot4), slot4.added(slot));

        // add contained slot
        assertEquals(slot, slot.added(slot4));
        assertEquals(slot, slot4.added(slot));

        // add adjacent slot
        assertEquals(new TimeSlot(0,15), slot.added(new TimeSlot(11,15)));
        assertEquals(new TimeSlot(0,15), new TimeSlot(11,15).added(slot));

        // add non adjacent slots
        assertEquals(new TimeSlot(0,20), slot.added(slot2));
        assertEquals(new TimeSlot(0,20), slot2.added(slot));
    }

    // SPLITTING

    @Test
    public void splitTest_bigSlot(){
        var slot = new TimeSlot(0,99);
        assertEquals(slot.getToTurn(), 99);
        assertEquals(slot.getDuration(), 100);

        var fst = slot.splitted(.50).first;
        var snd = slot.splitted(.50).second;

        assertTrue(fst.disjunct(snd));
        assertEquals(50, fst.getDuration());
        assertEquals(snd.getDuration(), fst.getDuration());

        assertEquals(50, snd.getFromTurn());
        assertEquals(49, fst.getToTurn());

        fst = slot.splitted(.20).first;
        snd = slot.splitted(.20).second;
        assertTrue(fst.disjunct(snd));
        assertEquals(fst.getDuration(), 20);
        assertEquals(snd.getDuration(), 80);

        assertEquals(fst.getFromTurn(),0);
        assertEquals(snd.getFromTurn(),20);

        assertEquals(fst.getToTurn(),19);
        assertEquals(snd.getToTurn(),99);
    }

    @Test
    public void splitTest_smallSlot(){
        var slot = new TimeSlot(10,15);
        var fst = slot.splitted(.50).first;
        var snd = slot.splitted(.50).second;

        assertTrue(fst.disjunct(snd));
        assertEquals(3, fst.getDuration());
        assertEquals(snd.getDuration(), fst.getDuration());

        assertEquals(slot.getDuration(), 6);

        fst = slot.splitted(.20).first;
        snd = slot.splitted(.20).second;
        assertTrue(fst.disjunct(snd));
        assertTrue(fst.getDuration() == 1 || fst.getDuration() == 2);
    }

    @Test
    public void splitTest_edgeCase(){
        var slot = new TimeSlot(5,24);

        assertNull(slot.splitted(0.02).first);
        assertEquals(slot.splitted(0.02).second, slot);
        assertNull(slot.splitted(1-0.02).second);
        assertEquals(slot.splitted(1-0.02).first, slot);
    }

    // OVERLAPPING

    @Test
    public void overLapTest(){
        assertEquals(slot.getOverlappingSection(slot2), null);
        assertEquals(slot.getOverlappingSection(slot3), new TimeSlot(7, 10));
        assertEquals(slot.getOverlappingSection(slot), slot);
        assertEquals(new TimeSlot(4,4).getOverlappingSection(new TimeSlot(4,4)), new TimeSlot(4,4));
        assertEquals(new TimeSlot(4,40).getOverlappingSection(new TimeSlot(4,4)), new TimeSlot(4,4));
        assertEquals(new TimeSlot(4,4).getOverlappingSection(new TimeSlot(4,40)), new TimeSlot(4,4));
    }

    @Test
    public void fullyContainedTestEdgeCases(){
        assertTrue(slot.envelopsOther(new TimeSlot(0, 0)));
        assertTrue(slot.envelopsOther(new TimeSlot(5, 5)));
        assertTrue(slot.envelopsOther(new TimeSlot(10, 10)));
        assertTrue(slot.envelopsOther(new TimeSlot(0, 10)));

        assertTrue(slot2.isFullyContainedIn(slot2));
        assertTrue(slot2.isFullyContainedIn(new TimeSlot(slot2)));
        assertTrue(slot2.isFullyContainedIn(new TimeSlot(15,20)));
        assertTrue(slot2.isFullyContainedIn(new TimeSlot(15,21)));
        assertTrue(slot2.isFullyContainedIn(new TimeSlot(14,20)));
        assertTrue(slot2.isFullyContainedIn(new TimeSlot(14,21)));
    }

    @Test
    public void overlapsTestEdgeCases(){
        assertTrue(slot2.overlaps(new TimeSlot(new TimeSlot(15,15))));
        assertTrue(slot2.overlaps(new TimeSlot(new TimeSlot(20,20))));

        assertFalse(slot2.overlaps(new TimeSlot(new TimeSlot(21,50))));
        assertTrue(slot2.overlaps(new TimeSlot(new TimeSlot(19,50))));
        assertTrue(slot2.overlaps(new TimeSlot(new TimeSlot(20,50))));


        assertTrue(slot2.overlaps(new TimeSlot(new TimeSlot(15,15))));
        assertTrue(slot2.overlaps(new TimeSlot(new TimeSlot(20,20))));

        assertFalse(slot2.overlaps(new TimeSlot(new TimeSlot(21,50))));
        assertTrue(slot2.overlaps(new TimeSlot(new TimeSlot(19,50))));
        assertTrue(slot2.overlaps(new TimeSlot(new TimeSlot(20,50))));
    }

    @Test
    public void fullyContainedTestNormalCases(){
        assertFalse(slot.isFullyContainedIn(slot2));
        assertFalse(slot.isFullyContainedIn(slot3));
        assertFalse(slot.isFullyContainedIn(slot4));
        // containment is not always symmetrical
        assertFalse(slot2.isFullyContainedIn(slot));
        assertFalse(slot3.isFullyContainedIn(slot));
        assertTrue(slot4.isFullyContainedIn(slot));

        assertFalse(slot2.isFullyContainedIn(slot3));
        assertFalse(slot2.isFullyContainedIn(slot4));
        // containment is not always symmetrical
        assertFalse(slot3.isFullyContainedIn(slot2));
        assertFalse(slot4.isFullyContainedIn(slot2));

        assertFalse(slot3.isFullyContainedIn(slot4));
        // containment is not always symmetrical
        assertFalse(slot4.isFullyContainedIn(slot3));

        // containment is always reflexive
        assertTrue(slot.isFullyContainedIn(slot));
        assertTrue(slot2.isFullyContainedIn(slot2));
        assertTrue(slot3.isFullyContainedIn(slot3));
        assertTrue(slot4.isFullyContainedIn(slot4));
    }

    @Test
    public void overlapTestNormalCases(){
        assertFalse(slot.overlaps(slot2));
        assertTrue(slot.overlaps(slot3));
        assertTrue(slot.overlaps(slot4));
        // overlapping must be symmetrical
        assertFalse(slot2.overlaps(slot));
        assertTrue(slot3.overlaps(slot));
        assertTrue(slot4.overlaps(slot));

        assertTrue(slot2.overlaps(slot3));
        assertFalse(slot2.overlaps(slot4));
        // overlapping must be symmetrical
        assertTrue(slot3.overlaps(slot2));
        assertFalse(slot4.overlaps(slot2));

        assertFalse(slot3.overlaps(slot4));
        // overlapping must be symmetrical
        assertFalse(slot4.overlaps(slot3));

        // x.overlaps(x) must be true
        assertTrue(slot.overlaps(slot));
        assertTrue(slot2.overlaps(slot2));
        assertTrue(slot3.overlaps(slot3));
        assertTrue(slot4.overlaps(slot4));
    }

    @Test
    public void adjacentTest(){
        assertTrue(slot.isAdjacentTo(new TimeSlot(11,12)));
        assertTrue(new TimeSlot(11, 12).isAdjacentTo(slot));

        assertFalse(slot.isAdjacentTo(new TimeSlot(10,10)));
        assertFalse(new TimeSlot(10, 10).isAdjacentTo(slot));

        assertFalse(slot.isAdjacentTo(slot));

        assertFalse(new TimeSlot(0,5).isAdjacentTo(slot));
        assertFalse(slot.isAdjacentTo(new TimeSlot(0, 5)));

        assertFalse(new TimeSlot(9,10).isAdjacentTo(slot));
        assertFalse(slot.isAdjacentTo(new TimeSlot(9,10)));

        assertFalse(new TimeSlot(9,11).isAdjacentTo(slot));
        assertFalse(slot.isAdjacentTo(new TimeSlot(9,11)));
    }

    @Test
    public void subslotTest(){
        var slot = new TimeSlot(10,15);
        var subs = slot.getSubslots(o-> 3, o->3);
        assertEquals(4, subs.size());
        assertEquals(subs.get(3), new TimeSlot(13, 15));
    }

    @Test
    public void wouldSplitOtherTest(){
        assertFalse(slot.wouldSplitOtherInTwo(slot));
        assertFalse(slot.wouldSplitOtherInTwo(slot2));
        assertFalse(slot.wouldSplitOtherInTwo(slot3));
        assertFalse(slot.wouldSplitOtherInTwo(slot4));

        assertFalse(slot2.wouldSplitOtherInTwo(slot));
        assertFalse(slot2.wouldSplitOtherInTwo(slot2));
        assertFalse(slot2.wouldSplitOtherInTwo(slot3));
        assertFalse(slot2.wouldSplitOtherInTwo(slot4));

        assertFalse(slot3.wouldSplitOtherInTwo(slot));
        assertFalse(slot3.wouldSplitOtherInTwo(slot2));
        assertFalse(slot3.wouldSplitOtherInTwo(slot3));
        assertFalse(slot3.wouldSplitOtherInTwo(slot4));

        assertTrue(slot4.wouldSplitOtherInTwo(slot));
        assertFalse(slot4.wouldSplitOtherInTwo(slot2));
        assertFalse(slot4.wouldSplitOtherInTwo(slot3));
        assertFalse(slot4.wouldSplitOtherInTwo(slot4));
    }

}