package test;

import agent.*;
import agent.behavior.schedule.*;
import environment.world.agent.*;
import org.junit.jupiter.api.*;

import java.util.*;

class BatteryScheduleTest {

    BatterySchedule schedule;
    List<Agent> agents;

    @BeforeEach
    void setup(){
        agents = new ArrayList<>();
        agents.add(new Agent(0,0,5,1,""));
        //agents.get(0).updateBatteryState();
    }

    @Test
    void getBestPossibleSlot() {
    }
}