package test;

import org.junit.jupiter.api.*;
import util.custom.statistics.*;

import static org.junit.jupiter.api.Assertions.*;

class WorldClearanceStatisticsTest {

    WorldClearanceStatistics trivialStat, nonTrivialStat;

    @BeforeEach
    public void setUp(){
        trivialStat = new WorldClearanceStatistics(100);
        for (int i = 0; i <= 100; i++) {
            trivialStat.update(i, 100-i);
        }

        nonTrivialStat = new WorldClearanceStatistics(100){{
            update(1,100);
            update(3,100);
            update(10,80);
            update(15,20);
            update(20,0);
        }};

    }

    @Test
    void testClear_complex(){
        assertEquals(1, nonTrivialStat.getTurnAtCompletionPercent(0));
        assertEquals(10, nonTrivialStat.getTurnAtCompletionPercent(0.1));
        assertEquals(10, nonTrivialStat.getTurnAtCompletionPercent(0.2));
        assertEquals(15, nonTrivialStat.getTurnAtCompletionPercent(0.3));
        assertEquals(15, nonTrivialStat.getTurnAtCompletionPercent(0.4));
        assertEquals(15, nonTrivialStat.getTurnAtCompletionPercent(0.5));
        assertEquals(15, nonTrivialStat.getTurnAtCompletionPercent(0.6));
        assertEquals(15, nonTrivialStat.getTurnAtCompletionPercent(0.7));
        assertEquals(15, nonTrivialStat.getTurnAtCompletionPercent(0.8));
        assertEquals(20, nonTrivialStat.getTurnAtCompletionPercent(0.81));
        assertEquals(20, nonTrivialStat.getTurnAtCompletionPercent(0.9001));
        assertEquals(20, nonTrivialStat.getTurnAtCompletionPercent(0.9999));
        assertEquals(20, nonTrivialStat.getTurnAtCompletionPercent(1));

        assertThrows(AssertionError.class, () -> nonTrivialStat.getTurnAtCompletionPercent(1.001));
        assertThrows(AssertionError.class, () -> nonTrivialStat.getTurnAtCompletionPercent(-0.001));
    }

    @Test
    void testClear_simple(){
        assertEquals(80, trivialStat.getTurnAtNbPacketsRemaining(20));
        assertEquals(50, trivialStat.getTurnAtNbPacketsRemaining(50));
        assertEquals(20, trivialStat.getTurnAtNbPacketsRemaining(80));

        assertEquals(20, trivialStat.getTurnAtCompletionPercent(0.20));
        assertEquals(50, trivialStat.getTurnAtCompletionPercent(0.50));
        assertEquals(80, trivialStat.getTurnAtCompletionPercent(0.80));
    }

    @Test
    void illegalAddTest(){
        WorldClearanceStatistics stat = new WorldClearanceStatistics(50);
        // Add at illegal time
        assertThrows(IllegalArgumentException.class, () -> stat.update(-1,0));
        assertThrows(IllegalArgumentException.class, () -> stat.update(0,-1));

        // Add after last add
        stat.update(10,50);
        assertThrows(IllegalArgumentException.class, () -> stat.update(9,50));
        assertThrows(IllegalArgumentException.class, () -> stat.update(11,51));

        // should not result in exception
        stat.update(11,50);
        stat.update(12,49);
        stat.update(13,4);

        // cannot add at already present time
        assertThrows(IllegalArgumentException.class, () -> stat.update(13,5));
        assertThrows(IllegalArgumentException.class, () -> stat.update(13,4));
        assertThrows(IllegalArgumentException.class, () -> stat.update(13,3));

        stat.update(14,0);
        stat.update(15,0);
    }

}