package test;

import agent.behavior.learning.slotRequest.*;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

class ProbabilisticAcceptorTest {

    ProbabilisticAcceptor simpleAcceptor = new ProbabilisticAcceptor(1,0, 1, 0.5);
    ProbabilisticAcceptor concreteAcceptor = new ProbabilisticAcceptor(0.8,0.4, 10, 0.6);

    @Test
    void getProbabilityOfAcceptance_trivialCase() {
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(1,0), 0, 0.01);
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(-1,0), 1, 0.01);

        assertEquals(concreteAcceptor.getProbabilityOfAcceptance(0.9,0),0,0.01);
        assertEquals(concreteAcceptor.getProbabilityOfAcceptance(0.4,0),1,0.01);
    }

    @Test
    void getProbabilityOfAcceptance_nuancedCase() {
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(.5,0), .5, 0.01);
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(.25,0), .75, 0.01);

        assertEquals(concreteAcceptor.getProbabilityOfAcceptance(0.6,0),0.5,0.01);
        assertEquals(concreteAcceptor.getProbabilityOfAcceptance(0.5,0),0.75,0.01);
    }

    @Test
    void getProbabilityOfAcceptance_timeCase() {
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(.25,1), 1, 0.01);
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(.5,1), .5, 0.01);
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(.75,1), .0, 0.01);

        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(.25,2), 1, 0.01);
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(.5,2), .5, 0.01);
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(.75,2), .0, 0.01);

        assertEquals(concreteAcceptor.getProbabilityOfAcceptance(0.7,10),0,0.01);
        assertEquals(concreteAcceptor.getProbabilityOfAcceptance(0.6,10),0.5,0.01);
        assertEquals(concreteAcceptor.getProbabilityOfAcceptance(0.5,10),1,0.01);

    }

    @Test
    void getProbabilityOfAcceptance_longTimeCase() {
        int longTime = 100_000_000;
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(.25,longTime), 1, 0.01);
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(.49999999,longTime), 1, 0.01);
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(.50000001,longTime), 0, 0.01);
        assertEquals(simpleAcceptor.getProbabilityOfAcceptance(.75,longTime), .0, 0.01);

        assertEquals(concreteAcceptor.getProbabilityOfAcceptance(0.6000001,longTime),0,0.01);
        assertEquals(concreteAcceptor.getProbabilityOfAcceptance(0.5999999,longTime),1,0.01);
    }

    @Test
    void getProbabilityOfAcceptance_edgeCases(){
        var higherConvergence = new ProbabilisticAcceptor(1,0,5,10);
        var noConvergence = new ProbabilisticAcceptor(1,0,0,-1);

        assertEquals(higherConvergence.getProbabilityOfAcceptance(9.999, 100000000), 1,0.01);
        assertEquals(higherConvergence.getProbabilityOfAcceptance(10.001, 100000000), 0,0.01);

        assertEquals(noConvergence.getProbabilityOfAcceptance(0.5, 0), 0.5,0.01);
        assertEquals(noConvergence.getProbabilityOfAcceptance(0.5, 100000000), 0.5,0.01);
    }

    @Test
    void illegalInit() throws IllegalArgumentException{
        new ProbabilisticAcceptor(1.1,1);
        new ProbabilisticAcceptor(1.1,1, 1, 0);
        new ProbabilisticAcceptor(1.1,1, 1000, 0);
        new ProbabilisticAcceptor(1.1,1, 0, 0);
    }
}