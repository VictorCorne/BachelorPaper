package synchronizer;

import environment.MailBox;

@SuppressWarnings({"FieldCanBeLocal", "unused"})
public class PersonalSynchronizer implements Synchronizer {

    private final int myId;
    private final MailBox inbox;
    private SyncElement[] syncSet;

    private boolean ini = false;
    private boolean reqR = false;
    private boolean reqS = false;
    private boolean ackS = false;
    private boolean ackR = false;
    private boolean comR = false;
    private boolean comS = false;
    private boolean sync = false;

    PersonalSynchronizer(int id) {
        myId = id;
        inbox = new MailBox();
    }

    public int[] getSyncSet(int id) {
        return new int[0];
    }

    public void synchronize(int agent_id, int[] setOfCandidates, int time) {}

    private String getState() {
        if (syncSet.length == 0) {
            return "sync";
        }
        String state = "";
        ini = false;
        reqR = false;
        reqS = false;
        ackR = false;
        ackS = false;
        comR = false;
        comS = false;
        sync = false;
        for (SyncElement syncElement : syncSet) {
            switch (syncElement.getState()) {
                case "ini":
                    ini = true;
                    break;
                case "reqR":
                    reqR = true;
                    break;
                case "reqS":
                    reqS = true;
                    break;
                case "ackR":
                    ackR = true;
                    break;
                case "ackS":
                    ackS = true;
                    break;
                case "comR":
                    comR = true;
                    break;
                case "comS":
                    comS = true;
                    break;
                case "sync":
                    sync = true;
                    break;
            }
        }
        if (ini) {
            state = "ini";
        } else if (reqR) {  // !ini
            state = "reqR";
        } else if (reqS) {  // !ini & !reqR
            state = "reqS";
        } else if (ackR) {  //!ini & !reqR & !reqS
            state = "ackR";
        } else if (ackS) {  // !ini & !reqR & !reqS & !ackR
            state = "ackS";
        } else if (comR) {  // !ini & !reqR & !reqS & !ackR & !ackS
            state = "comR";
        } else if (comS) {  // !ini & !reqR & !reqS & !ackR & !ackS & !comR
            state = "comS";
        } else if (sync) {  // !ini & !reqR & !reqS & !ackR & !ackS & !comR & !comS
            state = "sync";
        }
        return state;
    }
}
