package agent;

import agent.behavior.schedule.*;
import util.communicationHelper.*;

/**
 * A class destined to give an easy way for communicating data from the agents
 *
 * To avoid parsing and reconstructing messages to and from a string, the data gets sent in this container
 */
public class SlotRequest implements Communicable {

    AgentRepresentation agent;

    public SlotRequest(AgentRepresentation agentRepresentation){
        agent = agentRepresentation;
    }

    public SlotRequest(AgentImp agent){
        this(new AgentRepresentation(agent));
    }

    public AgentRepresentation getAgent() {
        return agent;
    }

    @Override
    public int getCommunicationSize() {
        return agent.getCommunicationSize();
    }
}
