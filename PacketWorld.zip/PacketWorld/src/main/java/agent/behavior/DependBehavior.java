package agent.behavior;

import agent.AgentImp;

/**
 * This class represents a dependency role.
 */
public abstract class DependBehavior extends Behavior {

    /**
     * This method checks if this agent sees a sign that an agent who is
     * dependant on this agent, signals this dependency
     * (cfr methodology "Casseiopea", Alexis Drogoul)
     */
    public abstract boolean checkDependency(AgentImp agent);


    /**
     * This method handles the actions of the behavior that are action
     * related
     */
    public abstract void act(AgentImp agent);

    /**
     * This method handles the actions of the behavior that are communication
     * related. This does not include answering messages, only sending them.
     */
    public abstract void communicate(AgentImp agent);


    public void handle(AgentImp agent) {
        super.handleDependency(agent);
        if (hasHandled()) {
            return;
        }
        if (agent.inCommPhase()) {
            communicate(agent);
        } else if (agent.inActionPhase()) {
            act(agent);
        }
    }
}