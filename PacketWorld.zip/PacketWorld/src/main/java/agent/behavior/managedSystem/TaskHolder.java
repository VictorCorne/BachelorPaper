package agent.behavior.managedSystem;

import agent.behavior.tasks.*;
import environment.*;

import java.util.*;

/**
 * This interface is used for indicating entities that are able to keep tasks.
 *
 * This interface provides several utility methods related to task-keeping
 */
public interface TaskHolder {

    // TASKS
    /**
     * Returns the collection of tasks for the agent to do.
     * The agent will always try to accomplish the task on top of the stack
     */
    Stack<Task> getTasks();

    /**
     * Returns the current task of this agent or null if absent
     */
    default Task getCurrentTask() {
        return getTasks().empty() ? null : getTasks().peek();
    }

    default Coordinate getTaskLocation(){
        if (getCurrentTask() == null) return null;
        return getCurrentTask().getTaskLocation();
    }

    default boolean hasNoCurrentTask() {
        return getCurrentTask() == null;
    }

    default void removeCurrentTask() {
        getTasks().pop();
    }

    /**
     * Adds a new task for this agent and switches to it
     */
    default void addTask(Task task){
        getTasks().add(task);
    }

    /**
     * Changes the current task location if it is updatable
     */
    default void setTaskLocation(Coordinate taskLocation) {
        if(getCurrentTask().isLocationUpdatable())
            getCurrentTask().setTaskLocation(taskLocation);
    }

    default void removeAllTasks(){
        getTasks().clear();
    }
}
