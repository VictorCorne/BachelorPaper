package agent.behavior.managedSystem;

import agent.*;

public class CommunicationDelegate {

    public CommunicationDelegate(BaseBehavior baseBehavior) {

    }

    public void communicate(AgentImp agent) {
    }

    public void handleMail(AgentImp agent){

    }
}
