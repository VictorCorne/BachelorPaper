package agent.behavior.managedSystem;

import agent.*;
import agent.behavior.*;
import agent.behavior.learning.*;
import agent.behavior.learning.movement.*;
import agent.behavior.tasks.*;
import environment.*;

import java.util.*;

/**
 * The base class for an agent behavior
 * This behavior is a manageable behavior and is in state to perform the basic tasks of dropping and retrieving packets from
 * its tasks. It is also able to follow the tasks that are scheduled
 */
public class BaseBehavior extends Behavior implements TaskHolder, ScheduleHolder, LearnableBehavior{

    public BaseBehavior() {
        addPredictor(new MovementPredictor());
    }

    /**
     * Called each turn and manages all the actions this agent will be doing this turn.
     */
    @Override
    public void act(AgentImp agent) {
        monitoringDelegate.monitor(agent);
        communicationDelegate.handleMail(agent);
        goalManagementDelegate.manageGoal(agent);
        movementDelegate.movement(agent);
    }


    // COMMUNICATION
    /**
     * Calls the communication delegate to perform communication
     */
    @Override
    public void communicate(AgentImp agent) {
        communicationDelegate.communicate(agent);
    }

    // DELEGATES
    final GoalManagementDelegate goalManagementDelegate = new GoalManagementDelegate(this);
    final MonitoringDelegate monitoringDelegate = new MonitoringDelegate(this);
    final MovementDelegate movementDelegate = new MovementDelegate(this);
    final CommunicationDelegate communicationDelegate = new CommunicationDelegate(this);

    // PREDICTORS
    private final List<Predictor> predictors = new ArrayList<>();

    public List<Predictor> getPredictors() {
        return predictors;
    }

    // IMPLEMENTING THE INTERFACE

    private List<TemporalTask> scheduledTasks = new ArrayList<>();

    @Override
    public List<TemporalTask> getScheduledTasks() {
        return scheduledTasks;
    }

    private Stack<Task> tasks = new Stack<>();

    @Override
    public Stack<Task> getTasks() {
        return tasks;
    }

    public Coordinate getHeadedToLocation() {
        return goalManagementDelegate.getHeadedToLocation();
    }
}