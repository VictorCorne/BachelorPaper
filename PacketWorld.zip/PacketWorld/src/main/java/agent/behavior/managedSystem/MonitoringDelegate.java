package agent.behavior.managedSystem;

import agent.*;
import agent.behavior.tasks.*;
import environment.*;

import java.util.*;

public class MonitoringDelegate {

    public MonitoringDelegate(BaseBehavior behavior) {
        this.behavior = behavior;
    }

    public void monitor(AgentImp agent){
        // Let the agent percept and save its environment
        agent.doPerceptionCheck();
        // Check if the agent can forget missing packets
        forgetPacketsCheck(agent);
    }

    /**
     * Checks if the agent can forget packets if they are not present anymore
     */
    private void forgetPacketsCheck(AgentImp agent) {
        List<Coordinate> forgottenPacketGroupsLocation = agent.getAgentMemory().forgetMissingPacketGroups(agent);
        if(!forgottenPacketGroupsLocation.isEmpty())
            handleWhenPacketsForgotten(agent, forgottenPacketGroupsLocation);
    }

    /**
     * Called when the memory of this agent has decided to forget packets.
     * If the next goal of this agent was to pick up a packet (close enough to the packets that got forgotten), the goal will be set null
     */
    private void handleWhenPacketsForgotten(AgentImp agent, List<Coordinate> forgottenPackets) {
        Task currentTask = behavior.getCurrentTask();
        Coordinate taskLocation = behavior.getTaskLocation();;
        if(currentTask == null || taskLocation == null) return;
        if(currentTask instanceof GetPacketTask &&
                taskLocation.minDistanceCoord(forgottenPackets).distance(taskLocation) <= rangeChangeGoalWhenPacketsAreForgotten &&
                currentTask.isLocationUpdatable())
            behavior.removeCurrentTask();
    }


    // If the goal of this agent is within this distance from a group of packets that got forgotten, the goal will be reset
    private static final int rangeChangeGoalWhenPacketsAreForgotten = 2;

    private final BaseBehavior behavior;
}
