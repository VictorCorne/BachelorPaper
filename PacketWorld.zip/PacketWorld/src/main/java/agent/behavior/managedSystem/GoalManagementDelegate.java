package agent.behavior.managedSystem;

import agent.*;
import agent.behavior.tasks.*;
import environment.*;
import environment.world.destination.*;
import environment.world.energystation.*;
import environment.world.packet.*;

import java.util.*;

/**
 * The delegate of the base-behavior that specialises in managing the goals and tasks of the agent
 */
public class GoalManagementDelegate {

    // CONSTRUCTOR

    public GoalManagementDelegate(BaseBehavior behavior) {
        this.behavior = behavior;
    }

    final BaseBehavior behavior;

    /**
     * Called each turn to update the goal logic of the agent
     */
    public void manageGoal(AgentImp agent){
        doGoalAccomplishedCheck(agent);
        emptyTaskCheck(agent);
        updateTaskLocationCheck(agent);
        clearObsoleteScheduledTasks(agent);
        checkShouldStartFollowSchedule(agent);
    }

    /**
     * If the task's location is updatable, it will try to update the location
     */
    private void updateTaskLocationCheck(AgentImp agent) {
        if(behavior.getCurrentTask().isLocationUpdatable()) updateTaskLocation(agent);
    }

    /**
     * Checks if the tasks stack is empty, and if it is, a new task will be chosen
     */
    private void emptyTaskCheck(AgentImp agent) {
        if(behavior.hasNoCurrentTask()) behavior.addTask(generateNewTask(agent));
    }


    /**
     * Checks if this agent has accomplished its current goal.
     * If its goal is accomplished, it removes it from its task-stack
     */
    private void doGoalAccomplishedCheck(AgentImp agent) {
        if(behavior.getCurrentTask() != null)
            if (behavior.getCurrentTask().isFinished(agent)) behavior.removeCurrentTask();
    }



    // TASK MANAGEMENT

    /**
     * Updates the task location of this agent if possible.
     * If the tasklocation is not set (==null), this agent will try to find a location of the goal by first looking and then
     * (if nothing has been found) going through its memory
     */
    private void updateTaskLocation(AgentImp agentImp) {
        if(!behavior.getCurrentTask().isLocationUpdatable()) return;
        // If the agent can see the goal, it will update to go towards it

        boolean goalChanged = setGoalIfInVision(agentImp);
        // Do nothing if the task location is already set
        if(goalChanged) return;

        // If the task location is not set, go through the memory to find a possible location
        Class<? extends Task> aClass = behavior.getCurrentTask().getClass();
        if (GetPacketTask.class.equals(aClass))
            behavior.setTaskLocation(agentImp.getAgentMemory().getClosestItemOfClass(PacketRep.class, agentImp.getCoordinate(), null));
        else if (DeliverPacketTask.class.equals(aClass)) {
            if (agentImp.getCarry() != null)
                behavior.setTaskLocation(agentImp.getAgentMemory().getClosestItemOfClass(DestinationRep.class, agentImp.getCoordinate(), agentImp.getCarry().getColor()));
        } else if (TemporalTask.class.equals(aClass))
            behavior.setTaskLocation(agentImp.getAgentMemory().getClosestItemOfClass(EnergyStationRep.class, agentImp.getCoordinate(), null));
    }

    /**
     * Sets the next location this agent will go to as a goal this agent can see
     *
     * eg If the next goaltype of this agent is a packet and it sees a packet in its vision, the next goal will be this packet
     * Returns true if the goallocation hes been changed
     */
    private boolean setGoalIfInVision(AgentImp agent) {
        if(!behavior.getCurrentTask().isLocationUpdatable()) return false;

        Class itemClass = behavior.getCurrentTask().getItemClassForTask();
        if (itemClass == null) return false;

        List<Representation> classItemsInPerception = agent.getPerception().getAllItemsOfClassInPerception(Collections.singletonList(itemClass));
        var closestGoalInVision = classItemsInPerception.stream().filter(o -> {
                    // If the goal type is a delivery station, we want it to have the same color as the packet the agent is holding
                    if(o instanceof DestinationRep && agent.hasCarry()) return ((DestinationRep) o).getColor().equals(agent.getCarry().getColor());
                    return true;
                }) // We want the closest goal
                .min(Comparator.comparingInt(o -> o.getCoordinate().distance(agent.getCoordinate())));

        if(closestGoalInVision.isPresent()){
            behavior.setTaskLocation(closestGoalInVision.get().getCoordinate());
            return true;
        }
        return false;
    }

    /**
     * Generates a new task for the agent
     */
    private Task generateNewTask(AgentImp agent) {
        if(!agent.hasCarry())
            return new GetPacketTask(agent.getAgentMemory().getClosestItemOfClass(PacketRep.class, agent.getCoordinate(),null), null);
        else
            return new DeliverPacketTask(agent.getAgentMemory().getClosestItemOfClass(DestinationRep.class, agent.getCoordinate(), agent.getCarry().getColor()));
    }


    // SCHEDULE

    /**
     * Checks if the agent should start moving towards its schedule destination now. If it does, it adds this task on top of its stack of tasks and removes the
     * scheduled task.
     */
    private void checkShouldStartFollowSchedule(AgentImp agent) {
        TemporalTask task = behavior.getFirstScheduledTask();
        if(task == null) return;
        boolean shouldGoToSchedule = task.shouldGoToSchedule(agent, behavior.getPredictors());
        if(shouldGoToSchedule){
            if(shouldClearAllTasksWhenGoingToSchedule) behavior.removeAllTasks();
            behavior.addTask((Task) task);
            task.onStartFollowTask(behavior, agent);
            behavior.removeScheduledTask(task);
        }
    }

    /**
     * Removes the scheduled tasks whose deadline is already done
     */
    private void clearObsoleteScheduledTasks(AgentImp agent) {
        while (!behavior.getScheduledTasks().isEmpty() && !behavior.getFirstScheduledTask().getSlot().endsAfter(agent.getNbTurns())) {
            behavior.getScheduledTasks().remove(0);
        }
    }

    private boolean shouldClearAllTasksWhenGoingToSchedule = false;

    public Coordinate getHeadedToLocation() {
        return behavior.getTaskLocation();
    }
}