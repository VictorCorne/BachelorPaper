package agent.behavior.managedSystem;

import agent.*;
import agent.behavior.tasks.*;
import environment.*;
import util.excpetions.*;

import java.util.*;

public class MovementDelegate {

    public MovementDelegate(TaskHolder behavior) {
        this.behavior = behavior;
    }

    public void movement(AgentImp agent){
        rememberLastCoordinate(agent);
        if(agent.hasCommittedAction()) return;
        runTaskExecution(agent);
        if(!agent.hasCommittedAction()) moveTowardsGoal(agent);
    }

    /**
     * Runs the code of the task in order to execute it.
     *
     * Note : it is possible that the agent did not commit any action after this method. This may happen if the task is not able to be executed (example a pickup
     * packet task cannot be executed if there's no packet next to the agent to pick up
     */
    private void runTaskExecution(AgentImp agent) {
        Task currentTask = behavior.getCurrentTask();
        if(currentTask == null || agent.hasCommittedAction()) return;
        currentTask.execute(agent);
    }


    /**
     * Moves the agent towards directGoal.
     * If there is no goal (or the path is blocked), the agent will bump
     * @param agent
     */
    protected void moveTowardsGoal(AgentImp agent) {
        // The goal does not exist, wander
        if (getTaskLocation() == null) wander(agent);
        // If the goal exists, go towards it
        else {
            try {
                // allow the agent to skip turns if its task allows it or if another agent is in the direct way
                if(shouldSkipTurn(agent)) agent.skip();
                // Let the agent move to the location
                else agent.moveTowardsLocation(getTaskLocation());
            } catch (DirectPathIsBlockedException e) {
                onDirectPathBlocked(agent, getTaskLocation());
            }
        }

    }

    /**
     * Returns true if the agent should skip its turn when travelling to its goal.
     * This method returns true if its task allows the agent to skip or if this agent is adjacent to the goal and another agent is already present
     */
    private boolean shouldSkipTurn(AgentImp agent){
        if(getTaskLocation() == null) return false;

        if(getCurrentTask().isAgentAtSkippingRangeOfGoal(agent)) return true;

        if(agent.getCoordinate().distance(getTaskLocation()) != 1) return false;
        CellPerception targetper = agent.getPerception().getCellPerceptionOnAbsPos(getTaskLocation());
        if (targetper == null) return false;
        if(targetper.containsAgent()) return true;

        return false;
    }

    private Task getCurrentTask() {
        return behavior.getCurrentTask();
    }

    private Coordinate getTaskLocation() {
        return behavior.getTaskLocation();
    }

    // PATH FINDING & WANDERING

    /**
     * Called when an agent tries to move towards a location, but the direct path is blocked
     */
    protected void onDirectPathBlocked(AgentImp agent, Coordinate intendedDestination) {
        rememberLastBlockCoordinate(agent);

        if(getCurrentTask().allowToDropTask()) {
            removeCurrentTask();
            try {
                agent.moveTowardsLocation(intendedDestination);
            } catch (DirectPathIsBlockedException ignored) {
                agent.moveToRandomTileOrSkip();
            }
            return;
        }

        if(isStuck(agent)){
            addUnstuckYourselfTask(agent);
            dodgedObstacleHistory.clear();
        }

        getAroundObstacle(agent, intendedDestination);
    }

    private void removeCurrentTask() {
        behavior.removeCurrentTask();
    }

    /**
     * Generates a new coordinate this agent will wander to.
     *
     * @Post wanderDirection will be set to a new coordinate. The coordinate will be chosen with a distance (in x and y)
     * within a range of [-wanderDistance, wanderdistance]
     * returns the wanderlocation
     */
    private Coordinate generateWanderDirection(AgentImp agent) {
        int xdir = random.nextInt(maxWanderRange-minWanderRange) + minWanderRange,
                ydir = random.nextInt(maxWanderRange - minWanderRange) + minWanderRange;
        if(random.nextBoolean()) xdir = -xdir;
        if(random.nextBoolean()) ydir = -ydir;
        wanderLocation = new Coordinate(agent.getCoordinate().getX() + xdir, agent.getCoordinate().getY() + ydir);
        return wanderLocation;
    }

    // Makes the agent go towards its wanderlocation if it exists, invents one otherwise

    private void wander(AgentImp agent) {
        // Go to the wanderlocation
        // If it does not exist, create it
        if(wanderLocation == null || wanderLocation.distance(agent.getCoordinate()) <= rangeGetNewWanderLocation){
            generateWanderDirection(agent);
        }
        try {
            agent.moveTowardsLocation(wanderLocation);
        } catch (DirectPathIsBlockedException e) {
            // If the path to the new direction is blocked, move to a random neighboring tile and generate a new wander direction
            generateWanderDirection(agent);
            agent.moveToRandomTileOrSkip();
        }
    }

    /**
     * Returns true if this method detects that the agent is stuck in an obstacle.
     * This method returns true if the agent's path has been blocked around a certain location a certain number of times within a certain duration
     */
    private boolean isStuck(AgentImp agent) {
        int minimumTurnThreshold = agent.getNbTurns() - UNSTUCK_MINIMUM_HISTORY;
        return dodgedObstacleHistory.stream().
                allMatch(o -> o.coordinate.distance(agent.getCoordinate()) <= MUSTUNSTUCKYOURSELFRANGE
                        && (o.turnNb > minimumTurnThreshold));
    }

    /**
     * Method that tries to remove the agent from its blocked location.
     * This method realises this by adding new waypoints that hopefully remove the agent from its stuck location
     */
    private void addUnstuckYourselfTask(AgentImp agent) {
        Coordinate[] locs = getUnstuckLocations(agent);
        addTask(new WaitTask(locs[1], UNSTUCK_ACCEPTED_RANGE, true, false, 0));
        addTask(new WaitTask(locs[0], UNSTUCK_ACCEPTED_RANGE, true, false, 0));
    }

    private void addTask(Task task) {
        behavior.addTask(task);
    }


    private Coordinate[] getUnstuckLocations(AgentImp agent) {
        return getUnstuckLocations(agent.getCoordinate());
    }

    private Coordinate[] getUnstuckLocations(Coordinate agentCoord) {
        Coordinate firstMoveDir = agentCoord.sub(getTaskLocation()).sized(5);
        Coordinate firstMoveLoc = firstMoveDir.add(agentCoord);

        Coordinate secondDir = firstMoveDir.rotate(random.nextBoolean());
        Coordinate secondLoc = secondDir.add(agentCoord);

        return new Coordinate[]{firstMoveLoc, secondLoc};
    }


    /**
     * Moves the agent through
     * @param agent
     * @param goalCoordinate
     */
    protected void getAroundObstacle(AgentImp agent, Coordinate goalCoordinate) {
        Coordinate direction = goalCoordinate.add(agent.getCoordinate().negative()).negative();
        List<Coordinate> possibleMoves = direction.alternateDirectionsCumulative(1);

        if(random.nextBoolean()){
            try {
                agent.moveTowardsLocation(possibleMoves.get(0)); return;
            } catch (DirectPathIsBlockedException e) {
                try {agent.moveTowardsLocation(possibleMoves.get(1)); return;}
                catch (DirectPathIsBlockedException ignored) {}}
        } else {
            try {
                agent.moveTowardsLocation(possibleMoves.get(1)); return;
            } catch (DirectPathIsBlockedException e) {
                try {agent.moveTowardsLocation(possibleMoves.get(0)); return;}
                catch (DirectPathIsBlockedException ignored) {}
            }
        }

        if(random.nextFloat()<probabilitySkipTurnIfAlternativePathIsBlocked) {
            agent.skip();
        }else {
            agent.moveToRandomTileOrSkip();
        }
    }

    private void rememberLastCoordinate(AgentImp agent) {
        if(coordinateHistory.size() == HISTORYSIZE){
            coordinateHistory.removeFirst();
        }
        coordinateHistory.addLast(new LocationData(agent));
    }


    private void rememberLastBlockCoordinate(AgentImp agent){
        if(dodgedObstacleHistory.size() == OBSTACLESHISTORY){
            dodgedObstacleHistory.removeFirst();
        }
        dodgedObstacleHistory.addLast(new LocationData(agent));
    }

    //If the agent has no goal to move towards and must wander around or explore, it will go towards this location
    Coordinate wanderLocation;

    LinkedList<LocationData> coordinateHistory = new LinkedList<>(),
            dodgedObstacleHistory = new LinkedList<>();

    final static int HISTORYSIZE = 10,
            OBSTACLESHISTORY = 3;
    // If an agent bumps multiple times at coordinates of a distance of this field, the agent will try to un-stuck itself
    static final int MUSTUNSTUCKYOURSELFRANGE = 2;
    // The agent will unstuck itself if all his occurrences of getting stuck are not older than this field
    static final int UNSTUCK_MINIMUM_HISTORY = 10;
    static final int UNSTUCK_ACCEPTED_RANGE = 0, RANGE_UNSTUCK_SECONDMOVE = 4;
    // The range (x,y) of which a wanderDistance will be selected from
    private static final int minWanderRange = 3,
            maxWanderRange = 8;
    // If the agent is wandering and comes to this distance of the wanderlocation, a new wanderlocation will be generated
    private static final int rangeGetNewWanderLocation = 1;
    /**
     * If the alternative path used for going around an obstacle is blocked,
     * this probability determines the chance of skipping the turn instead of going for a random tile
     */
    private static final float probabilitySkipTurnIfAlternativePathIsBlocked = 0.2f;
    private final TaskHolder behavior;

    private static final Random random = new Random();

    /**
     * A class used to keep a record of where agents are and have been
     */
    private static final class LocationData{
        final int turnNb;
        final Coordinate coordinate;
        public LocationData(int turnNb, Coordinate coordinate) {
            this.turnNb = turnNb;
            this.coordinate = coordinate;
        }
        public LocationData(AgentImp agent){
            this(agent.getNbTurns(), agent.getCoordinate().clone());
        }

        @Override
        public String toString() {
            return "LocationData{" +
                    "turnNb=" + turnNb +
                    ", coordinate=" + coordinate +
                    '}';
        }
    }
}