package agent.behavior.managedSystem;

import agent.behavior.schedule.*;
import agent.behavior.tasks.*;
import environment.*;

import java.util.*;

/**
 * This interface is used for indicating that entities can follow a schedule.
 *
 * This interface requires that the entity is also able to follow tasks
 */
public interface ScheduleHolder extends TaskHolder {

    List<TemporalTask> getScheduledTasks();

    default void removeLatestScheduledTask(){
        getScheduledTasks().remove(getScheduledTasks().size()-1);
    }

    default TemporalTask getFirstScheduledTask() {
        return getScheduledTasks().stream().min(Comparator.comparing(o-> o.getSlot().getFromTurn())).orElse(null);
    }

    /**
     * Adds the given temporaltask to this agent's schedule.
     *
     * It also sorts the schedule
     */
    default void addScheduledTask(TemporalTask item){
        getScheduledTasks().add(item);
        getScheduledTasks().sort(Comparator.comparing(o-> o.getSlot().getFromTurn()));
    }

    /**
     * Removes the given task from the schedule
     */
    default void removeScheduledTask(TemporalTask task) {
        removeScheduledTask(task.getSlot());
    }

    /**
     * Removes the given task from the schedule
     */
    default void removeScheduledTask(TimeSlot slot) {
        var matchingSlot = getScheduledTasks().stream().filter(o->o.getSlot().equals(slot)).findFirst().orElse(null);
        if(matchingSlot != null){
            int amountBefore = getScheduledTasks().size();
            int index = getScheduledTasks().indexOf(matchingSlot);
            assert index != -1;
            getScheduledTasks().remove(index);
            assert amountBefore == getScheduledTasks().size() + 1;
        }
    }
}
