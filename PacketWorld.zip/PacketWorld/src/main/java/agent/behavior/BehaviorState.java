package agent.behavior;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeSet;

import util.Debug;

/**
 * This class acts a [GoF]FlyWeight pattern for the Behavior class. It enables
 * big Behaviors to appear a lot in behavior graphs.
 */
public class BehaviorState {

    /**
     * Creates a new BehaviorState for the given Behavior
     * @param b: the Behavior to point
     */
    public BehaviorState(Behavior b) {
        lnkBehaviorChange = new HashMap<>();
        lnkBehavior = b;
    }

    /**
     * Returns the real Behavior
     */
    public Behavior getBehavior() {
        return lnkBehavior;
    }

    /**
     * Evaluates all succeeding BehaviorChanges in random order. When the
     * postcondition of the current Behavior is false, no updates or changes
     * are done.
     * If a BehaviorChange fires then the current Behavior State of the owner
     * Agent will change to the one pointed to by the last tested
     * 'positive/open' Change.
     */
    public void testBehaviorChanges() {
        if (lnkBehaviorChange.size() == 0 || !lnkBehavior.postcondition()) {
            return;
        }

        for (var changes : lnkBehaviorChange.values()) {
            changes.forEach(BehaviorChange::updateChange);
        }

        TreeSet<Integer> priorities = new TreeSet<>(Comparator.reverseOrder());
        priorities.addAll(lnkBehaviorChange.keySet());

        for (int key : priorities) {
            var changes = lnkBehaviorChange.get(key);
            int[] rand = createRandom(changes.size());

            // Randomly try changes within the same priority level
            for (int i = 0; i < changes.size(); i++) {
                if (changes.get(rand[i]).testChange()) {
                    Debug.print(this, "changed with " + changes.get(rand[i]).toString());
                    return;
                }
            }
        }
    }


    /**
     * Adds a BehaviorChange with a given priority level (higher priority values implies a higher priority)
     */
    public void addChange(BehaviorChange bc, int priority) {
        if (!lnkBehaviorChange.containsKey(priority)) {
            lnkBehaviorChange.put(priority, new ArrayList<>());
        }

        lnkBehaviorChange.get(priority).add(bc);
    }

    private int[] createRandom(int length) {
        int[] result = new int[length];
        for (int i = 0; i < length; i++) {
            result[i] = -1;
        }
        int count = 0;
        int index;
        while (count < length) {
            index = rnd.nextInt(length);
            if (result[index] == -1) {
                result[index] = count;
                count++;
            }
        }
        return result;
    }

    /**
     * DESTRUCTOR. Cleans up this BehaviorState
     */
    public void finish() {
        if (closing) {
            return;
        }
        closing = true;
        lnkBehavior.finish();
        lnkBehavior = null;

        for (var changes : lnkBehaviorChange.values()) {
            changes.forEach(BehaviorChange::finish);
        }
        lnkBehaviorChange.clear();
        lnkBehaviorChange = null;
    }

    /**
     * @invariant lnkBehaviorChange.getElement instanceof BehaviorChange
     * @associates <{AgentImplementations.BehaviorChange}>
     * @directed
     * @supplierCardinality 0..*
     */
    private Map<Integer, List<BehaviorChange>> lnkBehaviorChange;

    /**
     * @directed
     * @supplierCardinality 1*/
    private Behavior lnkBehavior;

    // signals if this state is already closing.
    private boolean closing = false;

    static final Random rnd = new Random();
}
