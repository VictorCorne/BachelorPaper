package agent.behavior.schedule;

import agent.*;
import environment.*;

import java.util.*;
import java.util.stream.*;

/**
 * A SchedulingEntity is an active entity that is able to send & receive messages and possesses the ability of allocating charger slots to agents.
 *
 * This entity is implemented on top of an entity inside the packet-world that is able to act.
 */
public class SchedulingEntity {

    /**
     * Initializes a scheduling entity for the given chargers on a given location
     */
    public SchedulingEntity(List<EnergyStationImp> batteries, Environment environment) {
        this.energySchedulingLogic = new EnergySchedulingLogic(batteries);
        this.environment = environment;
        toSendBuffer = new SendMessageBuffer(environment);
    }

    // MAIN METHODS

    /**
     * Describes the action phase of this entity
     */
    public void action() {
        addIncomingMessages();
        nbTurns++;
        energySchedulingLogic.update(nbTurns);
    }

    /**
     * Describes the communication phase of this entity
     */
    public void communication(){
        doCommunicationPhase();
    }


    // RECEIVING MESSAGES
    public void receiveMessage(Mail mail){
        // It once happened that the buffer was being cleared while a new request was incoming, resulting in an exception
        // This lock tries to avoid this situation
        while (true) {
            try{
                incomingMessagesBuffer.add(mail);
                return;
            }catch (Exception ignored){}
        }
    }

    private void addIncomingMessages() {
        var copy = new ArrayList<>(incomingMessagesBuffer);
        copy.forEach(o->addMessageToRespectiveBuffer(o));
        copy.forEach(o->incomingMessagesBuffer.remove(o));
    }

    /**
     * Adds the given message to its respective buffer
     */
    protected void addMessageToRespectiveBuffer(Mail mail){
        if (mail instanceof SlotRequestMail) requests.add(((SlotRequestMail) mail).getRequest());
    }

    // SENDING MESSAGES

    /**
     * Adds the given message to the output buffer
     */
    protected void addMessageToSendBuffer(Object receiver, Mail mail){
        toSendBuffer.addMessage(receiver, mail);
    }

    private void doCommunicationPhase() {
        treatMessagesPhase();
        sendMessagesFromBuffer();
    }

    private void sendMessagesFromBuffer() {
        toSendBuffer.sendBuffer();
    }

    // TREATING SLOT REQUESTS

    /**
     * Method responsible for treating the messages of the buffers.
     * This can be overridden to treat messages from other queues and lists.
     */
    protected void treatMessagesPhase(){
        treatSlotRequestsPhase();
    }

    /**
     * Method responsible for the phase of treating the requests of the agents
     */
    private void treatSlotRequestsPhase(){
        var requestsToTreat = getSlotRequestsToTreatNow();
        treatSlotRequests(requestsToTreat);
        removeRequests(requestsToTreat);
    }

    /**
     * Treats all the messages given as a parameter
     */
    private void treatSlotRequests(List<SlotRequest> messagesToTreat) {
        for (var msg : messagesToTreat) treatSlotRequest(msg);
    }

    /**
     * Treats the given slotrequest.
     */
    protected void treatSlotRequest(SlotRequest request){
        try {
            var slot = energySchedulingLogic.reserveBestSlotForAgent(request.getAgent());
            var agent = environment.getAgentImplementations().getAgentImp(request.getAgent().getAgentID());
            var message = new SlotReservedMail(slot);
            addMessageToSendBuffer(agent, message);
        } catch (NoSlotAvailableException e) {
            e.print();
        }
    }

    /**
     * Returns all the messages this entity will treat now
     */
    public List<SlotRequest> getSlotRequestsToTreatNow(){
        return requests.stream().
                sorted(Comparator.comparing(o-> energySchedulingLogic.getSchedulingPriorityFor(o))).
                collect(Collectors.toList());
    }


    // MANAGING BUFFERS

    /**
     * Removes the requests from this entity's requests
     */
    private void removeRequests(List<SlotRequest> toRemoveRequests) {
        toRemoveRequests.forEach(this::removeRequest);
    }

    /**
     * Removes the given request from this entity's requests
     */
    private void removeRequest(SlotRequest toRemoveRequest) {
        requests.remove(toRemoveRequest);
    }

    // MESSAGE-MEMORY
    /**
     * The buffer for incoming messages
     */
    private final List<Mail> incomingMessagesBuffer = new ArrayList<>();

    private final List<SlotRequest> requests = new ArrayList<>();

    private final SendMessageBuffer toSendBuffer;

    // FIELDS
    private int nbTurns = 0;
    public int getNbTurns() {
        return nbTurns;
    }

    /**
     * The battery-scheduler that manages the scheduling logic for this entity.
     */
    private final EnergySchedulingLogic energySchedulingLogic;

    protected final EnergySchedulingLogic getSchedulingLogic(){
        return energySchedulingLogic;
    }

    /**
     * The environment in which this scheduler is in.
     * This field is needed in order to send messages
     */
    private final Environment environment;

    protected final Environment getEnvironment(){
        return environment;
    }
}