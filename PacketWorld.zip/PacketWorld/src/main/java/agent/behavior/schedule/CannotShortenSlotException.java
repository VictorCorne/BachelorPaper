package agent.behavior.schedule;

public class CannotShortenSlotException extends Exception {
}
