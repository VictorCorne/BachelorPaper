package agent.behavior.schedule;

import util.*;

public class NoSlotAvailableException extends Exception {
    public NoSlotAvailableException(AgentRepresentation agentRepresentation){
        this.agentRepresentation = agentRepresentation;
    }

    private final AgentRepresentation agentRepresentation;

    @Override
    public String getMessage() {
        Debug.print(this, String.format("There were no slots free for agent nb %d on turn %d. Agent had %d battery and coordinate %s%n",
                                        agentRepresentation.agentID, agentRepresentation.turnNb, agentRepresentation.getBatteryState(), agentRepresentation.getCoordinate()));
        return super.getMessage();
    }

    public void print() {
        Debug.print(this, getMessage());
    }
}
