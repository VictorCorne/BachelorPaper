package agent.behavior.schedule;

import agent.*;
import agent.behavior.managedSystem.*;
import agent.behavior.managingSystem.*;
import environment.*;
import util.*;
import util.communicationHelper.*;

import java.util.*;

/**
 * A class used for communicating the details of an agent in requests.
 */
public class AgentRepresentation implements Communicable, NullableObject<AgentRepresentation> {

    // FIELDS

    private final Coordinate coordinate;
    public Coordinate headedToCoordinate;
    public final boolean hasCarry;
    public final int batteryState;
    public final int turnNb;
    public final int agentID;

    // CONSTRUCTOR

    public AgentRepresentation(AgentImp agent) {
        this(agent.getCoordinate(),
             determineHeadedToCoordinate(agent),
             agent.hasCarry(),
             agent.getBatteryState(),
             agent.getID(),
             agent.getNbTurns());
    }

    private static Coordinate determineHeadedToCoordinate(AgentImp agentImp){
        var behavior = agentImp.getCurrentBehavior();
        if(behavior instanceof ManagementBehavior) behavior = ((ManagementBehavior) behavior).getImplementedBehavior();
        if(!(behavior instanceof BaseBehavior)) return null;
        return ((BaseBehavior) behavior).getHeadedToLocation();
    }

    public AgentRepresentation(Coordinate coordinate, Coordinate headedToCoordinate, boolean hasCarry, int batteryState, int agentID, int turnNb) {
        this.coordinate = coordinate.clone();
        this.headedToCoordinate = headedToCoordinate == null ? null : headedToCoordinate.clone();
        this.hasCarry = hasCarry;
        this.batteryState = batteryState;
        this.agentID = agentID;
        this.turnNb = turnNb;
    }

    /**
     * Creates a new AgentRepresentation by cloning the one given in parameter
     */
    public AgentRepresentation(AgentRepresentation toClone) {
        this(toClone.getCoordinate().clone(),
             toClone.headedToCoordinate == null ? null : toClone.getHeadedToCoordinate().clone(),
             toClone.hasCarry,
             toClone.getBatteryState(),
             toClone.getAgentID(),
             toClone.turnNb);
    }

    // GETTERS

    public Coordinate getCoordinate() {
        return coordinate;
    }

    public Coordinate getHeadedToCoordinate(){
        return headedToCoordinate;
    }

    public int getBatteryState() {
        return batteryState;
    }

    public int getAgentID() {
        return agentID;
    }

    public int getNbTurns() {
        return turnNb;
    }


    // METHODS

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AgentRepresentation that = (AgentRepresentation) o;
        return hasCarry == that.hasCarry && batteryState == that.batteryState && turnNb == that.turnNb && Objects.equals(getCoordinate(), that.getCoordinate());
    }

    public boolean equals(AgentImp agent){
        return equals(new AgentRepresentation(agent));
    }

    @Override
    public AgentRepresentation clone() {
        return new AgentRepresentation(this);
    }

    @Override
    public int getCommunicationSize() {
        int size = 3 * CommunicationValues.INTSIZE + 1 * CommunicationValues.BOOLSIZE;
        if(getCoordinate() != null && !getCoordinate().equals(Coordinate.nullCoordinate)) size += getCoordinate().getCommunicationSize();
        if(headedToCoordinate != null && !headedToCoordinate.equals(Coordinate.nullCoordinate)) size += headedToCoordinate.getCommunicationSize();
        return size;
    }

    @Override
    public String toString() {
        return "AgentRepresentation{" +
                "coordinate=" + getCoordinate() +
                ", turnNb=" + turnNb +
                ", agentID=" + agentID +
                '}';
    }

    // NULL REPRESENTATION

    @Override
    public AgentRepresentation getNullableObject() {
        return NULL_REPRESENTATION;
    }

    public final static AgentRepresentation NULL_REPRESENTATION = new AgentRepresentation(Coordinate.nullCoordinate,null, false, -1, -1, -1);
}
