package agent.behavior.schedule;

import util.*;

public class ScheduleNotFreeException extends Exception {

    private final TimeSlot requestedSlot;
    private final Schedule schedule;

    public ScheduleNotFreeException(Schedule schedule, TimeSlot requestedSlot) {
        this.requestedSlot = requestedSlot;
        this.schedule = schedule;
    }

    @Override
    public String getMessage() {
        var intro = String.format("%s was not free to accept the given slot %s, because %d slots were blocking the way\n",
                                  schedule.toString(), requestedSlot.toString(), schedule.getOverLappingSlots(requestedSlot).size());
        StringBuilder details = new StringBuilder(String.format("Requesting slot :\t%s\n", requestedSlot.toString()));
        for (var overlapper : schedule.getOverLappingSlots(requestedSlot)) {
          details.append(String.format("Overlapping slot\t%s\n", overlapper));
        }
        return intro + details.toString();
    }

    public void print(){
        Debug.print(this, getMessage());
    }
}
