package agent.behavior.schedule;

import agent.*;
import agent.behavior.learning.movement.*;
import environment.*;
import util.*;

import java.util.*;
import java.util.stream.*;


/**
 * Class used for implementing a smart scheduler for the battery stations. It manages multiple individual schedules
 * and is able to reserve slots for each one of them
 */
public class EnergySchedulingLogic {

    // CONSTRUCTOR
    /**
     * Initializes a new scheduler and creates a schedule for each given location
     */
    public EnergySchedulingLogic(List<EnergyStationImp> batteries) {
        for (var station : batteries)
            batterySchedules.add(new BatterySchedule(station, movementPredictor, energyPredictor));
    }

    // SCHEDULES
    private final List<BatterySchedule> batterySchedules = new ArrayList<>();
    public List<BatterySchedule> getBatterySchedules() {
        return batterySchedules;
    }

    // MAIN METHODS
    public void update(int currentTurnNb){
        for (BatterySchedule schedule : batterySchedules) schedule.update(currentTurnNb);
    }

    // RESERVING SLOTS

    /**
     * Reserves a slot for the given agent and returns the given slot
     *
     * @post    The schedule in which the agent got a slot has a place for the agent
     * @return  Returns a pointer to the allocated slot for the agent to charge
     */
    public TimeSlot reserveBestSlotForAgent(AgentImp agent) throws NoSlotAvailableException {
        return reserveBestSlotForAgent(new AgentRepresentation(agent));
    }

    /**
     * Reserves a slot for the given agent and returns the given slot
     *
     * @param agent The agent for whom we need to reserve a slot for
     * @post    The schedule in which the agent got a slot has a place for the agent
     * @return  Returns a pointer to the allocated slot for the agent to charge
     */
    public TimeSlot reserveBestSlotForAgent(AgentRepresentation agent) throws NoSlotAvailableException {
        if(batterySchedules.isEmpty()) throw new NoSlotAvailableException(agent);

        var bestSlotPair = getBestSlot(agent);
        if(bestSlotPair == null || bestSlotPair.first == null)
            throw new NoSlotAvailableException(agent);

        try {reserveSlot(bestSlotPair);}
        catch (ScheduleNotFreeException e) {
            /*Should never happen*/ e.printStackTrace();
            throw new NoSlotAvailableException(agent);
        }

        return new TimeSlot(bestSlotPair.second.getFromTurn(),
                            bestSlotPair.second.getToTurn(),
                            agent,
                            bestSlotPair.first.getChargingFieldLoc());
    }

    /**
     * Reserves the slot for this scheduler
     */
    public void reserveSlot(Pair<BatterySchedule, TimeSlot> batteryScheduleTimeSlotPair) throws ScheduleNotFreeException {
        batteryScheduleTimeSlotPair.first.addScheduledItem(batteryScheduleTimeSlotPair.second);
    }

    public void reserveSlotForChargerAt(Coordinate destination, TimeSlot slot) throws ScheduleNotFreeException, NoChargerPresentAtLocationException{
        var sched = getScheduleForChargingField(destination);
        if(sched == null) throw new NoChargerPresentAtLocationException(destination);
        reserveSlot(new Pair<>(getScheduleForChargingField(destination), slot));
    }


    /**
     * Returns a pair representing the best slot for the agent. It consists of a given energystation and its best possible slot.
     * If no slot has been found, null is returned.
     *
     * The first item is the schedule, the second is a proposal for a slot.
     */
    public Pair<BatterySchedule, TimeSlot> getBestSlot(AgentRepresentation agent){
        return batterySchedules.stream().
                // Create the result object
                map(batterySchedule -> new Pair<>(batterySchedule, batterySchedule.getBestPossibleSlot(agent))).
                // Only get the possible slots
                filter(pair->pair.second != null).
                // Find the best slot
                max(Comparator.comparing(pair->pair.first.getQualityOfSlot(agent, pair.second))).orElse(null);
    }

    // TEMPORARY SLOTS

    /**
     * Marks the given slot as definitive if it was present in this scheduling entities temporary slot
     */
    public void markSlotAsDefinitive(TimeSlot slot){
        if(slot == null) return;
        var sched = getScheduleForChargingField(slot.getDestination());
        if(sched != null) sched.markSlotAsDefinitive(slot);
    }

    /**
     * Marks the given slot as temporary.
     */
    public void markSlotAsTemporary(TimeSlot slot, int timeToLive){
        getScheduleForChargingField(slot.getDestination()).markSlotAsTemporary(slot, timeToLive);
    }


    // CANCELLING RESERVATION

    /**
     * Cancels the given reservation
     */
    public void cancelReservation(TimeSlot slot) {
        getScheduleForChargingField(slot.getDestination()).cancelSlot(slot);
    }

    // HELPER METHODS

    /**
     * Returns the coordinates of each energy-station this scheduler handles
     */
    public List<Coordinate> getEnergyStationCoords(){
        return batterySchedules.stream().map(BatterySchedule::getChargingFieldLoc).collect(Collectors.toList());
    }

    /**
     * Returns the station at the given chargingFieldCoord (if it exists, otherwise null)
     */
    public BatterySchedule getScheduleForChargingField(Coordinate chargingFieldCoord){
        return batterySchedules.stream().filter(o->o.getChargingFieldLoc().equals(chargingFieldCoord)).findFirst().orElse(null);
    }

    public boolean hasAlreadySlotForAgent(int agentID) {
        for (BatterySchedule schedule : batterySchedules) {
            for (TimeSlot slot : schedule.getScheduledItems()) {
                if (slot.getAgentRepresentation() != null && slot.getAgentRepresentation().agentID == agentID) {
                    return true;
                }
            }
        }
        return false;
    }


    /**
     * If the given slot is registered within this scheduler, it returns the quality of it.
     * Otherwise, returns an average expected value
     */
    public double getQualityOfSlot(TimeSlot slot, AgentRepresentation agent){
        return BatterySchedule.getQualityOfSlot(agent, slot);
    }

    /**
     * Returns true if and only if this energy scheduler manages an energy station that is within a range of the given coordinate
     */
    public boolean hasEnergyStationAtDistance(int range, Coordinate coordinate){
        return getEnergyStationCoords().stream().anyMatch(o->o.distance(coordinate) <= range);
    }

    /**
     * Returns the slot that is written in the memory that fulfills the given request if it exists, otherwise null
     */
    public TimeSlot getSlotThatHandlesRequest(SlotRequest request) {
        return getBatterySchedules().stream().map(bs -> bs.getSlotThatServesRequest(request)).filter(Objects::nonNull).findFirst().orElse(null);
    }

    // PREDICTORS
    private final MovementPredictor movementPredictor = new MovementPredictor();
    private final EnergyPredictor energyPredictor = new EnergyPredictor();

    public MovementPredictor getMovementPredictor() {
        return movementPredictor;
    }

    public EnergyPredictor getEnergyPredictor() {
        return energyPredictor;
    }

    public double getSchedulingPriorityFor(SlotRequest slotRequest) {
        return strategy.getPriorityFor(slotRequest, this);
    }
    SlotRequesterStrategy strategy = SlotRequestPriorityStrategies.furthestAway;
}
