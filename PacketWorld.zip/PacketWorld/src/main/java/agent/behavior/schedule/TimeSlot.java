package agent.behavior.schedule;

import agent.*;
import environment.*;
import util.*;
import util.communicationHelper.*;

import java.util.*;
import java.util.function.*;
import java.util.stream.*;

/**
 * Container class used for representing the items inside the schedule
 */
public class TimeSlot implements Communicable {

    // ATTRIBUTES
    private int fromTurn, toTurn;
    private final AgentRepresentation agentRepresentation;
    private final Coordinate destination;

    public AgentRepresentation getAgentRepresentation() {
        return agentRepresentation;
    }
    public Coordinate getDestination() {
        return destination;
    }

    public boolean servesAgent(AgentImp agent){
        return agent == null ? false :servesAgent(agent.getID());
    }

    public boolean servesAgent(AgentRepresentation agent){
        return agent == null ? false : servesAgent(agent.agentID);
    }

    public boolean servesAgent(int agentID){
        return agentRepresentation.agentID == agentID;
    }

    // CONSTRUCTOR

    /**
     * Creates a timeslot, only consisting of timebounds, but not for any agent nor destination
     */
    public TimeSlot(int fromTurn, int toTurn) {
        this(fromTurn, toTurn, AgentRepresentation.NULL_REPRESENTATION, Coordinate.nullCoordinate);
    }

    /**
     * Creates a timeslot for an agent at a location and consisting of timebounds
     * If the bounds are not correct, this constructor will invert them (ie from will be to and to will be from)
     */
    public TimeSlot(int fromTurn, int toTurn, AgentRepresentation agentRepresentation, Coordinate destination){
        if(toTurn >= fromTurn){
            this.fromTurn = fromTurn;
            this.toTurn = toTurn;
        }else {
            this.fromTurn = toTurn;
            this.toTurn = fromTurn;
        }
        this.agentRepresentation = agentRepresentation;
        this.destination = destination;
    }

    /**
     * Returns a new clone of the given timeSlot
     */
    public TimeSlot(TimeSlot toClone){
        this(toClone.getFromTurn(), toClone.getToTurn(), toClone.getAgentRepresentation().clone(), toClone.getDestination().clone());
    }

    /**
     * Returns a copy of this timeSlot but with other time-bounds
     */
    private TimeSlot getSameSlotToOtherTime(int newBegin, int newEnd){
        return new TimeSlot(newBegin, newEnd, getAgentRepresentation(), getDestination());
    }

    // DURATION
    public int getDuration() {
        return getToTurn() - getFromTurn() + 1;
    }

    public boolean isTurnInSlot(int turnNb) {
        return (getFromTurn() <= turnNb && getToTurn() >= turnNb);
    }

    public boolean endsBefore(int turnNb) {
        return getToTurn() < turnNb;
    }

    public boolean endsAfter(int turnNb) {
        return getToTurn() > turnNb;
    }

    public boolean startsAfter(int turnNb) {
        return getFromTurn() > turnNb;
    }

    public boolean startsBefore(int turnNb) {
        return getFromTurn() < turnNb;
    }

    private boolean startsBefore(TimeSlot other){
        return startsBefore(other.getFromTurn());
    }

    private boolean startsOn(int turn) {
        return this.getFromTurn() == turn;
    }

    private boolean endsOn(int turn) {
        return getToTurn() == turn;
    }

    public static int duration(int from, int to){
        return new TimeSlot(from, to).getDuration();
    }

    // OVERLAPPING
    /**
     * Returns true if and only if this slot is disjunct from the other (ie does not overlap)
     */
    public boolean disjunct(TimeSlot other){
        return !overlaps(other);
    }

    /**
     * Returns true if and only if this slot overlaps the other in some way.
     */
    public boolean overlaps(TimeSlot other){
        return getOverlappingSection(other) != null;
    }

    /**
     * Returns true if and only if this slot is fully contained within the other slot.
     */
    public boolean isFullyContainedIn(TimeSlot other){
        var overlappingSection = getOverlappingSection(other);
        return overlappingSection == null ? false : overlappingSection.sameTimeBounds(this);
    }

    public boolean envelopsOther(TimeSlot other){
        return other.isFullyContainedIn(this);
    }

    /**
     * Returns a slot representing the section that is overlapping the one given as a parameter.
     * If this slot does not overlap with the other, null is returned
     */
    public TimeSlot getOverlappingSection(TimeSlot other){
        // If no overlap, return null
        if(other == null || other.startsAfter(getToTurn()) || other.endsBefore(getFromTurn())) return null;

        var firstStart = this.getFromTurn() <= other.getFromTurn() ? this : other;
        var secondStart = firstStart == this ? other : this;
        return new TimeSlot(Math.max(firstStart.getFromTurn(), secondStart.getFromTurn()), Math.min(firstStart.getToTurn(), secondStart.getToTurn()));
    }

    /**
     * Returns true if and only if the other timeSlot is directly adjacent to this one
     */
    public boolean isAdjacentTo(TimeSlot other){
        var firstBegin = this.startsBefore(other) ? this : other;
        var secondBegin = firstBegin == this ? other : this;
        return firstBegin.getToTurn() +1 == secondBegin.getFromTurn();
    }

    // LENGTH TRANSFORMATIONS

    /**
     * Returns a new, shortened slot who is shortened to not overlap with the one given as parameter.
     * If the resulting slot cannot exist or if this slot would be split in two, null would be returned.
     *
     * @post this.overlapsWith(slot) == false
     */
    public TimeSlot shortened(TimeSlot other) {
        return shortened(other, 1);
    }

    /**
     * Returns true if the bounds of this slot overlaps the other in a way that if it were to be inscribed, the other would be split into two
     */
    public boolean wouldSplitOtherInTwo(TimeSlot other){
        if(sameTimeBounds(other)) return false;
        if(isFullyContainedIn(other)) {
            return this.fromTurn != other.fromTurn && this.toTurn != other.toTurn;
        }
        return false;
    }

    /**
     * Returns a new, shortened timeSlot who is reduced by the given percentage to make place for the one given as parameter.
     *
     * If the resulting slot would not exist (ie would be overwritten), null will be returned
     */
    public TimeSlot shortened(TimeSlot other, double reductionPercent) {
        if(wouldSplitOtherInTwo(other) || other.wouldSplitOtherInTwo(this) || sameTimeBounds(other)) return null;
        assert reductionPercent >= 0 && reductionPercent <= 1;

        var overlap = getOverlappingSection(other);
        if(overlap == null) return this.clone();

        int overlapSize = (int) Math.round((double) overlap.getDuration() * reductionPercent);
        if(overlap.startsAfter(this.getFromTurn())) return augmentedSizeAtEnd(-overlapSize);
        else return augmentedSizeAtBegin(-overlapSize);
    }

    public void shorten(TimeSlot timeSlot) throws CannotShortenSlotException {
        shorten(timeSlot,1);
    }

    public void shorten(TimeSlot other, double reductionPercent) throws CannotShortenSlotException {
        var shortened = this.shortened(other, reductionPercent);
        if(shortened == null) throw new CannotShortenSlotException();
        copyTimeBounds(this.shortened(other, reductionPercent));
    }

    void copyTimeBounds(TimeSlot toCopyBounds) {
        if(toCopyBounds == null) return;
        this.fromTurn = toCopyBounds.fromTurn;
        this.toTurn = toCopyBounds.toTurn;
    }


    /**
     * Returns a new timeSlot created by merging this one and the second together.
     *
     * @return new.fromTurn = min(this.fromTurn, other.fromTurn)
     *         new.toTurn = max(this.toTurn, other.toTurn)
     */
    public TimeSlot added(TimeSlot other){
        int newBegin = Math.min(this.getFromTurn(), other.getFromTurn());
        int newEnd = Math.max(this.getToTurn(), other.getToTurn());
        return getSameSlotToOtherTime(newBegin, newEnd);
    }

    /**
     * Returns a new TimeSlot whose size is augmented at the end with the given parameter, or null if the resulting slot is illegal (negative duration)
     */
    public TimeSlot augmentedSizeAtEnd(int dsize){
        if(getDuration() + dsize < 1) return null;
        return new TimeSlot(getFromTurn(), getToTurn() + dsize, getAgentRepresentation(), getDestination());
    }

    /**
     * Returns a new TimeSlot whose size is augmented at the start with the given parameter, or null if the resulting slot is illegal (negative duration)
     */
    public TimeSlot augmentedSizeAtBegin(int dsize){
        if(getDuration() + dsize < 1) return null;
        return new TimeSlot(getFromTurn() - dsize, getToTurn(), getAgentRepresentation(), getDestination());
    }

    /**
     * Changes the size of this timeSlot by the given value at the beginning of the slot.
     * If the resulting size would be illegal, an IllegalArgumentException will be thrown
     */
    public void changeSizeAtBegin(int dsize){
        if(getDuration() + dsize < 1) throw new IllegalArgumentException("The resulting size cannot be negative");
        fromTurn += dsize;
    }

    /**
     * Changes the size of this timeSlot by the given value at the end of the slot.
     * If the resulting size would be illegal, an IllegalArgumentException will be thrown
     */
    public void changeSizeAtEnd(int dsize){
        if(getDuration() + dsize < 1) throw new IllegalArgumentException("The resulting size cannot be negative");
        toTurn += dsize;
    }

    /**
     * Returns a pair of timeSlots that were created by splitting this one at the given threshold
     */
    public Pair<TimeSlot, TimeSlot> splitted(double percent){
        assert percent >= 0 && percent <= 1;

        int firstDuration = (int) Math.round(percent * (double) getDuration());
        int endFirst = getFromTurn() + firstDuration - 1;

        // Edge cases
        if(firstDuration == 0) return new Pair<>(null, this.clone());
        if(firstDuration == getDuration()) return new Pair<>(this.clone(), null);

        // There are multiple slots to split
        return new Pair<>(getSameSlotToOtherTime(getFromTurn(), endFirst), getSameSlotToOtherTime(endFirst + 1, getToTurn()));
    }

    // SUBSLOTS

    /**
     * Returns all the possible subslots of the given duration contained within this slot, ranging over the given parameters
     */
    public List<TimeSlot> getSubslots(Function<Integer, Integer> fromToMinDurationFunction, Function<Integer, Integer> fromToMaxDurationFunction) {
        return getSubslots(getFromTurn(), getToTurn(), fromToMinDurationFunction, fromToMaxDurationFunction);
    }

    /**
     * Returns all the possible subslots of the given duration contained within this slot, ranging over the given parameters
     */
    public List<TimeSlot> getSubslots(int from, int to, Function<Integer, Integer> fromToMinDurationFunction, Function<Integer, Integer> fromToMaxDurationFunction){
        List<TimeSlot> res = new ArrayList<>();
        for (int begin = from; begin <= to; begin++) {
            for (int end = from; end <= to; end++) {
                if(begin <= end &&
                        duration(begin, end) >= fromToMinDurationFunction.apply(begin) &&
                        duration(begin, end) <= fromToMaxDurationFunction.apply(begin)){
                    res.add(getSameSlotToOtherTime(begin,end));
                }
            }
        }
        return res;
    }
    
    

    // OVERRIDDEN METHODS

    @Override
    public String toString() {
        return "Slot [" +
                getFromTurn() +
                ", " + getToTurn() +
                "] at " + destination.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TimeSlot timeSlot = (TimeSlot) o;
        return fromTurn == timeSlot.fromTurn && toTurn == timeSlot.toTurn && destination.equals(timeSlot.destination);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fromTurn, toTurn, destination);
    }

    /**
     * Returns true if and only if this slot shares the same time bounds as the other
     */
    public boolean sameTimeBounds(TimeSlot other){
        return getFromTurn() == other.getFromTurn() && getToTurn() == other.getToTurn();
    }

    @Override
    public TimeSlot clone() {
        return new TimeSlot(this);
    }

    @Override
    public int getCommunicationSize() {
        int size = 2 * CommunicationValues.INTSIZE;
        if(destination != null) size += destination.getCommunicationSize();
        if (agentRepresentation != null) size += agentRepresentation.getCommunicationSize();
        return size;
    }

    /**
     * The INCLUSIVE bounds for this schedule
     * FromTurn must always be before toTurn
     */
    public int getFromTurn() {
        return fromTurn;
    }
    public int getToTurn() {
        return toTurn;
    }
}
