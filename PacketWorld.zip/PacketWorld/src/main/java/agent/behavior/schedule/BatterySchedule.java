package agent.behavior.schedule;

import agent.*;
import agent.behavior.learning.*;
import agent.behavior.learning.movement.*;
import agent.behavior.learning.slotRequest.*;
import environment.*;

import java.util.*;
import java.util.stream.*;

import static agent.behavior.learning.movement.ChargingPredictor.*;
import static agent.behavior.learning.movement.EnergyPredictor.*;

/**
 * A scheduler class that extends the normal schedule to implement all energy-related methods
 */
public class BatterySchedule extends Schedule{

    // ATTRIBUTES
    /**
     * The energy station this schedule is based upon.
     */
    private final EnergyStationImp energyStation;

    public EnergyStationImp getEnergyStation() {
        return energyStation;
    }

    // CONSTRUCTOR
    public BatterySchedule(EnergyStationImp energyStation, MovementPredictor movementPredictor, EnergyPredictor energyPredictor) {
        super();
        this.energyStation = energyStation;
        this.energyPredictor = energyPredictor;
        this.movementPredictor = movementPredictor;
        slotQualityPredictor = new SlotQualityPredictor();
    }

    // LOCATION
    public Coordinate getBatteryStationLoc() {
        return energyStation.getCoordinate();
    }

    public Coordinate getChargingFieldLoc(){
        return energyStation.getChargingFieldLocation();
    }

    // SLOTS
    /**
     * Returns the best possible slot this schedule has to offer for the given agent
     */
    public TimeSlot getBestPossibleSlot(AgentRepresentation agent){
        int from = agent.getNbTurns() + MovementPredictor.getEstimatedNbTurnsToMove(agent.getCoordinate(), getChargingFieldLoc());
        int to = getLongestLivingAutonomy(agent.getBatteryState()) + agent.getNbTurns() + MAXIMUM_TURNS_TO_CHARGE_UP;
        return getBestPossibleSlot(agent, from, to);
    }

    /**
     * Returns the best possible slot this schedule has to offer for the given agent
     * @param minFromTurn  The minimum turn where we want results
     * @param toTurn    The maximum turn of which we want
     *
     * @return The best timeSlot this battery-schedule has to offer for the given agent, whose time-limits fall into the given parameters
     */
    public TimeSlot getBestPossibleSlot(AgentRepresentation agent, int minFromTurn, int toTurn){

        List<TimeSlot> slots = fillSlotsIn(getSchedulableSlots(ChargingPredictor.getBestChargingSlotSize(), minFromTurn, toTurn), agent);
        return slots.stream().max(Comparator.comparing(o->getQualityOfSlot(agent, o))).orElse(null);

//        // uncomment me if you want to fill slots in an unboxed fashion
//
//        Stream<TimeSlot> freeSlots =  fillSlotsIn(getAllFreeSlots(minFromTurn, toTurn),agent).stream();
//        Stream<TimeSlot> bestSubSlotPerSlot = freeSlots.map(o->{
//
//            int minTurnAgentPresent =  MovementPredictor.getMinimumTurnAgentCanBePresent(agent, o.getDestination());
//            Function<Integer, Integer> maxDurationFn = from-> MAXIMUM_TURNS_TO_CHARGE_UP + 2;
//            Function<Integer, Integer> minDurationFn = maxDurationFn;
//
//            return o.getSubslots(Math.max(minTurnAgentPresent, o.getFromTurn()), Math.min(toTurn, o.getToTurn()), minDurationFn, maxDurationFn)
//                    .stream().max(Comparator.comparing(oo -> getQualityOfSlot(agent, oo))).orElse(null);
//        });
//        return bestSubSlotPerSlot.filter(o->o != null).max(Comparator.comparing(o->getQualityOfSlot(agent, o))).orElse(null);
    }

    private List<TimeSlot> fillSlotsIn(List<TimeSlot> slots, AgentRepresentation agentRepresentation){
        return slots.stream().map(o->new TimeSlot(o.getFromTurn(), o.getToTurn(), agentRepresentation, getChargingFieldLoc())).collect(Collectors.toList());
    }

    // HEURISTICS & CALCULATIONS

    /**
     * Returns the heuristic value of the given slot if it were given to the agent
     */
    public static double getQualityOfSlot(AgentRepresentation agent, TimeSlot slot){
        return SlotQualityPredictor.getQualityOfSlot(agent, slot);
    }


    // SERVING AGENTS

    /**
     * Returns true if and only if this schedule has a slot that serves the given request
     */
    public boolean hasSlotThatServesRequest(SlotRequest request){
        return getScheduledItems().stream().filter(o -> o.getAgentRepresentation() != null).anyMatch(o -> o.getAgentRepresentation().equals(request.getAgent()));
    }

    /**
     * Returns the slot that serves the request if it exists within this memory, otherwise null
     */
    public TimeSlot getSlotThatServesRequest(SlotRequest request){
        return getScheduledItems().stream().filter(o -> o.getAgentRepresentation() != null).filter(o -> o.getAgentRepresentation().equals(request.getAgent())).findFirst().orElse(null);
    }

    // PREDICTORS

    private final MovementPredictor movementPredictor;
    private final EnergyPredictor energyPredictor;
    private final SlotQualityPredictor slotQualityPredictor;

    private List<Predictor> getPredictors(){
        return List.of(movementPredictor, energyPredictor, slotQualityPredictor);
    }

    private MovementPredictor getMovementPredictor() {
        return movementPredictor;
    }

    private EnergyPredictor getEnergyPredictor() {
        return energyPredictor;
    }

    private SlotQualityPredictor getSlotQualityPredictor(){
        return slotQualityPredictor;
    }
}