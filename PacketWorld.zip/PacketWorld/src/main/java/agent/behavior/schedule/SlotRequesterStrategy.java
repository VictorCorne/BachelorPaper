package agent.behavior.schedule;

import agent.*;

public interface SlotRequesterStrategy {
    double getPriorityFor(SlotRequest slotRequest, EnergySchedulingLogic schedulingLogic);
}
