package agent.behavior.schedule;

import environment.*;

import java.util.*;

public class SlotRequestPriorityStrategies {

    public static SlotRequesterStrategy lowestEnergy = (request, schedulingLogic) -> request.getAgent().batteryState;

    public static SlotRequesterStrategy furthestAway = (slotRequest, schedulingLogic) -> {
        Coordinate agentCoord = slotRequest.getAgent().getCoordinate();
        Coordinate moveTo = slotRequest.getAgent().getHeadedToCoordinate();
        Coordinate next = moveTo == null ? agentCoord : Coordinate.mean(List.of(agentCoord, moveTo));
        int movementToClosest = schedulingLogic.getEnergyStationCoords().stream().min(Comparator.comparing(o->o.distance(next))).get().distance(agentCoord);
        return - movementToClosest;
    };
}
