package agent.behavior.schedule;

import environment.*;
import util.*;

import java.util.*;
import java.util.function.*;
import java.util.stream.*;

/**
 * A class that allows the scheduling of scheduledItems.
 * It offers methods to check and find free slots, reserve slots, find the size of a slot etc.
 */
public class Schedule {


    private Schedule(Schedule toClone) {
        this(toClone.scheduledItems, toClone.currentTurnNb, toClone.temporaryReservedSlots);
    }

    private Schedule (List<TimeSlot> timeSlots, int currentTurn, List<Pair<Integer, TimeSlot>> temporarySlots){
        this.currentTurnNb = currentTurn;
        this.scheduledItems = new ArrayList<>();
        for (var item : timeSlots) this.scheduledItems.add(item.clone());

        this.temporaryReservedSlots = new ArrayList<>();
        for (var item : temporarySlots) {
          temporaryReservedSlots.add(new Pair<>(item.first, item.second.clone()));
        }
    }

    // INTERACTION

    public void update(int newTurnNb){
        updateTemporaryReservedSlots(newTurnNb - this.currentTurnNb);
        advanceScheduleToTime(newTurnNb);
        removeAllFinishedItems();
    }

    /**
     * Adds this timeslot to this schedule.
     * If this schedule isn't free at the requested time bounds, an exception will be thrown
     */
    public void addScheduledItem(TimeSlot item) throws ScheduleNotFreeException{
        if(!noSlotsOverlap(item.getFromTurn(), item.getToTurn())) throw new ScheduleNotFreeException(this, item);
        getScheduledItems().add(item);
        sortScheduledItems();
    }

    /**
     * If the given parameter is after now, the current turn will be updated
     */
    private void advanceScheduleToTime(int currentTurnNb){
        if(currentTurnNb > this.currentTurnNb) this.currentTurnNb = currentTurnNb;
    }

    /**
     * Removes the given slot from this schedule
     */
    public void cancelSlot(TimeSlot slot) {
        scheduledItems.remove(slot);
    }

    public List<TimeSlot> getSlotsForAgentID(int agentID){
        return getScheduledItems().stream().filter(o->o.getAgentRepresentation().agentID == agentID).collect(Collectors.toList());
    }

    // ADDING SLOTS

    /**
     * Forcefully plans this slot into this schedule.
     * The eventual slots that were present will get shortened to make place for the given slot (or get deleted if they were fully contained inside the given slot)
     * @param slot  The slot we want to fully place in this schedule
     */
    public void forceAddSlot(TimeSlot slot){
        Predicate<TimeSlot> replaceFunc = o -> true;
        Predicate<TimeSlot> delFunc = o -> false;
        addSlotWithRules(slot, replaceFunc, delFunc);
    }

    /**
     * Adds the given slot to this schedule. If there is any overlap between the slot to add and an already present slot, this schedule keeps the slot that the function
     * allows to overwrite.
     * The shortened slots who are accepted by the deletion predicate will get deleted.
     *
     * @pre All the slots that get enveloped into the given slot must be allowed to be deleted
     *      this.getEnvelopedSlots(slot).allMatch(o->toDelete(o) == true)
     */
    public void addSlotWithRules(TimeSlot toAddSlot, Predicate<TimeSlot> toAddOverwritesPresent, Predicate<TimeSlot> deleteShortenedSlotsPredicate) {
        var overlapped = getOverLappingSlots(toAddSlot);
        var enveloped = getEnvelopedSlots(toAddSlot);
        var envelopedWithoutSplit = enveloped.stream().filter(toAddOverwritesPresent.negate()).filter(o->o.wouldSplitOtherInTwo(toAddSlot));
        boolean wouldCauseProblems = envelopedWithoutSplit.findAny().isPresent();
        if (wouldCauseProblems) return;

        // remove all slots that are fully inside the given slot
        overlapped.removeAll(enveloped);
        enveloped.stream().filter(toAddOverwritesPresent).forEach(this::cancelSlot);

        // now, trim the slots that are only partially overlapping with the parameter, only keep the partially overlapped ones
        var toShorten = overlapped.stream().filter(toAddOverwritesPresent).collect(Collectors.toList());
        toShorten.forEach(o -> {
            try {
                o.shorten(toAddSlot);
            } catch (CannotShortenSlotException e) {
                cancelSlot(o);
            }
        });
        toShorten.stream().filter(deleteShortenedSlotsPredicate).forEach(this::cancelSlot);

        var free = getAllFreeSlots(toAddSlot.getFromTurn(), toAddSlot.getToTurn());
        // No overlapping slot could be shortened, and no place has been found in between slots. Return
        if(free.size() == 0) return;
        assert free.size() == 1;
        toAddSlot.copyTimeBounds(free.get(0));
        try {
            addScheduledItem(toAddSlot);
        } catch (ScheduleNotFreeException ignored) {}

        assert isValidSchedule(this);
    }

    public static boolean isValidSchedule(Schedule schedule) {
        return schedule.scheduledItems.stream().allMatch(o-> schedule.getOverLappingSlots(o).size() == 1);
    }

    /**
     * Adds a given slot to this schedule and solves the possible conflicts by giving this slot the given relative priority compared to the other slots (ie this slot
     * is relativePriority more important than the ones it overlaps
     *
     * @pre   The timeSlot to add must not fully cover any of this schedule's slots
     */
    public void insertWithRelativePriority(TimeSlot slot, double toAddRelativePriority) {
        insertWithPriority(new Pair<>(slot, toAddRelativePriority),
                           getOverLappingSlots(slot).stream().collect(Collectors.toMap(o->o, o->1d)));
    }

    /**
     * Adds a given slot to this schedule and solves the possible conflicts by giving each slot the same priority
     *
     * @pre   The timeSlot to add must not fully cover any of this schedule's slots
     * @param toAddSlot The slot we want to add
     *
     */
    public void insertWithEqualPriority(TimeSlot toAddSlot) {
        insertWithRelativePriority(toAddSlot, 1d);
    }

    /**
     * Adds a given slot to this schedule with the given priority to solve overlapping conflicts.
     * The parameters specify the timeSlots and their priority.
     *
     * @pre   The timeSlot to add must not fully cover any of this schedule's slots
     * @param toAddSlot The slot we want to add, together with its priority.
     * @param otherPriorities The map containing the timeSlots and priority of the overlapping slots.
     *
     */
    public void insertWithPriority(Pair<TimeSlot, Double> toAddSlot, Map<TimeSlot, Double> otherPriorities){
        List<Pair<TimeSlot, Double>> mapList = otherPriorities.entrySet().stream().map(o->new Pair<>(o.getKey(), o.getValue())).collect(Collectors.toList());
        insertWithPriority(toAddSlot, mapList);
    }

    /**
     * Adds a given slot to this schedule with the given priority to solve overlapping conflicts.
     * The parameters specify the timeSlots and their priority.
     *
     * @pre   The timeSlot to add must not fully cover any of this schedule's slots
     * @param toAddSlot The slot we want to add, together with its priority.
     * @param otherPriorities The List containing the timeSlots and priority of the overlapping slots.
     *
     */
    public void insertWithPriority(Pair<TimeSlot, Double> toAddSlot, List<Pair<TimeSlot, Double>> otherPriorities){
        // assertions
        assert toAddSlot != null && toAddSlot.first != null;
        var overlappingSlots = getOverLappingSlots(toAddSlot.first);
        assert overlappingSlots.size() <= 2 && getEnvelopedSlots(toAddSlot.first).isEmpty();
        var slots = otherPriorities.stream().map(o->o.first).collect(Collectors.toList());
        assert slots.containsAll(overlappingSlots) && overlappingSlots.containsAll(slots);

        // Make place for the slot (shorten other slots, then the to add slot)
        for (var overlappingSlot : overlappingSlots) {
            double otherPrio = otherPriorities.stream().filter(o->o.first.equals(overlappingSlot)).findFirst().get().second;
            double prio = getReductionPercentForConflictSolving(toAddSlot.second, otherPrio);
            // needed because otherwise the two slots will split just equally and would overlap if the overlap is odd
            if(prio == 0.5d) prio += 0.0001d;
            var clone = overlappingSlot.clone();
            try {
                // clone needed because the reduction changes the size of the original slot.
                overlappingSlot.shorten(toAddSlot.first, prio);
                toAddSlot.first.shorten(clone,1 - prio);
            } catch (CannotShortenSlotException e) {/*Should never happen*/e.printStackTrace();}
        }

        // Add the slot
        try {
            addScheduledItem(toAddSlot.first);
        } catch (ScheduleNotFreeException e) {
            /*should never happen*/
            System.out.println(e.getMessage());
            throw new RuntimeException();
        }
    }

    // CONFLICT SOLVING

    private double getReductionPercentForConflictSolving(double presentSlotPriority, double toAddSlotPriority){
        return presentSlotPriority / (toAddSlotPriority + presentSlotPriority);
    }

    // OVERLAPPING SLOTS
    public List<TimeSlot> getOverLappingSlots(int from, int to){
        TimeSlot slot = new TimeSlot(from, to);
        return scheduledItems.stream().filter(o->o.overlaps(slot)).collect(Collectors.toList());
    }

    public List<TimeSlot> getOverLappingSlots(TimeSlot slot) {
        return getOverLappingSlots(slot.getFromTurn(), slot.getToTurn());
    }

    private boolean noSlotsOverlap(int from, int to){
        return getOverLappingSlots(from, to).isEmpty();
    }

    /**
     * Returns all the slots of this schedule that would be fully enveloped in the one given as a parameter
     */
    private Collection<TimeSlot> getEnvelopedSlots(TimeSlot slot) {
        return getScheduledItems().stream().filter(o->o.isFullyContainedIn(slot)).collect(Collectors.toList());
    }

    // FREE SLOTS
    public boolean isFreeSlot(int turnNb){
        return getScheduledItems().stream().noneMatch(o -> o.isTurnInSlot(turnNb));
    }

    public boolean isFreeSlot(int beginTurn, int endTurn){
        TimeSlot newSlot = new TimeSlot(beginTurn, endTurn);
        return scheduledItems.stream().noneMatch(o->o.overlaps(newSlot));
    }

    public boolean isFreeSlot(TimeSlot slot){
        return isFreeSlot(slot.getFromTurn(), slot.getToTurn());
    }

    /**
     * Returns the size between this scheduleditem and the following one
     */
    int getSizeOfFreeSpaceAfterItem(TimeSlot item){
        int index = getScheduledItems().indexOf(item);
        // If the given item is the last, there is an infinite free slot after it
        if(index == getScheduledItems().size() - 1) return Integer.MAX_VALUE;
        // If the given item is not in the list, there is no place
        if(index == -1) return 0;
        return getScheduledItems().get(index + 1).getFromTurn() - item.getToTurn() - 1;
    }

    /**
     * Returns the size between this scheduleditem and the following one
     */
    public int getSizeOfFreeSpaceAfterTurn(int turnNb){
        TimeSlot itemAtSlot = getItemAtTurnNb(turnNb);
        if (itemAtSlot != null) return getSizeOfFreeSpaceAfterItem(itemAtSlot);
        // There is no item at this slot
        else{
            TimeSlot itemBefore = getItemAtOrBeforeTurnNb(turnNb);
            // If there is an item before
            if(itemBefore != null){
                int size = getSizeOfFreeSpaceAfterItem(itemBefore);
                return size == Integer.MAX_VALUE ? size : ( size - (turnNb- itemBefore.getToTurn() -1));
            }
            // There is no item before. If no items at all in schedule, return infinite
            else return getScheduledItems().isEmpty() ? Integer.MAX_VALUE : getScheduledItems().get(0).getFromTurn() - turnNb;
        }
    }

    /**
     * Returns a collection of the biggest possible slots, starting from "from" and going to "to". Both values are inclusive
     */
    public List<TimeSlot> getAllFreeSlots(int from, int to){
        List<TimeSlot> res = new ArrayList<>();

        // Find the begin and end for the first slot
        int tempBegin = getStartOfFirstSlotOfSizeAvailable(1, from);
        int nextSize = getSizeOfFreeSpaceAfterTurn(tempBegin);
        int tempEnd = Math.min(to,nextSize == Integer.MAX_VALUE ? Integer.MAX_VALUE : tempBegin + nextSize-1);
        if(tempBegin <= tempEnd) res.add(new TimeSlot(tempBegin, isFreeSlot(tempEnd) ? tempEnd : tempEnd-1));

        // Repeat untill you have achieved the end
        while (tempEnd <= to){
            // Find the beginning of the next free slot
            tempBegin = getStartOfFirstSlotOfSizeAvailable(1,tempEnd+1);
            // Find the end of the given slot
            nextSize = getSizeOfFreeSpaceAfterTurn(tempBegin);
            tempEnd =  Math.min(to, nextSize == Integer.MAX_VALUE ? Integer.MAX_VALUE : tempBegin + nextSize - 1);
            // Check te remove errors
            if(tempEnd >= tempBegin)
                res.add(new TimeSlot(tempBegin, tempEnd));
            else break;
        }
        return res;
    }

    /**
     * Returns all the free slots that fall in the box with size size
     */
    public List<TimeSlot> getSchedulableSlots(int size, int from, int to){
        if(size == 0) return new ArrayList<>();
        while (from % size != 0) from ++;

        List<TimeSlot> res = new ArrayList<>();
        while (from <= to){
            var slot = new TimeSlot(from, from + size - 1);
            if(this.isFreeSlot(slot) && slot.getToTurn() <= to) res.add(slot);
            from += size;
        }
        return res;
    }

    // GET SCHEDULEDITEMS

    /**
     * Returns the number of reservations of this schedule
     */
    public int getNbReservations(){
        return scheduledItems.size();
    }

    public TimeSlot getItemAtTurnNb(int turnNb){
        return getScheduledItems().stream().filter(o -> o.isTurnInSlot(turnNb)).findFirst().orElse(null);
    }

    private TimeSlot getItemAtOrBeforeTurnNb(int turnNb){
        // If this turnNb is inside a scheduled item
        TimeSlot temp = getItemAtTurnNb(turnNb);
        if(temp != null) return temp;
        // This was a free spot, get the item just before
        return getScheduledItems().stream().filter(o -> o.endsBefore(turnNb)).max(Comparator.comparing(o-> o.getToTurn())).orElse(null);
    }

    private TimeSlot getItemAtOrAfterTurnNb(int turnNb){
        TimeSlot temp = getItemAtTurnNb(turnNb);
        if(temp != null) return temp;
        return getScheduledItems().stream().filter(o -> o.startsAfter(turnNb)).min(Comparator.comparing(o-> o.getToTurn())).orElse(null);
    }

    /**
     * Returns the timeslots who overlap (even partially) during the inclusive bounds
     */
    public List<TimeSlot> getTimeSlotsDuring(TimeSlot slot) {
        return getTimeSlotsDuring(slot.getFromTurn(), slot.getToTurn());
    }

    /**
     * Returns the timeslots who overlap (even partially) during the inclusive bounds
     */
    public List<TimeSlot> getTimeSlotsDuring(int from, int to){
        return scheduledItems.stream().filter(o->o.overlaps(new TimeSlot(from, to))).collect(Collectors.toList());
    }

    /**
     * Returns the start of the first free slot whose size is superior or equal to the given parameter
     */
    public int getStartOfFirstSlotOfSizeAvailable(int slotsize){
        return getStartOfFirstSlotOfSizeAvailable(slotsize, currentTurnNb);
    }

    public int getStartOfFirstSlotOfSizeAvailable(int slotsize, int start) {
        // Filter out all the items that start before the given start
        List<TimeSlot> itemsAfterStart = getScheduledItems().stream().filter(o-> o.endsAfter(start) || o.getToTurn() == start).collect(Collectors.toList());
        // Return the startpoint if there's enough room after the first item
        if(itemsAfterStart.isEmpty() || itemsAfterStart.get(0).getFromTurn() - start>= slotsize)
            return start;
        for (TimeSlot it : itemsAfterStart) {
            if (getSizeOfFreeSpaceAfterItem(it) >= slotsize)
                return it.getToTurn() + 1;
        }
        // Should never happen, there is always an infinite slot at the end of the schedule
        assert false;
        return -1;
    }

    // CLEANING & MAINTAINING SCHEDULE
    private void sortScheduledItems() {
        getScheduledItems().sort(Comparator.comparingInt(o -> o.getFromTurn()));
    }

    private void removeAllFinishedItems(){
        while (!getScheduledItems().isEmpty()){
            if(getScheduledItems().get(0).endsBefore(currentTurnNb)) getScheduledItems().remove(0);
            else return;
        }
    }

    // OVERRIDDEN METHODS
    @Override
    public String toString() {
        if(scheduledItems.isEmpty()) return "Empty schedule";
        return "Schedule for " + scheduledItems.get(0).getDestination().toString();
    }

    public String getDescription(){
        StringBuilder res  = new StringBuilder(toString());

        for (var item : scheduledItems) {
            res.append(item.toString()+"\n");
        }

        return res.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Schedule schedule = (Schedule) o;
        return currentTurnNb == schedule.currentTurnNb && scheduledItems.equals(schedule.scheduledItems) && temporaryReservedSlots.equals(schedule.temporaryReservedSlots);
    }

    @Override
    protected Schedule clone() {
        return new Schedule(this);
    }

    public Coordinate getLocation() {
        return getScheduledItems().isEmpty() ? null : getScheduledItems().get(0).getDestination();
    }

    // ATTRIBUTES

    private List<TimeSlot> scheduledItems = new ArrayList<>();

    public List<TimeSlot> getScheduledItems() {return scheduledItems;}

    /**
     * Counter to nb of turns. Is updated via the advanceScheduleToTime() method
     */
    private int currentTurnNb;

    public Schedule() {
        this.currentTurnNb = 0;
    }

    // TEMPORARY SLOTS

    /**
     * Marks the given slot as definitive if it was present in this scheduling entities temporary slot
     */
    public void markSlotAsDefinitive(TimeSlot slot){
        var match = temporaryReservedSlots.stream().filter(o->o.second.equals(slot)).findFirst();
        if(match.isPresent()) temporaryReservedSlots.remove(match.get());
    }

    /**
     * Updates the time to live field for each temporary reserved slot.
     * If it reaches 0, it will be removed from the memory
     */
    private void updateTemporaryReservedSlots(int turnsSinceUpdate) {
        if(turnsSinceUpdate <= 0) return;
        for (Pair<Integer, TimeSlot> temporaryReservedSlot : temporaryReservedSlots) temporaryReservedSlot.first -= turnsSinceUpdate;
        var toDeleteSlots = temporaryReservedSlots.stream().filter(o->o.first <= 0).collect(Collectors.toList());
        toDeleteSlots.forEach(o-> cancelSlot(o.second));
        toDeleteSlots.forEach(o-> temporaryReservedSlots.remove(o));
    }

    /**
     * Adds the given slot to the temporary list of slots if it is present in this schedule's slots.
     */
    public void markSlotAsTemporary(TimeSlot slot, int timeToLive){
        if(getScheduledItems().contains(slot))
            temporaryReservedSlots.add(new Pair<>(timeToLive, slot));
    }

    /**
     * The collection of all the temporary reserved slots.
     * The first field represents the time to live. If it reaches 0, the timeslot-reservation will be forgotten.
     */
    private List<Pair<Integer, TimeSlot>> temporaryReservedSlots = new ArrayList<>();

}