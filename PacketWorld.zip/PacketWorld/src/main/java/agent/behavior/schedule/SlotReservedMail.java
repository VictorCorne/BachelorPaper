package agent.behavior.schedule;

import environment.*;

/**
 * The SlotReservedMail is a mail that is used to communicate that a slot has been reserved
 */
public class SlotReservedMail extends Mail {
    public SlotReservedMail(TimeSlot timeSlot) {
        super(timeSlot == null ? null : timeSlot.clone());
    }

    public TimeSlot getTimeSlot(){
        return (TimeSlot) getMessages().get(0);
    }
}
