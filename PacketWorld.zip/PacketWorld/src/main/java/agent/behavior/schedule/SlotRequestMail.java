package agent.behavior.schedule;

import agent.*;
import environment.*;

public class SlotRequestMail extends Mail {

    public SlotRequestMail(SlotRequest request) {
        super(request);
    }

    public SlotRequest getRequest() {
        return (SlotRequest) getMessages().get(0);
    }
}
