package agent.behavior.schedule;

import java.util.*;
import java.util.function.*;

public class CannotOverwriteEnvelopedSlotException extends Exception{

    public CannotOverwriteEnvelopedSlotException(TimeSlot toAddSlot, List<TimeSlot> unOverwritableSlots, Predicate<TimeSlot> overwritePredicate) {
    }
}
