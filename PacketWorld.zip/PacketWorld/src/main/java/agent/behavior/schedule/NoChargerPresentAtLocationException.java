package agent.behavior.schedule;

import environment.*;

public class NoChargerPresentAtLocationException extends Exception {

    public final Coordinate expectedCoordinate;

    public NoChargerPresentAtLocationException(Coordinate expectedCoordinate) {
        this.expectedCoordinate = expectedCoordinate;
    }

    @Override
    public String getMessage() {
        return String.format("A charger was expected at location %s, but none was present", expectedCoordinate.toString());
    }
}
