package agent.behavior;


import agent.AgentImp;


abstract public class BehaviorChange {

    /**
     * Checks if the condition for this Behaviorchange is satisfied
     */
    abstract public boolean isSatisfied();

    /**
     * Updates this change. The conditions in this change are
     * computed/verified.
     */
    public abstract void updateChange();

    /**
     * Updates this change according to the information contained in the Agent.
     * If the update lets this Change fire and the precondition of the
     * target is true, then the owner Agent's currentBehaviorState is set to
     * the next state pointed by this BehaviorChange.
     */
    public boolean testChange() {
        if (isSatisfied() &&
            lnkBehaviorState.getBehavior().precondition(getAgentImp())) {
            lnkAgentImp.getCurrentBehavior().leave(lnkAgentImp);
            lnkAgentImp.setCurrentBehaviorState(lnkBehaviorState);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Sets the target behavior, specified by its flyweight BehaviorState
     */
    public void setNextBehavior(BehaviorState bs) {
        lnkBehaviorState = bs;
    }

    /**
     * Association to the owning AgentImp
     */
    public AgentImp getAgentImp() {
        return lnkAgentImp;
    }

    /**
     * Sets association to the owning AgentImp
     */
    public void setAgentImp(AgentImp lnkAgentImmp) {
        this.lnkAgentImp = lnkAgentImmp;
    }

    /**
     * DESTRUCTOR
     */
    public void finish() {
        lnkAgentImp = null;
        lnkBehaviorState.finish();
        lnkBehaviorState = null;
    }

    /**
     * @directed
     * @supplierCardinality 0..1
     */
    private BehaviorState lnkBehaviorState;

    /**
     * @directed
     */
    private AgentImp lnkAgentImp;
}
