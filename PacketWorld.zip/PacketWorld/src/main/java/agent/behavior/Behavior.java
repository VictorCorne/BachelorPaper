package agent.behavior;

import java.util.ArrayList;
import java.util.List;

import agent.*;
import com.google.common.eventbus.*;

/**
 * This class represents a role for an agent. It contains the actions the agent
 * does when playing this role.
 */
abstract public class Behavior {

    /**
     * Enables to create multiple instance of a behavior. This is only
     * recommended for light Behavior classes.
     * @deprecated
     */
    @Deprecated
    protected Behavior(boolean singleinstance) {
    }

    protected Behavior() {
        this(true);
    }


    protected EventBus getEventBus(AgentImp agent){
        return agent.getEventBus();
    }

    /**
     * This method handles the actions of the behavior that are action related
     */
    public abstract void act(AgentImp agent);

    /**
     * This method handles the actions of the behavior that are communication
     * related. This does not include answering messages, only sending them.
     */
    public abstract void communicate(AgentImp agent);



    /**
     * Implements the general Behavior.handle method
     * see superclass
     * For the LTD sheme behaviors, this method does communication if in
     * communication phase and then directly responds to any messages it
     * may have received.
     * In action phase it triggers the actions of this behavior.
     */
    public void handle(AgentImp agent) {
        // First check for dependent behaviors, and execute them if necessary
        this.handleDependency(agent);
        
        if (this.hasHandled()) {
            return;
        }
        if (agent.inCommPhase()) {
            communicate(agent);
            agent.closeCommunication();
        } else if (agent.inActionPhase()) {
            agent.resetCommitedAction();
            act(agent);

            if (!agent.hasCommittedAction()) {
                throw new RuntimeException(String.format("Agent with ID=%d did not perform any action in its current behavior. Make sure the agent performs exactly one action each turn (taking the skip action into account as well).", agent.getID()));
            }
        }
    }


    public void handleDependency(AgentImp agent) {
        hasHandled = false;

        for (var dependentBehavior : dependers) {
            if (dependentBehavior.checkDependency(agent)) {
                dependentBehavior.handle(agent);
            }
            if (dependentBehavior.hasHandled()) {
                // If the dependent behavior indicates that the agent is handled,
                // do not execute other agent behavior
                this.hasHandled = true;
            }
        }
    }


    /**
     * This method checks if the precondition of the behavior is fulfilled
     * Note: subclasses should always call superclass precondition first
     */
    public boolean precondition(AgentImp agent) {
        return true;
    }

    /**
     * This method checks if the postcondition of the behavior is fulfilled
     * Note: subclasses should always call superclass postcondition first
     */
    public boolean postcondition() {
        return true;
    }

    /**
     * Returns the depending behavior at index
     */
    protected DependBehavior getDepender(int index) {
        return dependers.get(index);
    }

    /**
     * Adds a dependent behavior
     */
    protected void addDependency(DependBehavior dep) {
        dependers.add(dep);
    }

    /**
     * Checks if this role has done for this synchronization cycle
     */
    public boolean hasHandled() {
        return hasHandled;
    }

    /**
     * Returns a description of this role
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets a description for this role
     */
    protected void setDescription(String description) {
        this.description = description;
    }

    /**
     * DESTRUCTOR. Clears this role.
     */
    public void finish() {
        if (closing) {
            return;
        }
        closing = true;
        for (int i = 0; i < dependers.size(); i++) {
            dependers.get(i).finish();
        }
        dependers.clear();
        dependers = null;
        description = null;
    }

    /**
     * Actions to take before leaving this role
     */
    public void leave(AgentImp agent) {
    }

    //attributes
    private List<DependBehavior> dependers = new ArrayList<>();
    private String description;
    public static boolean singleInstance = true;
    protected boolean hasHandled;
    private boolean closing = false;


    // OBSERVERS
    protected final List<AgentObserver> observers = new ArrayList<>();

    public void addObserver(AgentObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(AgentObserver observer){
        observers.remove(observer);
    }
}