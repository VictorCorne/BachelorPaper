package agent.behavior.managingSystem.communicationStrategy.masterSlaveBehavior;

import agent.*;
import agent.behavior.managingSystem.*;
import agent.behavior.schedule.*;
import environment.*;

import java.util.*;
import java.util.stream.*;

/**
 * The implementation of a slaveBehavior for the packetWorld
 * This class builds upon the EnergyManagementBehavior class.
 */
public class SlaveBehavior extends CentralisedEnergyManagementBehavior {

    /**
     * Finds the central energy station and sets it as the scheduler.
     * It also saves the reference to the scheduler and passes it to all the other agents
     */
    @Override
    protected void initialiseEnvironment(AgentImp agent) {
        // Get the central station
        List<EnergyStationImp> stations = new ArrayList<>(agent.getEnvironment().getAgentImplementations().getEnergyStationsSet().values());
        List<Coordinate> stationCoords = stations.stream().map(o->o.getCoordinate()).collect(Collectors.toList());
        Coordinate center = Coordinate.getCentralCoordinate(stationCoords);
        EnergyStationImp centerStation = stations.stream().filter(o->o.getCoordinate().equals(center)).findFirst().get();

        // Init the central station
        centerStation.setSchedulingEntity(new SchedulingEntity(stations, agent.getEnvironment()));

        // Pass the reference to the central station everywhere
        for (AgentImp a : agent.getEnvironment().getAgentImplementations().getAllAgents())
            ((SlaveBehavior) a.getCurrentBehavior()).setMaster(centerStation);

    }

    private void setMaster(EnergyStationImp master){
        this.master = master;
    }

    /**
     * Returns the central master computer
     */
    @Override
    protected SchedulingEntity getScheduler(AgentImp agent) {
        return master.getSchedulingEntity();
    }

    private EnergyStationImp master;
}
