package agent.behavior.managingSystem.communicationStrategy.regionalPlannerBehavior;

import agent.*;
import agent.behavior.schedule.*;
import environment.*;
import environment.world.region.*;

import java.util.*;
import java.util.stream.*;

public class RegionSchedulerMap extends HashMap<Region, SchedulingEntity> {

    /**
     * Initialises this map to be the clone of the one given in the parameter
     * @param map
     */
    public RegionSchedulerMap(RegionSchedulerMap map) {
        super();
        map.forEach((key, value) -> this.put(key.clone(), value));
    }

    public RegionSchedulerMap(){
        super();
    }

    /**
     * Returns the SchedulingEntity that is responsible for handling requests at the given location
     */
    public SchedulingEntity getSchedulingEntityFor(Coordinate coordinate){
        Region region = getRegionFor(coordinate);
        return get(region);
    }

    /**
     * Returns the region where this coordinate is located at
     */
    public Region getRegionFor(Coordinate coordinate){
        return entrySet().stream().filter(o->o.getKey().isInRegion(coordinate)).findFirst().get().getKey();
    }

    public List<Region> getAllRegions(){
        return new ArrayList<>(this.keySet());
    }
}
