package agent.behavior.managingSystem.communicationStrategy.regionalPlannerBehavior;

import agent.*;
import agent.behavior.*;
import agent.behavior.schedule.*;
import environment.*;
import environment.world.region.*;

import java.util.*;
import java.util.stream.*;

public class RegionalPlannerFactory {

    public void initialiseRegionalPlanner(RegionWorldFactory.PRESET preset, Environment environment){
        // Init region world
        RegionWorld regionWorld = RegionWorldFactory.createNewRegionWorld(preset, environment);

        // Init schedulers
        initialiseSchedulers(regionWorld, environment);

        RegionSchedulerMap map = createSchedulerMap(regionWorld, environment);

        shareMapToAllAgents(environment, map);
    }

    private RegionSchedulerMap createSchedulerMap(RegionWorld regionWorld, Environment environment) {
        RegionSchedulerMap map = new RegionSchedulerMap();
        for (Region region : regionWorld.getRegions()) {
            var schedulers = environment.getAgentImplementations().getSchedulingStationsInArea(region.getCoordinates());
            assert schedulers.size() == 1;
            map.put(region.clone(), schedulers.get(0).getSchedulingEntity());
        }
        return map;
    }

    /**
     * Shares the regionalSchedulerMap to all the agents of the environment
     */
    private void shareMapToAllAgents(Environment environment, RegionSchedulerMap map) {
        for (Behavior rb : environment.getAgentImplementations().getAllAgentBehaviors()) {
            ((RegionalBehavior) rb).setRegionSchedulerMap(new RegionSchedulerMap(map));
        }
    }

    /**
     * Initialises the scheduling entities for the environment
     */
    private void initialiseSchedulers(RegionWorld regionWorld, Environment environment){
        for (Region region : regionWorld.getRegions()) {
            List<Coordinate> regionStationsCoords = region.getAllMatchingCoordinates(environment.getEnergyStationWorld().getItemLocations());
            List<EnergyStationImp> regionStations = environment.getAgentImplementations().getStationsAt(regionStationsCoords);

            Coordinate centralCoord = Coordinate.getCentralCoordinate(regionStationsCoords);
            EnergyStationImp scheduler = environment.getAgentImplementations().getStationAt(centralCoord);

            initialiseScheduler(scheduler, regionStations, environment, region);
        }
        List<RegionalSchedulingEntity> worldSchedulingEntities =
                environment.getAgentImplementations().getSchedulingEntities().stream().map(o->(RegionalSchedulingEntity)o).collect(Collectors.toList());
        worldSchedulingEntities.forEach(o->o.setContactableEntities(worldSchedulingEntities));
    }

    private void initialiseScheduler(EnergyStationImp schedulerStation, List<EnergyStationImp> regionStations, Environment environment, Region region){
        RegionalSchedulingEntity schedulingEntity = new RegionalSchedulingEntity(regionStations, environment, List.of(), region);
        schedulerStation.setSchedulingEntity(schedulingEntity);
    }
}
