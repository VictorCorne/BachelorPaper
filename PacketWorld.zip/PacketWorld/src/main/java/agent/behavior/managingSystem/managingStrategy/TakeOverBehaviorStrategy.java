package agent.behavior.managingSystem.managingStrategy;

import agent.*;
import agent.behavior.managedSystem.*;
import agent.behavior.managingSystem.*;
import agent.behavior.schedule.*;
import agent.behavior.tasks.*;

import java.util.*;
import java.util.stream.*;

/**
 * This strategy is used to fulfil the energy-concern, and when it is needed to go charge, this behavior will fully take control of the agent.
 */
@Deprecated
public class TakeOverBehaviorStrategy extends EnergyManagementStrategy implements TaskHolder, ScheduleHolder {


    public TakeOverBehaviorStrategy(ManagementBehavior managementBehavior) {
        super(managementBehavior);
    }

    @Override
    public List<TimeSlot> getAllSlots() {
        var a = getTasks().stream().filter(o->o instanceof ChargeYourselfTask).map(o->((ChargeYourselfTask) o).getSlot()).collect(Collectors.toList());
        var b = getScheduledTasks().stream().filter(o->o instanceof ChargeYourselfTask).map(o->o.getSlot()).collect(Collectors.toList());
        a.addAll(b);
        return a;
    }

    @Override
    public boolean shouldBeMovingToStation(AgentImp agent) {
        return getCurrentTask() != null;
    }

    @Override
    public void receiveSlot(TimeSlot task, AgentImp agent) {
        addScheduledTask(new ChargeYourselfTask(task));
    }

    @Override
    public void removeSlot(TimeSlot toRemove, AgentImp agent) {
        removeScheduledTask(new ChargeYourselfTask(toRemove));
    }

    /**
     * If this managementStrategy deems it necessary to go charge, it imposes the agent to move towards the goal and therefore does not allow the managed behavior to
     * move freely
     */
    @Override
    public void act(AgentImp agent) {
        if(shouldBeMovingToStation(agent)) movementDelegate.movement(agent);
        getImplementedBehavior().act(agent);
    }

    // MOVEMENT

    /**
     * This field describes the logic that deals with the movement of the agent.
     *
     * To not rewrite this logic, we use the standard movement logic that is also used in other behaviors.
     */
    MovementDelegate movementDelegate = new MovementDelegate(this);

    // INTERFACE METHODS
    List<TemporalTask> scheduledTasks = new ArrayList<>();
    @Override
    public List<TemporalTask> getScheduledTasks() {
        return scheduledTasks;
    }

    Stack<Task> tasks = new Stack<>();
    @Override
    public Stack<Task> getTasks() {
        return tasks;
    }
}
