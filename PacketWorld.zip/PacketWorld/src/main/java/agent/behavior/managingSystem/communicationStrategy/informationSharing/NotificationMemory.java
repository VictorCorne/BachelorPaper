package agent.behavior.managingSystem.communicationStrategy.informationSharing;

import agent.behavior.schedule.*;
import util.*;

import java.util.*;
import java.util.stream.*;

public class NotificationMemory {

    // MAIN METHODS


    public NotificationMemory() {}

    /**
     * Cleans up the memory by removing entries that are already done
     * @param currentTurnNb The current turn-number
     */
    public void update(int currentTurnNb){
        var toDelete = getAllToDeleteNotifications(currentTurnNb);
        toDelete.forEach(o->forgetEntry(o));
    }

    // ATTRIBUTES
//    private final List<Pair<TimeSlot, List<Integer>>> assumedKnowsAboutNotificationMap = new ArrayList<>();
    private final Map<TimeSlot, List<Integer>> assumedKnowsAboutNotificationMap = new Hashtable<>();
    private final List<TimeSlot> hasAlreadySpreadInformationList = new ArrayList<>();

    // MEMORY MANAGEMENT

    /**
     * Forgets the entry linked to the notification
     * @param notification
     */
    private void forgetEntry(TimeSlot notification) {
        assumedKnowsAboutNotificationMap.remove(notification);
        hasAlreadySpreadInformationList.remove(notification);
    }

    /**
     * Returns all the notifications that are already done
     */
    private Collection<TimeSlot> getAllToDeleteNotifications(int currentTurnNb) {
        return assumedKnowsAboutNotificationMap.keySet().stream().filter(o->o.endsBefore(currentTurnNb)).collect(Collectors.toList());
    }

    // AGENTS THAT KNOW ABOUT NOTIFICATION

    public void addAgentKnows(TimeSlot slot, int agentID){
        List<Integer> knowingAgents = assumedKnowsAboutNotificationMap.get(slot);
        if(knowingAgents == null){
            // create the entry
            assumedKnowsAboutNotificationMap.put(slot, new ArrayList<>(){{add(agentID);}});
        }else {
            knowingAgents.add(agentID);
        }
    }

    /**
     * Returns true if and only if this memory remembers spreading the given notification to the given agentID
     */
    public boolean doesAgentKnowAboutNotification(TimeSlot slot, int agentID){
        var knows = assumedKnowsAboutNotificationMap.get(slot);
        if(knows == null) return false;
        return knows.contains(agentID);
    }

    // ALREADY HAVING SPREAD INFORMATION

    public void addHasSpreadInformation(TimeSlot slot){
        if(!hasAlreadySpreadInformationList.contains(slot)) hasAlreadySpreadInformationList.add(slot);
    }

    public boolean hasAlreadySpreadNotification(TimeSlot slot){
        return hasAlreadySpreadInformationList.contains(slot);
    }

}
