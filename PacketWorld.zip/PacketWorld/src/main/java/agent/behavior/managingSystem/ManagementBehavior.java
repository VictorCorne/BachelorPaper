package agent.behavior.managingSystem;

import agent.*;
import agent.behavior.*;
import agent.behavior.managedSystem.*;
import agent.behavior.managingSystem.managingStrategy.*;

/**
 * A class for adding a new management-layer on top of an already existing behavior.
 * The managementBehavior implements the decorator pattern, executes its role and then calls the execution of its managed behavior.
 * A managementBehavior can manage another managementBehavior, allowing this class to be used to add an arbitrary number of management layers to a behavior.
 */
public abstract class ManagementBehavior extends Behavior {

    /**
     * Constructs a behavior that manages another.
     *
     * The behavior to be managed is passed as parameter
     */
    public ManagementBehavior(Behavior managedBehavior) {
        this.managedBehavior = managedBehavior;
    }

    /**
     * To allow the execution of the program without modifying the files too much,
     * a parameterless constructor is required.
     *
     * This constructor makes a managementBehavior that manages the baseBehavior
     */
    public ManagementBehavior(){
        this(new BaseBehavior());
    }

    /**
     * Acts like the top layer of the management and calls the managed layer to act
     */
    @Override
    public void act(AgentImp agent) {
        managementStrategy.act(agent);
    }

    /**
     * Acts like the top layer of the management and calls the managed layer to act
     */
    @Override
    public void communicate(AgentImp agent) {
        managedBehavior.communicate(agent);
    }

    // MANAGEMENT STRATEGY
    private ManagementStrategy managementStrategy;

    public void setManagementStrategy(ManagementStrategy managementStrategy){
        this.managementStrategy = managementStrategy;
    }

    public ManagementStrategy getManagementStrategy(){
        return managementStrategy;
    }

    // MANAGING BEHAVIORS

    /**
     * The behavior that is being managed by this behavior
     */
    private final Behavior managedBehavior;

    public final Behavior getManagedBehavior() {
        return managedBehavior;
    }

    /**
     * Returns the lowest behavior (the one that realises the base tasks
     */
    public final Behavior getImplementedBehavior(){
        Behavior managedBehavior = getManagedBehavior();
        while (true){
            if (!(managedBehavior instanceof ManagementBehavior)) break;
            managedBehavior = ((ManagementBehavior) managedBehavior).getManagedBehavior();
        }
        return managedBehavior;
    }
}
