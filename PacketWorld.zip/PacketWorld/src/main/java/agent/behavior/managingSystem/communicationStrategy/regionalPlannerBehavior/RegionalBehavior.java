package agent.behavior.managingSystem.communicationStrategy.regionalPlannerBehavior;

import agent.*;
import agent.behavior.managingSystem.*;
import environment.world.region.*;

public class RegionalBehavior extends CentralisedEnergyManagementBehavior {

    // INITIALISATION

    public static final RegionWorldFactory.PRESET worldPreset = RegionWorldFactory.ENERGY_VORONOI;

    /**
     * Initialises the environment
     */
    @Override
    protected void initialiseEnvironment(AgentImp agent) {
        new RegionalPlannerFactory().initialiseRegionalPlanner(worldPreset, agent.getEnvironment());
    }

    /**
     * Returns the scheduler that resides in the same region as the agent
     */
    @Override
    protected RegionalSchedulingEntity getScheduler(AgentImp agent) {
        return (RegionalSchedulingEntity) regionSchedulerMap.getSchedulingEntityFor(agent.getCoordinate());
    }

    // REGIONAL MAP

    /**
     * The personal map this agent uses to detect regions
     */
    private RegionSchedulerMap regionSchedulerMap;

    public RegionSchedulerMap getRegionSchedulerMap() {
        return regionSchedulerMap;
    }

    public void setRegionSchedulerMap(RegionSchedulerMap map) {
        this.regionSchedulerMap = map;
    }
}