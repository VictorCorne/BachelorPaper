package agent.behavior.managingSystem.communicationStrategy.regionalPlannerBehavior;

import agent.behavior.schedule.*;
import environment.*;
import util.communicationHelper.*;

/**
 * A mail used for the regional schedulers to communicate that they accept the slot from the other regional scheduler
 */
public class SchedulerSlotAck extends Mail {

    public SchedulerSlotAck(TimeSlot ackSlot) {
        super(ackSlot);
        slot = ackSlot;
    }

    private TimeSlot slot;

    public TimeSlot getSlot() {
        return slot;
    }
}
