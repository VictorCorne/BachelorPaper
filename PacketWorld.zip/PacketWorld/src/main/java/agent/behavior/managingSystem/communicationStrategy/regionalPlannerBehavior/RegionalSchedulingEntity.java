package agent.behavior.managingSystem.communicationStrategy.regionalPlannerBehavior;

import agent.*;
import agent.behavior.learning.movement.*;
import agent.behavior.learning.slotRequest.*;
import agent.behavior.schedule.*;
import environment.*;
import environment.world.region.*;
import util.*;

import java.util.*;
import java.util.stream.*;

/**
 * A regional scheduler is a scheduling entity who works within a region.
 *
 * This scheduler works according to the following protocol:
 *   1. This entity is always able to receive messages
 *   2. When this entity must allocate a slot and its quality is too bad, it will ask other schedulers for their best slot
 *   3. When a regional scheduler receives a request from another scheduler, it allocates its best slot temporarily for the request and sends it back.
 *   4. When the regional scheduler receives the responses, he will respond to the best one. When the receiver receives the response, it writes the slot as temporary.
 *      Otherwise it would disappear
 */
public class RegionalSchedulingEntity extends SchedulingEntity{

    // CONSTRUCTOR

    public RegionalSchedulingEntity(List<EnergyStationImp> batteries, Environment environment, List<RegionalSchedulingEntity> contactableSchedulingEntities,
                                    Region region) {
        super(batteries, environment);
        this.contactableSchedulingEntities = contactableSchedulingEntities;
        this.region = region;
    }


    // ADDING MESSAGES TO BUFFERS

    @Override
    protected void addMessageToRespectiveBuffer(Mail mail) {
        super.addMessageToRespectiveBuffer(mail);
        if(mail instanceof SchedulerSlotAck) addAckMail((SchedulerSlotAck) mail);
        if(mail instanceof SchedulerSlotAnswerMail) addSlotAnswerMail((SchedulerSlotAnswerMail) mail);
        if(mail instanceof SchedulerSlotRequestMail) addSlotRequestMail((SchedulerSlotRequestMail) mail);
    }

    /**
     * Adds the given slotAnswerMail to its corresponding buffer
     */
    private void addSlotAnswerMail(SchedulerSlotAnswerMail mail) {
        if(!schedulerAnswers.containsKey(mail.request)) schedulerAnswers.put(mail.request, new ArrayList<>());
        schedulerAnswers.get(mail.request).add(new Pair<>(mail.sender, mail.response));
    }

    /**
     * Adds the given slotRequestMail to its corresponding buffer
     */
    private void addSlotRequestMail(SchedulerSlotRequestMail mail) {
        schedulerSlotRequests.add(mail);
    }

    /**
     * Adds the given ackMail to its corresponding buffer
     */
    private void addAckMail(SchedulerSlotAck ack){
        slotAcks.add(ack);
    }

    // TREATING MAIL


    @Override
    protected void treatMessagesPhase() {
        treatAckMessages();
        treatScheduleAnswers();
        treatSchedulerSlotRequests();
        // treat requests of agents
        super.treatMessagesPhase();
    }

    /**
     * Treats all the scheduler slot requests
     */
    private void treatSchedulerSlotRequests() {
        schedulerSlotRequests.forEach(o -> treatSchedulerSlotRequest(o));
        schedulerSlotRequests.clear();
    }

    /**
     * Responds to the request of the given scheduler to give its best slot for the given request
     */
    private void treatSchedulerSlotRequest(SchedulerSlotRequestMail mail) {
        try {
            var requesterAgent = mail.getRequest().getAgent();
            var senderBest = mail.getSenderBestProposal();
            var sender = mail.getSender();

            var localBestSlot = getSchedulingLogic().getBestSlot(requesterAgent);

            if (localBestSlot == null) {
                // no slot has been found
                addMessageToSendBuffer(sender, new SchedulerSlotAnswerMail(null, mail.getRequest(), this));
            } else {
                // The best slot this scheduler can propose is not null
                boolean responseBetterThanSender = !regionalSchedulerPredictor.shouldAcceptSlotFromOriginalScheduler(senderBest, localBestSlot.second, requesterAgent);

                if (responseBetterThanSender) {
                    getSchedulingLogic().reserveSlot(localBestSlot);
                    getSchedulingLogic().markSlotAsTemporary(localBestSlot.second, SLOTRESPONSE_TIMETOLIVE);
                    addMessageToSendBuffer(sender, new SchedulerSlotAnswerMail(localBestSlot.second, mail.getRequest(), this));
                } else {
                    // do not bother to reserve a slot that will not be accepted
                    addMessageToSendBuffer(sender, new SchedulerSlotAnswerMail(null, mail.getRequest(), this));
                }
            }
        } catch (ScheduleNotFreeException e) {
            // should never happen because we try to reserve the best slot (thus no collision)
        e.printStackTrace();
        assert false;
        }
    }

    private void treatScheduleAnswers() {
        // needed for concurrent modification
        var copy = new HashSet<>(schedulerAnswers.entrySet());
        copy.forEach(o -> treatScheduleAnswer(o.getKey(), o.getValue()));
    }

    /**
     * Tries to treat the scheduler answers for the given request.
     * If all the entities have responded to the given request, this entity will send an ack to the receiver and communicate the slot to the agent.
     */
    private void treatScheduleAnswer(SlotRequest request, List<Pair<SchedulingEntity, TimeSlot>> answers) {
        // Return if not all answers collected yet
        if(!expectedResponsesForSchedulerRequests.containsKey(request) || expectedResponsesForSchedulerRequests.get(request) != answers.size()) return;

        // some schedulers return null because they do not have valid slots over
        var bestResponse = answers.stream().filter(o->o.second != null).
                // get best answer
                max(Comparator.comparing(o->getSchedulingLogic().getQualityOfSlot(o.second, request.getAgent()))).map(o-> o.second).orElse(null);
        var placeHolderBest = getSchedulingLogic().getSlotThatHandlesRequest(request);

        boolean isPlaceHolderAnswerBetter = regionalSchedulerPredictor.shouldAcceptSlotFromOriginalScheduler(placeHolderBest, bestResponse, request.getAgent());

        if(isPlaceHolderAnswerBetter){
            if(placeHolderBest != null){
                getSchedulingLogic().markSlotAsDefinitive(placeHolderBest);
                addMessageToSendBuffer(request.getAgent(), new SlotReservedMail(placeHolderBest));
            }
        }else {
            if(bestResponse != null){
                addMessageToSendBuffer(request.getAgent(), new SlotReservedMail(bestResponse));
                addMessageToSendBuffer(bestResponse, new SchedulerSlotAck(bestResponse));
            }
        }

        // Clear the memory
        expectedResponsesForSchedulerRequests.remove(request);
        schedulerAnswers.remove(request);
    }

    /**
     * Acknowledges that the given slots have been accepted. It makes the temporary slot definitive if it received an Ack message for it.
     */
    private void treatAckMessages() {
        slotAcks.forEach(o->treatAckMessage(o));
        slotAcks.clear();
    }

    @Override
    protected void treatSlotRequest(SlotRequest request) {
        assert this.region.isInRegion(request.getAgent().getCoordinate());
        try {
            var localBestResponsePair = getSchedulingLogic().getBestSlot(request.getAgent());
            var localBestSlot = localBestResponsePair == null ? null : localBestResponsePair.second;

            if(localBestSlot != null) getSchedulingLogic().reserveSlot(localBestResponsePair);

            // should ask neighbors ? , postpone the response to the agent
            if(regionalSchedulerPredictor.shouldRequestNeighborsForSlot(localBestSlot, request.getAgent())){
                requestOtherRegionalSchedulers(request);
                if(localBestSlot != null) getSchedulingLogic().markSlotAsTemporary(localBestSlot, BADSLOT_TIMETOLIVE);
            }else{
                // no need to ask neighbors, respond to agents now
                var message = new SlotReservedMail(localBestSlot);
                addMessageToSendBuffer(request.getAgent(), message);
            }

        } catch (ScheduleNotFreeException e) {
            e.print();
        }
    }


    /**
     * Acknowledges that the given slot has been accepted. It makes the temporary slot definitive.
     */
    private void treatAckMessage(SchedulerSlotAck ack){
        getSchedulingLogic().markSlotAsDefinitive(ack.getSlot());
    }

    /**
     * Sends messages to other regional schedulers to request their best slot to this buffer.
     */
    private void requestOtherRegionalSchedulers(SlotRequest request){
        var schedulersToAsk = getNeighborsToAskForSlot(request);
        var bestLocal = getSchedulingLogic().getSlotThatHandlesRequest(request);

        schedulersToAsk.forEach(o-> addMessageToSendBuffer(o, new SchedulerSlotRequestMail(request, bestLocal, this)));
        expectedResponsesForSchedulerRequests.put(request, schedulersToAsk.size());
    }


    // NEIGHBORS

    /**
     * Returns the neighbors of this regional scheduler
     */
    private List<RegionalSchedulingEntity> getContactableSchedulingEntities(){
        return contactableSchedulingEntities;
    }

    /**
     * The list of neighbors this regional scheduling entity can contact.
     */
    private List<RegionalSchedulingEntity> contactableSchedulingEntities;

    /**
     * Returns a list of the neighbors this regionalScheduler must contact for transmitting the given request
     */
    private List<RegionalSchedulingEntity> getNeighborsToAskForSlot(SlotRequest request){
        int range = EnergyPredictor.getLongestMovementAutonomy((int) (request.getAgent().batteryState - (getNbTurns() - request.getAgent().turnNb) * EnergyPredictor.averageConsumptionPerTurn));

        var res = getContactableSchedulingEntities().stream().filter(o->o.getSchedulingLogic().hasEnergyStationAtDistance(range, request.getAgent().getCoordinate())).collect(Collectors.toList());
        return res;
    }


    // BUFFERS

    /**
     * The list of the acknowledgments this scheduler receives
     */
    private List<SchedulerSlotAck> slotAcks = new ArrayList<>();

    /**
     * The answers this scheduler receives from the neighbors
     */
    private Map<SlotRequest, List<Pair<SchedulingEntity, TimeSlot>>> schedulerAnswers = new HashMap<>();

    /**
     * A map representing how many answers are expected when asking other schedulers for a given request
     */
    private Map<SlotRequest, Integer> expectedResponsesForSchedulerRequests = new HashMap<>();

    /**
     * The received requests from the other schedulers
     */
    private List<SchedulerSlotRequestMail> schedulerSlotRequests = new ArrayList<>();

    /**
     * The time to live for a temporary bad slot.
     * This field is used when a bad slot is found by this schedule and how long it will live. If no better slot has been found, this slot would become persistent
     */
    private static final int BADSLOT_TIMETOLIVE = 5;

    /**
     * When a regional scheduler asks for a slot to another scheduler, the replier sends its best slot and saves it as a temporary slot.
     * This field represents the duration the replier saves the temporary slot.
     */
    private static final int SLOTRESPONSE_TIMETOLIVE = 3;

    private final Region region;

    // PREDICTOR
    private final RegionalSchedulerPredictor regionalSchedulerPredictor = new RegionalSchedulerPredictor();

    public void setContactableEntities(List<RegionalSchedulingEntity> worldSchedulingEntities) {
        contactableSchedulingEntities = new ArrayList<>(worldSchedulingEntities);
    }
}
