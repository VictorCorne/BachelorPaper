package agent.behavior.managingSystem.managingStrategy;

import agent.*;
import agent.behavior.*;
import agent.behavior.managingSystem.*;

/**
 * A management strategy details the manner of how the management-layer interacts with the managed layer.
 * This could be subtle as in adding a task to a schedule, or forceful as in fully taking over the managed behavior
 */
public abstract class ManagementStrategy {

    public ManagementStrategy(ManagementBehavior managementBehavior){
        this.managementBehavior = managementBehavior;
        setManagementBehavior(managementBehavior);
    }

    private ManagementBehavior managementBehavior;

    public ManagementBehavior getManagementBehavior() {
        return managementBehavior;
    }

    public Behavior getImplementedBehavior(){
        return managementBehavior.getImplementedBehavior();
    }

    public abstract void act(AgentImp agent);

    public void setManagementBehavior(ManagementBehavior managementBehavior) {
        if(managementBehavior == null) return;
        if(!canSetAsManagementBehavior(managementBehavior)) throw new RuntimeException("This managementStrategy cannot accept the given behavior");
        this.managementBehavior = managementBehavior;
    }

    protected boolean canSetAsManagementBehavior(ManagementBehavior managementBehavior){
        return true;
    }
}
