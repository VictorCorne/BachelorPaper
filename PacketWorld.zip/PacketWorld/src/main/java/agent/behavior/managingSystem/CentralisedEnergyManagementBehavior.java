package agent.behavior.managingSystem;

import agent.*;
import agent.behavior.schedule.*;
import environment.*;
import util.event.*;

import java.util.*;

/**
 * The centralised energy management behavior is a way to manage the energy-behavior by asking it to some centralised entity.
 */
public abstract class CentralisedEnergyManagementBehavior extends EnergyManagementBehavior {

    // ACTION
    @Override
    public void act(AgentImp agent) {
        handleMail(agent);

        // Managed behavior
        super.act(agent);
    }


    // INITS


    /**
     * This method is called at the very beginning of the run in order to prepare the environment for the simulation.
     * This is needed in order to allow the setup of the environment without modifying the simulator-files too much
     *
     * @param agent The agent that causes the setup. This field can be used to retrieve the environment and other useful fields
     */
    protected abstract void initialiseEnvironment(AgentImp agent);


    // SCHEDULERS
    protected abstract SchedulingEntity getScheduler(AgentImp agent);


    // SENDING MESSAGES

    @Override
    public void onShouldAskForSlot(AgentImp agent) {
        var mail = generateSlotRequestMail(agent);
        getScheduler(agent).receiveMessage(mail);
        agent.getEventBus().post(new MsgSentEvent(agent, mail));
    }

    @Override
    protected boolean shouldAskForSlot(AgentImp agent) {
        return super.shouldAskForSlot(agent) && getTimeSinceLastRequest(agent) >= 7;
    }

// RECEIVING MESSAGES

    /**
     * Reads this mail and acts accordingly
     * @note This mail has to be destined for this layer
     *       | isMailDestinedForThisLayer(mail) == true
     */
    private void handleMessage(Mail mail, AgentImp agent) {
        if(mail instanceof SlotReservedMail){
            receiveSlot(((SlotReservedMail) mail).getTimeSlot(), agent);
        }
    }

    /**
     * Reads all the mail that is in this agent's mailbox destined for this layer and acts accordingly. The treated messages
     * get cleared from the mailbox.
     */
    private void handleMail(AgentImp agent) {
        // Needed to copy to avoid problems with dynamically modifying the collection
        Collection<Mail> messagesCopy =  new ArrayList<>(agent.getMessages());
        for (Mail mail : messagesCopy){
            if(isMailDestinedForThisLayer(mail)){
                handleMessage(mail, agent);
                agent.removeMessage(mail);
            }
        }
    }

    private boolean isMailDestinedForThisLayer(Mail mail){
        return mail instanceof SlotReservedMail;
    }

    /**
     * Generates a message from this agent to be used in communication with the master
     * @return
     */
    protected final SlotRequestMail generateSlotRequestMail(AgentImp agent) {
        return new SlotRequestMail(new SlotRequest(agent));
    }
}
