package agent.behavior.managingSystem.communicationStrategy.informationSharing;

import agent.*;
import agent.behavior.schedule.*;
import environment.*;

import java.util.*;

public class SlotReservedNotification extends Mail {

    private final TimeSlot timeSlot;

    private final Coordinate sentFromCoordinate;
    private final int senderID;

    public SlotReservedNotification(TimeSlot timeSlot, AgentImp senderAgent) {
        super(List.of(timeSlot, senderAgent.getCoordinate()));
        this.timeSlot = timeSlot.clone();
        this.sentFromCoordinate = senderAgent.getCoordinate().clone();
        this.senderID = senderAgent.getID();
    }

    public TimeSlot getTimeSlot() {
        return timeSlot;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SlotReservedNotification that = (SlotReservedNotification) o;
        return timeSlot.equals(that.timeSlot);
    }

    @Override
    public int hashCode() {
        return Objects.hash(timeSlot);
    }

    public Coordinate getSentFromCoordinate() {
        return sentFromCoordinate;
    }

    public int getSenderID() {
        return senderID;
    }
}
