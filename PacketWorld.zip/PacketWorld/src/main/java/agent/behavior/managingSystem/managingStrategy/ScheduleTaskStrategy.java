package agent.behavior.managingSystem.managingStrategy;

import agent.*;
import agent.behavior.learning.movement.*;
import agent.behavior.managedSystem.*;
import agent.behavior.managingSystem.*;
import agent.behavior.schedule.*;
import agent.behavior.tasks.*;

import java.util.*;
import java.util.stream.*;

/**
 * This strategy is used for fulfilling the energy concern of the agents and consists of adding the chargingTasks as scheduledItems to the
 * implemented behavior who then self decides when to follow those tasks. This strategy is the most transparent and does the less work, but also has the highest
 * requirements to work correctly.
 *
 * This strategy requires that the implemented behavior possesses the needed logic to follow a schedule.
 */
public class ScheduleTaskStrategy extends EnergyManagementStrategy{

    public ScheduleTaskStrategy(ManagementBehavior managementBehavior) {
        super(managementBehavior);
    }

    @Override
    protected boolean canSetAsManagementBehavior(ManagementBehavior managementBehavior) {
        return super.canSetAsManagementBehavior(managementBehavior) && managementBehavior.getImplementedBehavior() instanceof ScheduleHolder;
    }

    @Override
    public List<TimeSlot> getAllSlots() {
        var scheduled = getScheduledBehavior().getScheduledTasks().stream().filter(o->o instanceof ChargeYourselfTask).map(o->o.getSlot()).collect(Collectors.toList());
        var tasks = getScheduledBehavior().getTasks().stream().filter(o->o instanceof ChargeYourselfTask).map(o-> ((ChargeYourselfTask) o).getSlot()).collect(Collectors.toList());
        tasks.removeAll(scheduled);
        scheduled.addAll(tasks);
        return scheduled;
    }



    @Override
    public boolean shouldBeMovingToStation(AgentImp agent) {
        return getScheduledBehavior().getCurrentTask() instanceof ChargeYourselfTask;
    }

    public ScheduleHolder getScheduledBehavior() {
        return (ScheduleHolder) getManagementBehavior().getImplementedBehavior();
    }

    @Override
    public void act(AgentImp agent) {
        // Does nothing, this strategy just schedules the task to the managed behavior and nothing else
        getImplementedBehavior().act(agent);
    }

    @Override
    public void receiveSlot(TimeSlot task, AgentImp agent) {
        getScheduledBehavior().addScheduledTask(new ChargeYourselfTask(task));
    }

    @Override
    public void removeSlot(TimeSlot toRemove, AgentImp agent) {
        getScheduledBehavior().removeScheduledTask(toRemove);
    }
}
