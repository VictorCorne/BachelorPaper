package agent.behavior.managingSystem;

import agent.*;
import agent.behavior.learning.*;
import agent.behavior.learning.movement.*;
import agent.behavior.learning.slotRequest.*;
import agent.behavior.managingSystem.managingStrategy.*;
import agent.behavior.tasks.*;
import agent.behavior.schedule.*;
import environment.*;
import util.event.*;

import java.util.*;
import java.util.stream.*;

/**
 * This is a behavior which is put on top of an existing behavior and manages all energy-related concerns
 */
public abstract class EnergyManagementBehavior extends ManagementBehavior {

    public EnergyManagementBehavior() {
        this(new ScheduleTaskStrategy(null));
    }

    public EnergyManagementBehavior(EnergyManagementStrategy energyManagementStrategy){
        super();
        if(getImplementedBehavior() instanceof LearnableBehavior) ((LearnableBehavior) getImplementedBehavior()).addPredictor(new EnergyPredictor());
        setManagementStrategy(energyManagementStrategy);
        getManagementStrategy().setManagementBehavior(this);
    }

    // MANAGEMENT STRATEGY
    public EnergyManagementStrategy getManagementStrategy(){
        return (EnergyManagementStrategy) super.getManagementStrategy();
    }

    // PREDICTOR

    /**
     * The learning module used for determining when to ask for slots
     */
    SlotRequesterPredictor slotRequesterPredictor = new SlotRequesterPredictor(this);

    public SlotRequesterPredictor getSlotRequesterPredictor() {
        return slotRequesterPredictor;
    }

    public void setSlotRequesterPredictor(SlotRequesterPredictor slotRequesterPredictor) {
        this.slotRequesterPredictor = slotRequesterPredictor;
    }


    // BASE METHODS
    @Override
    public void act(AgentImp agent) {
        // Needed to init the world without modifying the simulator files too much
        if(initCheck(agent)) return;

        avoidCollapsingWithPacketCheck(agent);

        // If the agent fell flat, signal it to its observers
        fellFlatCheck(agent);

        super.act(agent);
    }

    /**
     * A call to init the world. This is needed in order to instantiate the behaviors without changing the core files too much
     * Returns true if the turn is over
     */
    private boolean initCheck(AgentImp agent) {
        if (agent.getNbTurns() > 1) return false;

        if(agent.getID() == 1 && agent.getEnvironment().getEnergyStationWorld().getNbEnergyStations() != 0) initialiseEnvironment(agent);

        agent.getAgentMemory().retrieveAllItems(agent.getEnvironment().getEnergyStationWorld().getAllItems());
        agent.skip();
        return true;
    }

    protected abstract void initialiseEnvironment(AgentImp agent);

    @Override
    public void communicate(AgentImp agent) {
        if (shouldAskForSlot(agent)) {
            onShouldAskForSlot(agent);
            updateTimeLastAskedForSlot(agent.getNbTurns());
        }
        super.communicate(agent);
    }



    // ASKING ENERGY REQUESTS

    /**
     * Method called when the behavior desires to ask for a slot
     */
    public abstract void onShouldAskForSlot(AgentImp agent);

    protected boolean shouldAskForSlot(AgentImp agent) {
        return slotRequesterPredictor.shouldAskForSlot(agent) && getTimeSinceLastRequest(agent) >= 1;
    }

    // RECEIVING SLOTS
    protected void receiveSlot(TimeSlot receivedSlot, AgentImp agent){
        if(shouldAcceptSlot(receivedSlot)) {
            getManagementStrategy().addSlot(receivedSlot, agent);
            getEventBus(agent).post(new SlotReceivedEvent(this, agent, receivedSlot.clone()));
        }
    }

    public static boolean shouldAcceptSlot(TimeSlot receivedSlot) {
//        return ChargingPredictor.getMaximumChargeDeltaPercent(receivedSlot.getDuration()) >= 0.2d;
        return true;
    }


    protected final void cancelSlot(TimeSlot toRemove, AgentImp agent){
        getManagementStrategy().removeSlot(toRemove, agent);
        getEventBus(agent).post(new SlotCanceledEvent(this, agent, toRemove.clone()));
    }

    /**
     * Called when the given schedule has changed and this layer possibly needs to change the slots of the agent
     * @param schedule  The schedule that has changed.
     * @param agent     The agent this layer manages.
     */
    protected final void refreshScheduledPlans(Schedule schedule, AgentImp agent){
        cancelAllPlansToSchedule(schedule, agent);
        addAllSlotsOfSchedule(schedule, agent);
    }

    private boolean hasNoSlot(AgentImp agent) {
        return !getManagementStrategy().hasASlot(agent);
    }

    private void addAllSlotsOfSchedule(Schedule schedule, AgentImp agent) {
        assert Schedule.isValidSchedule(schedule);
        addAllSlots(schedule.getSlotsForAgentID(agent.getID()), agent);
    }

    private void addAllSlots(List<TimeSlot> slotsForAgent, AgentImp agent) {
        slotsForAgent.forEach(o-> receiveSlot(o, agent));
    }

    /**
     * Removes all the scheduled tasks that this agent has planned to the given schedule.
     */
    private void cancelAllPlansToSchedule(Schedule schedule, AgentImp agent){
        var slotsToLoc = getManagementStrategy().getAllSlots()
                .stream().filter(o->o.getDestination().equals(schedule.getLocation())).collect(Collectors.toList());
        slotsToLoc.forEach(o-> cancelSlot(o, agent));
    }

    // FALLING FLAT
    private Integer turnFellFlat = null;

    /**
     * If the agent is about to fall flat, this method makes sure it does not have any packet in its hands and it will make sure
     * not try to pick up packets anymore
     */
    private void avoidCollapsingWithPacketCheck(AgentImp agent) {
        if(agent.getBatteryState() <= EnergyValues.THRESHOLD_COLLAPSING_CHECK){
            new EmptyHandsTask().execute(agent);
            if(!agent.hasCommittedAction()) agent.skip();
        }
    }

    /**
     * Checks if the agent fell flat, and if so saves its turn when it fell flat and notifies its observers
     */
    private void fellFlatCheck(AgentImp agent) {
        if(!agent.hasEnergyLeft() && turnFellFlat == null){
            // Agent died
            turnFellFlat = agent.getNbTurns();
            observers.forEach(o->o.onAgentFellFlat(agent, turnFellFlat));
            if(hasAlreadyChargerSlot(agent)) livingStatus = LIVING_STATUS.DEATH_HAD_SLOT;
            else livingStatus = LIVING_STATUS.DEATH_NO_SLOT;

            if(environmentShouldRemoveDeadAgents)
                agent.getEnvironment().getAgentWorld().free(agent.getX(), agent.getY());

            getEventBus(agent).post(new AgentFellFlatEvent(this, agent, turnFellFlat, livingStatus == LIVING_STATUS.DEATH_HAD_SLOT, getManagementStrategy().shouldBeMovingToStation(agent)));
        }
    }

    // HELPER METHODS

    /**
     * Return true if the managed behavior already has a slot to its name
     * @param agent
     */
    public final boolean hasAlreadyChargerSlot(AgentImp agent){
        return getManagementStrategy().hasASlot(agent);
    }

    public boolean isMovingToStation(AgentImp agent) {
        return getManagementStrategy().shouldBeMovingToStation(agent);
    }

    public List<TimeSlot> getAllTimeSlots(){
        return getManagementStrategy().getAllSlots();
    }


    // LAST TIME WHEN ASKED FOR A SLOT

    /**
     * Returns the time that has passed since the last request for energy.
     * If no request has been made, the number of turns of this agent is returned
     */
    public int getTimeSinceLastRequest(AgentImp agent) {
        if (turnPreviousRequest == null) return agent.getNbTurns();
        return agent.getNbTurns() - turnPreviousRequest;
    }

    private void updateTimeLastAskedForSlot(int turnNb) {
        turnPreviousRequest = turnNb;
    }

    private Integer turnPreviousRequest = null;

    public TimeSlot getFirstScheduledItem() {
        return getManagementStrategy().getFirstSlot();
    }

    // ATTRIBUTES
    public static boolean environmentShouldRemoveDeadAgents = true;

    public enum LIVING_STATUS {LIVING, DEATH_NO_SLOT, DEATH_HAD_SLOT}
    public LIVING_STATUS livingStatus = LIVING_STATUS.LIVING;

}