package agent.behavior.managingSystem.communicationStrategy.informationSharing;

import agent.*;
import agent.behavior.learning.slotRequest.*;
import agent.behavior.managingSystem.*;
import agent.behavior.schedule.*;
import environment.*;

import java.util.*;
import java.util.function.*;
import java.util.stream.*;

/**
 * A factory used for priming the environment used in the information sharing
 */
public class InformationSharingFactory {

    /**
     * Primes the environment for use in the informationSharingBehavior.
     */
    public void initialise(Environment environment) {
        var behaviors = environment.getAgentImplementations().getAllAgentBehaviors().stream().map(o->(InformationSharingBehavior)o).collect(Collectors.toList());
        var allStations = environment.getAgentImplementations().getAllEnergyStations();
        for(InformationSharingBehavior behavior : behaviors){
            behavior.init(determineCommunicationRange(environment),
                          new EnergySchedulingLogic(allStations),
                          new SendMessageBuffer(environment));
            behavior.setSlotRequesterPredictor(new SlotRequesterPredictor(behavior));
            behavior.setSlotPriorityComparator(priorityComparator);
        }
    }

    /**
     * Determines the realistic communication range for use in the environment
     */
    private int determineCommunicationRange(Environment environment){
        return getCommunicationRangeFromView.apply(environment);
    }

    private final Function<Environment, Integer> getCommunicationRangeFromView = env -> 3 * env.getAgentWorld().getAgents().get(0).getView();
    private final Function<Environment, Integer> communicationRangeFromDensity = env -> (int) (2 * Math.sqrt(env.getWidth() * env.getHeight() / (double) env.getNbAgents()));
    private final Function<Environment, Integer> communicationRangeFixed = env -> 500;


    /**
     * The comparator that will be used to solve double booking.
     */
    public static Comparator<TimeSlot> priorityComparator = (o1, o2) -> {
        Comparator<TimeSlot>
                minAskTurn = Comparator.comparing(o -> - o.getAgentRepresentation().turnNb),
                minFromTurn = Comparator.comparing(o-> - o.getFromTurn()),
                energy = Comparator.comparing(o-> - o.getAgentRepresentation().batteryState),
                minDist = Comparator.comparing(o->o.getAgentRepresentation().getCoordinate().distance(o.getDestination())),
                random = Comparator.comparing(o->new Random(Math.max(o1.getAgentRepresentation().batteryState, o2.getAgentRepresentation().batteryState)).nextDouble()),
                hash = Comparator.comparing(o-> o.hashCode()),
                id = Comparator.comparing(o->o.getAgentRepresentation().agentID),
                duration = Comparator.comparing(o->o.getDuration());

        Comparator<TimeSlot> prio = minAskTurn.
                thenComparing(minFromTurn).
                thenComparing(energy).
                thenComparing(minDist).
                // If really the slots are equal, give up on logical decisions, and leave it up for random
                thenComparing(id);

        Comparator<TimeSlot> res;

        if(!getShouldAcceptPredicate().test(o1) || !getShouldAcceptPredicate().test(o2)) res = duration.thenComparing(prio);
        else res = prio;

        return res.compare(o1, o2);
    };

    static private Predicate<TimeSlot> getShouldAcceptPredicate(){
        return o -> EnergyManagementBehavior.shouldAcceptSlot(o);
    }
}
