package agent.behavior.managingSystem.managingStrategy;

import agent.*;
import agent.behavior.managingSystem.*;
import agent.behavior.schedule.*;
import environment.*;

import java.util.*;

public abstract class EnergyManagementStrategy extends ManagementStrategy{

    public EnergyManagementStrategy(ManagementBehavior managementBehavior) {
        super(managementBehavior);
    }
    
    public boolean hasASlot(AgentImp agent){
        return !getAllSlots().isEmpty();
    }

    public abstract List<TimeSlot> getAllSlots();

    public abstract boolean shouldBeMovingToStation(AgentImp agent);

    protected abstract void receiveSlot(TimeSlot task, AgentImp agent);

    public final void addSlot(TimeSlot slot, AgentImp agent){
        if(getAllSlots().contains(slot)) return;
        receiveSlot(slot, agent);
    }

    public abstract void removeSlot(TimeSlot toRemove, AgentImp agent);

    public final boolean hasSlotAtLocationTime(Coordinate coordinate, int turnNb){
        return getAllSlots().stream().anyMatch(o-> o.getDestination().equals(coordinate) && o.isTurnInSlot(turnNb));
    }

    public TimeSlot getFirstSlot() {
        return getAllSlots().stream().min(Comparator.comparing(o -> o.getFromTurn())).orElse(null);
    }
}
