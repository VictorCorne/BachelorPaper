package agent.behavior.managingSystem.communicationStrategy.regionalPlannerBehavior;

import agent.*;
import agent.behavior.schedule.*;
import environment.*;
import util.communicationHelper.*;

import java.util.*;

/**
 * This mail is used for responding to the requests originating from a regional scheduler to another
 */
public class SchedulerSlotAnswerMail extends Mail {

    public final TimeSlot response;
    /**
     * The request that has been answered by the scheduler
     */
    public final SlotRequest request;
    public final SchedulingEntity sender;

    /**
     * Creates an answer-mail containing the given response to the request, sent by the given sender
     */
    public SchedulerSlotAnswerMail(TimeSlot response, SlotRequest request, SchedulingEntity sender) {
        super(response != null ? List.of(response, request) : List.of(request));
        this.response = response;
        this.request = request;
        this.sender = sender;
    }
}
