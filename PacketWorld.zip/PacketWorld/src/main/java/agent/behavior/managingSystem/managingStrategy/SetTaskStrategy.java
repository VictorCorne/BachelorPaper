package agent.behavior.managingSystem.managingStrategy;

import agent.*;
import agent.behavior.learning.*;
import agent.behavior.learning.movement.*;
import agent.behavior.managedSystem.*;
import agent.behavior.managingSystem.*;
import agent.behavior.schedule.*;
import agent.behavior.tasks.*;

import java.util.*;
import java.util.stream.*;

/**
 * This strategy is used for fulfilling the energy concern of the agents. When this strategy deems it necessary for the agent to go to the schedule, it will tell the
 * behavior to start this task, but it will not take control of the agent. It is the base behavior who will take the matter in own hands when it comes to moving to the
 * task.
 *
 * This requires that the implemented behavior is able to follow tasks.
 */
@Deprecated
public class SetTaskStrategy extends EnergyManagementStrategy implements ScheduleHolder {

    // CONSTRUCTOR
    public SetTaskStrategy(ManagementBehavior managementBehavior) {
        super(managementBehavior);
    }

    @Override
    protected boolean canSetAsManagementBehavior(ManagementBehavior managementBehavior) {
        return super.canSetAsManagementBehavior(managementBehavior) && managementBehavior.getImplementedBehavior() instanceof TaskHolder;
    }

    // IMPLEMENTING ABSTRACT METHODS

    @Override
    public List<TimeSlot> getAllSlots() {
        var a = getTaskBehavior().getTasks().stream().filter(o-> o instanceof ChargeYourselfTask).map(o->((ChargeYourselfTask) o).getSlot()).collect(Collectors.toList());
        var b = chargeTasks.stream().map(o->o.getSlot()).collect(Collectors.toList());
        a.addAll(b);
        return a;
    }

    @Override
    public boolean shouldBeMovingToStation(AgentImp agent) {
        return getTaskBehavior().getCurrentTask() instanceof ChargeYourselfTask;
    }

    @Override
    public void act(AgentImp agent) {
        addTaskCheck(agent);
        getImplementedBehavior().act(agent);
    }

    // HELPER METHODS

    public TaskHolder getTaskBehavior() {
        return (TaskHolder) getImplementedBehavior();
    }

    /**
     * If this behavior deems it necessary to add the charging task to the base behavior, it will do so, and will remove it from the planned tasks
     */
    private void addTaskCheck(AgentImp agent){
        if(chargeTasks.get(0).shouldGoToSchedule(agent, getPredictors())){
            var task = chargeTasks.remove(0);
            getTaskBehavior().addTask((Task) task);
        }
    }

    // PREDICTORS
    private EnergyPredictor energyPredictor = new EnergyPredictor();
    private MovementPredictor movementPredictor = new MovementPredictor();
    private final List<Predictor> getPredictors(){
        return List.of(energyPredictor, movementPredictor);
    }
    
    // TASKS

    @Override
    public void receiveSlot(TimeSlot task, AgentImp agent) {
        chargeTasks.add(new ChargeYourselfTask(task));
        chargeTasks.sort(Comparator.comparing(o -> o.getSlot().getFromTurn()));
    }

    private final List<TemporalTask> chargeTasks = new ArrayList<>();

    @Override
    public List<TemporalTask> getScheduledTasks() {
        return chargeTasks;
    }

    @Override
    public Stack<Task> getTasks() {
        return getTaskBehavior().getTasks();
    }

    @Override
    public void removeSlot(TimeSlot toRemove, AgentImp agent) {
        chargeTasks.remove(new ChargeYourselfTask(toRemove));
    }
}
