package agent.behavior.managingSystem.communicationStrategy.informationSharing;

import agent.*;
import agent.behavior.schedule.*;
import environment.*;

import java.util.*;
import java.util.stream.*;

/**
 * A container class used for helping to decide which agents should be receiving the information
 */
public class SlotReceivedDataContainer {
    public final AgentImp receiverAgent;
    public final List<SlotReservedNotification> receivedFromAgents;
    public final TimeSlot slot;

    public SlotReceivedDataContainer(AgentImp receiverAgent, List<SlotReservedNotification> receivedFromAgents, TimeSlot slot) {
        this.receiverAgent = receiverAgent;
        this.receivedFromAgents = receivedFromAgents;
        this.slot = slot;
    }

    public List<Coordinate> getSenders(){
        return receivedFromAgents.stream().map(o->o.getSentFromCoordinate()).collect(Collectors.toList());
    }
}
