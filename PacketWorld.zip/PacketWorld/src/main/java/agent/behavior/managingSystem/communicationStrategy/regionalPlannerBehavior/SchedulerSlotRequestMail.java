package agent.behavior.managingSystem.communicationStrategy.regionalPlannerBehavior;

import agent.*;
import agent.behavior.schedule.*;
import environment.*;

import java.util.*;

/**
 * The mail representing the request of a scheduler to get a slot
 */
public class SchedulerSlotRequestMail extends Mail {

    public SchedulerSlotRequestMail(SlotRequest request, TimeSlot senderBestProposal, SchedulingEntity sendingScheduler) {
        super(new ArrayList<>() {{
            add(request);
            add(senderBestProposal);
        }});
        this.request = request;
        this.sender = sendingScheduler;
        this.senderBestProposal = senderBestProposal;
    }

    final private SlotRequest request;

    final private SchedulingEntity sender;

    private final TimeSlot senderBestProposal;

    public SchedulingEntity getSender() {
        return sender;
    }

    public SlotRequest getRequest() {
        return request;
    }

    public TimeSlot getSenderBestProposal() {
        return senderBestProposal;
    }
}
