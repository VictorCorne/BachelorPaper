package agent.behavior.managingSystem.communicationStrategy.informationSharing;

import agent.*;
import agent.behavior.learning.movement.*;
import agent.behavior.managingSystem.*;
import agent.behavior.schedule.*;
import environment.*;
import util.*;
import util.event.*;

import java.util.*;
import java.util.function.*;
import java.util.stream.*;

/**
 * The informationSharingBehavior is a decentralised manner in which agents coordinate themselves for allocating chargerSlots via the information sharing pattern
 */
public class InformationSharingBehavior extends EnergyManagementBehavior {

    // OVERRIDDEN METHODS
    
    @Override
    public void act(AgentImp agent) {
        if(initialised){
            treatMessages(agent);
            energySchedulingLogic.update(agent.getNbTurns());
            notificationMemory.update(agent.getNbTurns());
        }

        super.act(agent);
    }

    @Override
    public void communicate(AgentImp agent) {
        if(initialised) toSendBuffer.sendBuffer();
        super.communicate(agent);
    }
    
    // INITIALISATION

    @Override
    protected void initialiseEnvironment(AgentImp agent) {
        new InformationSharingFactory().initialise(agent.getEnvironment());
    }

    /**
     * Initialises this informationSharingBehavior with the given fields
     */
    public void init(int communicationRange, EnergySchedulingLogic schedulingLogic, SendMessageBuffer sendMessageBuffer){
        this.communicationRadius = communicationRange;
        this.energySchedulingLogic = schedulingLogic;
        this.toSendBuffer = sendMessageBuffer;
        initialised = true;
    }

    private boolean initialised = false;


    // ASKING SLOTS

    /**
     * When this agent deems it necessary to book a slot, this method is called.
     */
    @Override
    public void onShouldAskForSlot(AgentImp agent) {
        if(!initialised) return;
        try {
            var bestSlot = energySchedulingLogic.reserveBestSlotForAgent(agent);
            receiveSlot(bestSlot, agent);
            signalOtherAgentsOfSlotBooking(bestSlot, agent);
        } catch (NoSlotAvailableException e) {
            // too bad, agent cannot reach any slot
            getEventBus(agent).post(new NoSlotAvailableEvent(this, agent));
        }
    }

    // MAIL HANDLING

    /**
     * Treats all the messages destined for this layer and removes them from the agent's mailbox
     */
    private void treatMessages(AgentImp agent){
        var thisLayerMessages =
                agent.getMessages().stream().filter(o->o instanceof SlotReservedNotification).map(o->(SlotReservedNotification)o).collect(Collectors.toList());
        var incomingMailsMap = sortMessages(thisLayerMessages);

        for (Map.Entry<TimeSlot, List<SlotReservedNotification>> entry : incomingMailsMap.entrySet())
            treatSlotReservedNotification(agent, entry.getKey(), entry.getValue());

        agent.removeMessages(thisLayerMessages);
    }

    /**
     * Called when this agent receives a mail from other agents that a given slot has been reserved.
     */
    private void treatSlotReservedNotification(AgentImp agent, TimeSlot timeSlot, List<SlotReservedNotification> notifications){
        notifyMemoryOfSlotReservedNotification(agent, timeSlot, notifications);
        addSlotToSchedule(timeSlot);

        Schedule schedule = energySchedulingLogic.getScheduleForChargingField(timeSlot.getDestination());
        refreshScheduledPlans(schedule, agent);

        if(!notificationMemory.hasAlreadySpreadNotification(timeSlot))
            spreadBookingInformationFurther(agent, timeSlot, notifications);
    }

    public void addSlotToSchedule(TimeSlot timeSlot) {
        try {
            energySchedulingLogic.reserveSlotForChargerAt(timeSlot.getDestination(), timeSlot);
        } catch (ScheduleNotFreeException e) {
            /* A conflict has happened */
            resolveSlotConflict(timeSlot);
        } catch (NoChargerPresentAtLocationException e) {
            /* should never happen */
            e.printStackTrace();
        }
    }

    public List<BatterySchedule> getPercievedSchedule(){
        return energySchedulingLogic.getBatterySchedules();
    }


    /**
     * Notifies this memory that the given notifications have been received.
     * Adds to the memory all agents that should have been reached by the slot.
     *
     * @param agent The agent this layer manages
     * @param slot  The timeslot that has been reserved
     * @param notifications All the notifications this agent has received this turn
     */
    private void notifyMemoryOfSlotReservedNotification(AgentImp agent, TimeSlot slot, List<SlotReservedNotification> notifications) {
        var mustKnowers = getCommunicationReachableAgents(agent, agent.getEnvironment().getAgentImplementations()).stream().
                filter(o->hasNotificationAlreadyReachedAgent.test(new Pair<>(o, new SlotReceivedDataContainer(agent, notifications, slot)))).collect(Collectors.toList());

        mustKnowers.forEach(o->notificationMemory.addAgentKnows(slot, o.getID()));
        notifications.forEach(o->notificationMemory.addAgentKnows(slot, o.getSenderID()));
    }

    /**
     * Sorts the given notifications to a map where the key is representing the timeslot that is being shared and the value represents the senders from which this slot has
     * been received.
     */
    private Map<TimeSlot, List<SlotReservedNotification>> sortMessages(List<SlotReservedNotification> notifications) {
        Map<TimeSlot, List<SlotReservedNotification>> res = new HashMap<>();

        for (SlotReservedNotification msg : notifications) {
            var entries = res.get(msg.getTimeSlot());
            if(entries == null){
                res.put(msg.getTimeSlot(), new ArrayList<>(){{add(msg);}});
            }else {
                entries.add(msg);
            }
        }

        return res;
    }

    // SPREADING INFORMATION

    /**
     * This method adds messages to the outputbuffer to signal other agents that this agent reserved his slot
     */
    private void signalOtherAgentsOfSlotBooking(TimeSlot slot, AgentImp thisAgent){
        var toShare = getAgentsToShareBookingInformation(thisAgent, thisAgent.getEnvironment().getAgentImplementations());
        toShare.forEach(o -> toSendBuffer.addMessage(o, new SlotReservedNotification(slot, thisAgent)));
        toShare.forEach(o -> notificationMemory.addAgentKnows(slot, o.getID()));
        notificationMemory.addHasSpreadInformation(slot);
    }

    /**
     * Adds all the booking information of the slot to the output buffer
     */
    private void spreadBookingInformationFurther(AgentImp agent, TimeSlot slot, List<SlotReservedNotification> notifications){
        var agentImps = agent.getEnvironment().getAgentImplementations();

        var toShare = getAgentsToSpreadBookingInformationFurther(agent, notifications, agentImps);

        var notif = new SlotReservedNotification(slot, agent);
        toShare.forEach(o -> toSendBuffer.addMessage(o, notif));
        toShare.forEach(o -> notificationMemory.addAgentKnows(slot, o.getID()));
        notificationMemory.addHasSpreadInformation(slot);
    }

    /**
     * When reserving a slot, those agents will be the ones that this behavior will share the information with.
     * Those agents may or may not spread the information further.
     *
     * @param agent The agent that just reserved the slot
     * @param agentImplementations the other agents in the environment
     */
    private List<AgentImp> getAgentsToShareBookingInformation(AgentImp agent, AgentImplementations agentImplementations){
        return getCommunicationReachableAgents(agent, agentImplementations);
    }

    /**
     * When this agent receives a notification that a slot has been reserved by another agent, this method will return the agents to which this behavior will share the
     * information with
     */
    private List<AgentImp> getAgentsToSpreadBookingInformationFurther(AgentImp agent, List<SlotReservedNotification> notifications, AgentImplementations agentImplementations){
        assert notifications.size() >= 1;
        return getCommunicationReachableAgents(agent, agentImplementations).stream().
                filter(o-> shouldSpreadToAgentPredicate.test(new Pair<>(o,new SlotReceivedDataContainer(agent, notifications, notifications.get(0).getTimeSlot())))).
                collect(Collectors.toList());
    }

    /**
     * Returns all the other agents this agent can communicate to.
     */
    private List<AgentImp> getCommunicationReachableAgents(AgentImp thisAgent, AgentImplementations agentImplementations){
        var res = agentImplementations.getAllAgentsWithinRange(thisAgent.getCoordinate(), getCommunicationRadius());
        res.remove(thisAgent);
        return res;
    }

    // SCHEDULE
    private EnergySchedulingLogic energySchedulingLogic;

    public void setEnergySchedulingLogic(EnergySchedulingLogic energySchedulingLogic){
        this.energySchedulingLogic =energySchedulingLogic;
    }

    private EnergySchedulingLogic getEnergySchedulingLogic() {
        return energySchedulingLogic;
    }


    // LOGIC FOR CONFLICT HANDLING

    /**
     * When this behavior tries to add a slot to its schedule, and the schedule signals it is not free, this method is called to resolve the conflict.
     */
    private void resolveSlotConflict(TimeSlot toAddSlot){
        assert toAddSlot != null;
        var schedule = energySchedulingLogic.getScheduleForChargingField(toAddSlot.getDestination());
        schedule.addSlotWithRules(toAddSlot, getOverwritePredicate(toAddSlot), getToDeletePredicate());
        assert Schedule.isValidSchedule(schedule);
    }

    // PREDICATES FOR COMMUNICATION

    private final Predicate<Pair<AgentImp, SlotReceivedDataContainer>> couldAgentReachSlotBeforeStart = pair->{
        var agent = pair.first;
        var notif = pair.second.slot;
        var agentCoordinate = agent.getCoordinate();

        int estimatedTurnsToMove = MovementPredictor.getEstimatedNbTurnsToMove(agentCoordinate, notif.getDestination());
        int timeUntilStart = notif.getFromTurn() - agent.getNbTurns();

        return timeUntilStart >= estimatedTurnsToMove;
    };

    private final Predicate<Pair<AgentImp, SlotReceivedDataContainer>> hasNotificationAlreadyReachedAgent = pair -> {
        var testHasReceived = pair.first;
        List<Coordinate> senderCoords = pair.second.getSenders();

        if(pair.second.receivedFromAgents.stream().anyMatch(o->o.getSenderID() == testHasReceived.getID())) return true;

        return testHasReceived.getCoordinate().minDistance(senderCoords) <= (getCommunicationRadius() - 2);
    };

    private final Predicate<Pair<TimeSlot, Integer>> isAgentPresumedToKnowNotification = pair -> {
        return getNotificationMemory().doesAgentKnowAboutNotification(pair.first, pair.second);
    };

    private final Predicate<TimeSlot> hasAlreadySpreadNotification = slot -> getNotificationMemory().hasAlreadySpreadNotification(slot);

    private final Predicate<Pair<AgentImp, SlotReceivedDataContainer>> shouldSpreadToAgentPredicate = pair -> {
        return couldAgentReachSlotBeforeStart.test(pair)
                && !isAgentPresumedToKnowNotification.test(new Pair<>(pair.second.slot, pair.first.getID()))
                && !this.hasAlreadySpreadNotification.test(pair.second.slot);
    };

    // PREDICATES FOR CONFLICT HANDLING

    /**
     * The comparator that is used to solve double booking by returning which slot should overwrite the other
     */
    private Comparator<TimeSlot> slotPriorityComparator;

    public void setSlotPriorityComparator(Comparator<TimeSlot> slotPriorityComparator) {
        this.slotPriorityComparator = slotPriorityComparator;
    }

    /**
     * The predicate used in the conflict-solving proces to remove overwritten slots
     */
    private Predicate<TimeSlot> getToDeletePredicate() {
        return o -> false;
    }

    /**
     * The predicate used for solving conflicts when a slot tries to overwrite another
     */
    Predicate<TimeSlot> getOverwritePredicate(TimeSlot toAdd){
        return slot -> slotPriorityComparator.compare(slot.clone(), toAdd.clone()) < 0;
    }

    // COMMUNICATION ATTRIBUTES

    /**
     * The outputBuffer this behavior has to queue up messages to send in its next communication phase
     */
    private SendMessageBuffer toSendBuffer;

    private int communicationRadius;

    public int getCommunicationRadius() {
        return communicationRadius;
    }

    private NotificationMemory notificationMemory = new NotificationMemory();

    private NotificationMemory getNotificationMemory() {
        return notificationMemory;
    }
}