package agent.behavior.tasks;

import agent.*;
import agent.behavior.learning.*;
import agent.behavior.learning.movement.*;
import agent.behavior.schedule.*;
import environment.*;
import environment.world.agent.*;
import util.communicationHelper.*;

import java.util.*;

public class GatherTask extends Task implements TemporalTask {

    @Override
    public int getCommunicationSize() {
        int size = super.getCommunicationSize();
        size += (int) Math.log(2) / Math.log(gatherModes.values().length);
        size += slot.getCommunicationSize();
        size += 2 * CommunicationValues.BYTESIZE;
        return size;
    }

    // CONSTRUCTOR
    public GatherTask(TimeSlot slot,
                      int acceptableRangeFromGoal,
                      GatherTask.gatherModes gatherMode,
                      int turnsBeforeCanEnter,
                      int rangeCannotEnterBeforeBegin) {
        super(slot.getDestination(), acceptableRangeFromGoal, false, false);
        this.gatherMode = gatherMode;
        this.slot = slot;
        this.turnsBeforeCanEnter = turnsBeforeCanEnter;
        this.rangeCannotEnterBeforeBegin = rangeCannotEnterBeforeBegin;
    }

    /**
     * Specifies the code that is run each turn for the agent.
     *
     * If the agent is close enough to the gather-point but is unable to move into it, it will let the agent skip a turn
     * If the agent is at the task location, it will wait until it is done gathering
     */
    @Override
    public void execute(AgentImp agent) {
        // The agent cannot enter the gathering-point but is close to the area
        // The agent shall skip a turn
        if(isOnFrontierOfGatherPoint(agent) && !canAgentEnter(agent)) {
            agent.skip();
            return;
        }

        // The agent is gathering, let it gather
        if(isAtGatherPoint(agent.getCoordinate()) && !isFinished(agent)) {
            agent.skip();
            return;
        }
    }

    private boolean isAtGatherPoint(Coordinate coordinate) {
        return coordinate.equals(taskLocation);
    }

    @Override
    public boolean isFinished(AgentImp agent) {
        return finishedGathering(agent);
    }

    // GATHERING

    /**
     * An enum dictating how strict the agents have to stick to their schedule.
     *
     * CONTINUE = the agent continues to charge itself until it is done, regardless if other agents are waiting
     * POLITE = the agent charges as much as it can, but it will give up its slot if its duration is done and another agent is waiting
     * STRICT = the agent will leave its slot on time, regardless of its charge level
     */
    public enum gatherModes {CONTINUE, POLITE, STRICT}
    final gatherModes gatherMode;
    public final static gatherModes defaultMode = gatherModes.POLITE;


    int rangeCannotEnterBeforeBegin;
    int turnsBeforeCanEnter;


    protected boolean finishedGathering(AgentImp agent){
        switch (gatherMode) {
            case CONTINUE:
                return false;
            case POLITE:
                return otherAgentWaitingForThisSlot(agent) && slot.endsBefore(agent.getNbTurns());
            case STRICT:
                return slot.endsBefore(agent.getNbTurns());
        }
        return true;
    }

    /**
     * A boolean indicating if there's another living agent waiting next to this scheduled item at a neighboring coordinate
     */
    protected boolean otherAgentWaitingForThisSlot(AgentImp agent){
        Perception per = agent.getPerception();
        for (Coordinate c : Coordinate.getNeighborsShuffled())
            try {
                AgentRep repOther = per.getCellPerceptionOnAbsPos(taskLocation.add(c)).getAgent();
                AgentImp other = agent.getEnvironment().getAgentImplementations().getAgentImp(repOther.getID());
                // The other agent has to have energy left
                if (agent != other && other.hasEnergyLeft()) return true;
            }catch (Exception ignored){}
        return false;
    }

    public boolean isOnFrontierOfGatherPoint(AgentImp agent){
        return agent.getCoordinate().distance(getTaskLocation()) == rangeCannotEnterBeforeBegin;
    }

    /**
     * Returns true if the agent can move to the gathering-point (ie close in time and the cell is walkable)
     */
    public boolean canAgentEnter(AgentImp agent) {
        try {
            int turnsBefore = getSlot().getFromTurn() - agent.getNbTurns();
            boolean soonEnough = turnsBefore <= turnsBeforeCanEnter;
            boolean walkable = agent.getPerception().getCellPerceptionOnAbsPos(getTaskLocation()).isWalkable();
            return  soonEnough && walkable;
        }catch (NullPointerException e){
            // Happens when the task location is not visible
            return false;
        }
    }

    // SLOT
    private final TimeSlot slot;

    @Override
    public TimeSlot getSlot() {
        return slot;
    }

    @Override
    public boolean shouldGoToSchedule(AgentImp agentImp, List<Predictor> predictors) {
        MovementPredictor predictor = (MovementPredictor) Predictor.getPredictorOfType(predictors, MovementPredictor.class);
        return predictor.shouldStartFollowScheduledTask(agentImp, this, predictors);
    }
}
