package agent.behavior.tasks;

import agent.*;
import agent.behavior.learning.*;
import agent.behavior.learning.movement.*;
import agent.behavior.managedSystem.*;
import agent.behavior.schedule.*;
import environment.*;
import environment.world.energystation.*;

import java.util.*;

public class ChargeYourselfTask extends GatherTask {

    private int chargeToLevel = EnergyValues.BATTERY_SAFE_MAX;

    public ChargeYourselfTask(TimeSlot slot) {
        this(slot, gatherModes.STRICT, 0, 1);
    }

    public ChargeYourselfTask(TimeSlot slot, gatherModes gatherMode, int turnBeforeCanEnter, int rangeCannotEnterBeforeBegin) {
        super(slot, 0, gatherMode, turnBeforeCanEnter, rangeCannotEnterBeforeBegin);
    }

    @Override
    public boolean shouldGoToSchedule(AgentImp agentImp, List<Predictor> predictors) {
        EnergyPredictor energyPredictor = (EnergyPredictor) Predictor.getPredictorOfType(predictors, EnergyPredictor.class);
        return super.shouldGoToSchedule(agentImp, predictors) || energyPredictor.shouldStartFollowScheduledTask(agentImp, this, predictors) || MovementPredictor.shouldStartFollowingScheduledTaskByTime(new AgentRepresentation(agentImp), this);
    }

    public boolean shouldGoToSchedule(AgentRepresentation agent){
        return MovementPredictor.shouldStartFollowingScheduledTaskByTime(agent, this) || EnergyPredictor.shouldStartFollowingScheduledTaskByEnergy(agent, this);
    }

    @Override
    public Class getItemClassForTask() {
        return EnergyStationRep.class;
    }

    /**
     * When the task of charging one self has been decided to be followed, we want the agent to start dropping its packet (if
     * it carried any). This overridden method adds the task to empty the hands of the agent to the behavior
     */
    @Override
    public void onStartFollowTask(TaskHolder behavior, AgentImp agent) {
        super.onStartFollowTask(behavior, agent);
        if(agent.hasCarry()) behavior.addTask(new EmptyHandsTask());
    }

    @Override
    public boolean isFinished(AgentImp agent) {
        return super.isFinished(agent) || (agent.getBatteryState() >= chargeToLevel && getSlot().getToTurn() < agent.getNbTurns());
    }
}
