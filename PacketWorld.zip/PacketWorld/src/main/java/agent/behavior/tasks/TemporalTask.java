package agent.behavior.tasks;

import agent.*;
import agent.behavior.learning.*;
import agent.behavior.managedSystem.*;
import agent.behavior.schedule.*;

import java.util.*;

/**
 * A temporal task is a task that must be done within a certain time frame at a given location
 */
public interface TemporalTask {

    TimeSlot getSlot();

    /**
     * A boolean indicating if the agent must start following the schedule
     * @param agentImp  The agent we want to know if it has to follow the schedule
     * @param predictors The predictors needed to know if it is needed to follow the task
     * @return true iff the agent must add this task to its planning now
     */
    boolean shouldGoToSchedule(AgentImp agentImp, List<Predictor> predictors);

    /**
     * Called when it has been decided to follow this temporal task.
     */
    default void onStartFollowTask(TaskHolder behavior, AgentImp agentImp){}
}