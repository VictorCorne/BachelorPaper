package agent.behavior.tasks;

import agent.*;
import environment.*;
import environment.world.destination.*;

public class DeliverPacketTask extends Task{

    public DeliverPacketTask(Coordinate taskLocation) {
        super(taskLocation, 1, true, false);
    }

    @Override
    public void execute(AgentImp agent) {
        deliverPacket(agent);
    }

    /**
     * Makes the agent try to deliver the packet on a station in its immediate neighboring coordinates
     */
    private void deliverPacket(AgentImp agent) {
        if(agent.hasCarry()){
            // Iter trough all neighbouring cells to deliver the packet if possible
            for (Coordinate c : Coordinate.getNeighborsShuffled()) {
                try {
                    int x = agent.getCoordinate().add(c).getX();
                    int y = agent.getCoordinate().add(c).getY();
                    if (agent.getPerception().getCellPerceptionOnAbsPos(x,y).containsDestination(agent.getCarry().getColor())) {
                        agent.putPacket(x,y);
                        return;
                    }} catch (NullPointerException ignored) {}
            }
        }
    }

    @Override
    public Class getItemClassForTask() {
        return DestinationRep.class;
    }

    @Override
    public boolean isFinished(AgentImp agent) {
        return !agent.hasCarry();
    }
}
