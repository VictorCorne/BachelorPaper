package agent.behavior.tasks;

import agent.*;
import environment.*;

import java.util.stream.*;

public class EmptyHandsTask extends Task {

    public EmptyHandsTask() {
        super(null, Integer.MAX_VALUE, true, true);
    }

    @Override
    public void execute(AgentImp agent) {
        dropOrDeliverPacketNow(agent);
    }

    /**
     * Orders the agent to drop the packet he has in hands now.
     * It will try to deposit it in a destination or (if it isn't possible) it will try to drop it on a place where it shouldn't interfere with other agents too much
     */
    protected void dropOrDeliverPacketNow(AgentImp agent) {
        if (!agent.hasCarry()) return;
        // Deposit on destination if possible
        var destinations = agent.getCoordinate().getAbsoluteNeighborsShuffled().stream().
                filter(o -> o.isInWorldBounds(agent.getEnvironment())).
                filter(o -> agent.getPerception().getCellPerceptionOnAbsPos(o).containsDestination(agent.getCarry().getColor())).
                collect(Collectors.toList());
        for (Coordinate nb : destinations){
            agent.putPacket(nb.getX(), nb.getY());
            return;
        }
        // Deposit on a tile that isn't a charger
        for (Coordinate nb : agent.getCoordinate().getAbsoluteNeighborsShuffled().stream().
                filter(o->o.isInWorldBounds(agent.getEnvironment()) && o.add(0,1).isInWorldBounds(agent.getEnvironment())).
                filter(o->!agent.getPerception().getCellPerceptionOnAbsPos(o).containsEnergyStation() && !agent.getPerception().getCellPerceptionOnAbsPos(o.add(0,1)).containsEnergyStation()).
                collect(Collectors.toList())){
            agent.putPacket(nb.getX(), nb.getY());
            return;
        }
        // Deposit anywhere
        for (Coordinate nb : Coordinate.getNeighborsShuffled())
            try {
                agent.putPacket(nb.getX(), nb.getY());
                return;
            } catch (Exception ignored) {}
    }

    @Override
    public Class getItemClassForTask() {
        return null;
    }

    @Override
    public boolean isFinished(AgentImp agent) {
        return !agent.hasCarry();
    }
}
