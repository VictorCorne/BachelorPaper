package agent.behavior.tasks;

import agent.*;
import environment.*;
import util.communicationHelper.*;

public class WaitTask extends Task{
    final int waitDuration;
    int timeWaited;

    public WaitTask(Coordinate location, int range, int waitDuration) {
        super(location, range, false, true);
        this.waitDuration = waitDuration;
    }

    public WaitTask(Coordinate taskLocation, int acceptableRangeFromGoal, boolean isLocationUpdatable, boolean imperativeTask, int waitDuration) {
        super(taskLocation, acceptableRangeFromGoal, isLocationUpdatable, !imperativeTask);
        this.waitDuration = waitDuration;
    }

    @Override
    public void execute(AgentImp agent) {
        tryAddTimeWaited(agent);
    }

    @Override
    public Class getItemClassForTask() {
        return null;
    }

    public void tryAddTimeWaited(AgentImp agent){
        if(isAgentAtSkippingRangeOfGoal(agent)) timeWaited++;
    }

    @Override
    public boolean isFinished(AgentImp agent) {
        return timeWaited >= waitDuration;
    }

    @Override
    public int getCommunicationSize() {
        return super.getCommunicationSize() + CommunicationValues.INTSIZE;
    }
}
