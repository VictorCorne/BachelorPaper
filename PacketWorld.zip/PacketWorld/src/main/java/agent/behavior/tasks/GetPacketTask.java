package agent.behavior.tasks;

import agent.*;
import environment.*;
import environment.world.packet.*;
import util.communicationHelper.*;

import java.awt.*;

public class GetPacketTask extends Task{

    private final Color packetColor;

    public GetPacketTask(Coordinate taskLocation, Color color) {
        super(taskLocation, 1, true, false);
        this.packetColor = color;
    }

    @Override
    public void execute(AgentImp agent) {
        pickUpNeighboringPacket(agent);
    }

    private void pickUpNeighboringPacket(AgentImp agent) {
        if(!agent.hasCarry()){
            for (Coordinate c : Coordinate.getNeighborsShuffled())
                try {
                    int x = agent.getCoordinate().add(c).getX();
                    int y = agent.getCoordinate().add(c).getY();
                    if (agent.getPerception().getCellPerceptionOnAbsPos(x, y).containsPacket()) {
                        agent.pickPacket(x, y);
                        return;
                    }
                } catch (NullPointerException ignored) {}
        }
    }

    @Override
    public Class getItemClassForTask() {
        return PacketRep.class;
    }

    @Override
    public boolean isFinished(AgentImp agent) {
        if(!agent.hasCarry()) return false;
        if(packetColor != null) return agent.getCarry().getColor().equals(packetColor);
        return true;
    }

    @Override
    public int getCommunicationSize() {
        return super.getCommunicationSize() + 1*CommunicationValues.BYTESIZE;
    }
}
