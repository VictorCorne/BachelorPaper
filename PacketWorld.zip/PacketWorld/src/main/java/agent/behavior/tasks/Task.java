package agent.behavior.tasks;

import agent.AgentImp;
import environment.Coordinate;
import util.communicationHelper.*;

/**
 * A class used for describing tasks that an agent must do.
 */
public abstract class Task implements Communicable {

    // CONSTRUCTOR
    public Task(Coordinate taskLocation, int acceptableRangeFromGoal, boolean isLocationUpdatable, boolean allowToDropTask) {
        this.taskLocation = taskLocation;
        this.skippingRangeFromGoal = acceptableRangeFromGoal;
        this.isLocationUpdatable = isLocationUpdatable;
        this.allowToDropTask = allowToDropTask;
    }

    // METHODS

    /**
     * The code that is run for this task at each turn by the agent
     */
    public abstract void execute(AgentImp agent);

    /**
     * Returns the corresponding class of item to accomplish the goal
     *
     * For example : the item class for fulfilling the GetPacket task is PacketRep.class,
     * for fulfilling delivering a packet it is the DesptinationRep.class
     */
    public Class getItemClassForTask() {
        return null;
    }

    /**
     * Returns true iff the agent has accomplished this task.
     * A task is accomplished iff the main goal type is satisfied and the agent is at the current location
     */
    public abstract boolean isFinished(AgentImp agent);

    /**
     * Returns true if the agent is within the acceptable range from the goal
     */
    public final boolean isAgentAtSkippingRangeOfGoal(AgentImp agent){
        if(taskLocation != null)
            return agent.getCoordinate().distance(taskLocation) <= skippingRangeFromGoal;
        return true;
    }

    // FIELDS

    // The coordinate of the goal (can be null)
    Coordinate taskLocation;
    /**
     * An int dictating how far the agent can be from the task's goal before skipping turns.
     * A 0 means that the agent has to perform its goal, a value of 1 allows the agent to skip turns and stop moving on the neighboring tiles of the goal
     * This field is often used in the waiting or gathering tasks, where the markpoint allows a range from the goal where being present counts as accomplishing it
     */
    private final int skippingRangeFromGoal;

    /**
     * A field indicating that the location of this task can be changed.
     * This is especially useful when agents must pick up packets and see a closer one.
     */
    final boolean isLocationUpdatable;

    /**
     * A field representing the urgency of the task. If this is set to false, the task cannot be given up on and must be completed at all cost.
     * If this is set to true, the behavior governing the agent is allowed to drop this task to pursue another.
     */
    final boolean allowToDropTask;

    // SETTERS
    public void setTaskLocation(Coordinate taskLocation) {
        if(isLocationUpdatable)
            this.taskLocation = taskLocation;
    }


    // GETTERS

    public Coordinate getTaskLocation() {
        return taskLocation;
    }

    public int getSkippingRangeFromGoal() {
        return skippingRangeFromGoal;
    }

    public boolean isLocationUpdatable() {
        return isLocationUpdatable;
    }

    public boolean allowToDropTask() {
        return allowToDropTask;
    }

    @Override
    public int getCommunicationSize() {
        int size = 1 * CommunicationValues.BYTESIZE + 2 * CommunicationValues.BOOLSIZE;
        if (taskLocation != null) size += taskLocation.getCommunicationSize();
        return size;
    }
}