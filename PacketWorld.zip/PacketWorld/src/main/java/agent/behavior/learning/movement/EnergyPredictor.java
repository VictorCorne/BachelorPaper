package agent.behavior.learning.movement;

import agent.*;
import agent.behavior.learning.*;
import agent.behavior.schedule.*;
import agent.behavior.tasks.*;
import environment.*;

import java.util.*;

import static agent.behavior.learning.movement.ChargingPredictor.CHARGEPOWER;
import static agent.behavior.learning.movement.ChargingPredictor.CHARGE_MAXIMUM;

/**
 * A class who is specialised in calculating the expected energy costs of moving agents via learning.
 *
 * Examples are : calculating the minimum energy cost an agent will have to be present at a given location,
 *      calculating the expected energy cost to move to a location etc.
 */
public class EnergyPredictor extends Predictor implements FollowSchedulePredictor{

    // MOVEMENT

    public static double getEstimatedEnergyCostToMove(int nbTurns){
        return nbTurns * getAverageConsumptionPerTurn();
    }

    public static double getSafetyMinimalEnergyCostToMove(int nbTurns){
        return nbTurns * MIN_MOVE_CONSUMPTION * safetyMargin;
    }

    private static double getMinimalEnergyCostToMove(int timeNeededToMove) {
        return timeNeededToMove * MIN_MOVE_CONSUMPTION;
    }

    public static double getSafetyEnergyCostToMove(int nbTurns){
        return nbTurns * getAverageConsumptionPerTurn() * safetyMargin;
    }

    public static int getExpectedTurnsWaitingOnSchedule(AgentRepresentation agent, TimeSlot slot) {
        var stateOnSwitch = getExpectedRepresentationOfAgentWhenSwitchToSchedule(agent, slot);
        int turnsMove = MovementPredictor.getEstimatedNbTurnsToMove(stateOnSwitch.getCoordinate(), slot.getDestination());
        int turnOnArrival = stateOnSwitch.turnNb + turnsMove;
        return slot.getFromTurn() - turnOnArrival;
    }

    public static boolean couldAgentReachSlot(AgentRepresentation agent, TimeSlot slot) {
        int toMove = MovementPredictor.getEstimatedNbTurnsToMove(agent.getCoordinate(), slot.getDestination());
        int turnArrival = toMove + agent.turnNb;
        return turnArrival <= slot.getFromTurn();
    }

    public int getEstimatedChargeLevelAfterMoving(int nbTurns, AgentRepresentation agent){
        return (int) (agent.batteryState - getEstimatedEnergyCostToMove(nbTurns));
    }

    public EnergyPredictor() {
    }

    // AUTONOMY
    /**
     * Returns the maximum amount of turns this agent can move with his current battery level
     */
    public static int getLongestMovementAutonomy(int batteryState){
        return (int) Math.ceil((double) batteryState / (double) MIN_MOVE_CONSUMPTION);
    }

    /**
     * Returns the maximum amount of turns this agent can live (without moving)
     */
    public static int getLongestLivingAutonomy(int batteryState){
        return batteryState / DECAYCONSUMPTION;
    }

    /**
     * Returns the minimum amount of turns this agent can move with his current battery level
     */
    public static int getShortestMovementAutonomy(int batteryState){
        return (int) Math.ceil((double) batteryState / (double) MAX_MOVE_CONSUMPTION);
    }

    /**
     * Returns the estimated amount of turns this agent can move with his current battery level
     */
    public int getEstimatedAutonomy(int batteryState){
        return (int) ((double) batteryState / getAverageConsumptionPerTurn());
    }

    // SCHEDULE FOLLOWING

    /**
     * Returns true if this predictor deems it necessary to start moving to the given temporalTask in terms of energy.
     *
     */
    public static boolean shouldStartFollowingScheduledTaskByEnergy(AgentRepresentation agent, TemporalTask task){
        TimeSlot slot = task.getSlot();
        int turnsToGoal = MovementPredictor.getSafetyNbTurnsToMove(agent.getCoordinate(), slot.getDestination());
        double energyCostToGoal = getSafetyEnergyCostToMove(turnsToGoal);

        return agent.getBatteryState() <= energyCostToGoal;
    }

    /**
     * Returns the expected turn at which the agent will follow the given task
     */
    public static int getExpectedTurnWhenSwitchToSchedule(AgentRepresentation agent, TimeSlot slot) {
        return getExpectedRepresentationOfAgentWhenSwitchToSchedule(agent, slot).turnNb;
    }

    /**
     * Returns the expected number of turns this agent will be able to handle until its scheduled task takes place
     */
    public static int getExpectedTurnsUntilSwitchToSchedule(AgentRepresentation agent, TimeSlot slot){
        int currentTurn = agent.turnNb;
        return getExpectedTurnWhenSwitchToSchedule(agent, slot) - currentTurn;
    }

    public static int getExpectedTurnsInManagedMode(AgentRepresentation agent, TimeSlot slot){
        return slot.getFromTurn() - getExpectedTurnWhenSwitchToSchedule(agent, slot);
    }

    @Override
    public boolean shouldStartFollowScheduledTask(AgentImp agent, TemporalTask temporalTask, List<Predictor> otherPredictors) {
        return shouldStartFollowingScheduledTaskByEnergy(new AgentRepresentation(agent), temporalTask);
    }


    /**
     * Returns the expected charge level the given agent would have if it were to go to continue its normal behavior
     * and autonomously decide to go to the given location to reach it at the given time.
     */
    @Deprecated
    public int getEstimatedBatteryLevelOnSchedule(AgentRepresentation agent, TimeSlot timeSlot){
        return getEstimatedBatteryLevelOnSchedule(agent, timeSlot.getFromTurn(), timeSlot.getDestination());
    }

    /**
     * Returns the expected charge level the given agent would have if it were to go to continue its normal behavior
     * and autonomously decide to go to the given location to reach it at the given time.
     */
    @Deprecated
    public static int getEstimatedBatteryLevelOnSchedule(AgentRepresentation agent, int turnDeadline, Coordinate goalCoord) {
        int timeNeededToMove = MovementPredictor.getEstimatedNbTurnsToMove(agent.getCoordinate(), goalCoord);
        // Lowest cost needed because the agent will drop its packet before going to the task
        int energyToMove = (int) getSafetyMinimalEnergyCostToMove(timeNeededToMove);
        int timeSurplus = (turnDeadline - agent.getNbTurns()) - timeNeededToMove;
        return (int) (agent.getBatteryState() - energyToMove - getEstimatedEnergyCostToMove(timeSurplus));
    }

    public static int getEstimatedEnergyMargeWhenFollowSchedule(AgentRepresentation agent, TimeSlot slot){
        int timeNeededToMove = MovementPredictor.getEstimatedNbTurnsToMove(agent.getCoordinate(), slot.getDestination());
        // Lowest cost needed because the agent will drop its packet before going to the task
        int energyToMove = (int) getMinimalEnergyCostToMove(timeNeededToMove);
        return agent.batteryState - energyToMove;
    }

    @Deprecated
    public int getEstimatedBatteryLevelAfterChargeTask(AgentRepresentation agent, TimeSlot timeSlot){
        int batteryBefore = getEstimatedBatteryLevelOnSchedule(agent, timeSlot);
        int batteryPlus = CHARGEPOWER * timeSlot.getDuration();
        return Math.max(CHARGE_MAXIMUM, batteryBefore + batteryPlus);
    }

    public static boolean wouldAgentDieWaitingForSlot(AgentRepresentation agent, TimeSlot slot){
        int turnsToMove = MovementPredictor.getEstimatedNbTurnsToMove(agent.getCoordinate(), slot.getDestination());
        int costToMove = (int) getSafetyMinimalEnergyCostToMove(turnsToMove);
        int turnArrival = agent.turnNb + turnsToMove;
        int waitTime = slot.getFromTurn() - turnArrival;
        int stateAfterWait = agent.batteryState - costToMove - waitTime * EnergyValues.BATTERY_DECAY_SKIP;
        return stateAfterWait < EnergyValues.BATTERY_SAFE_MIN;
    }

    public static AgentRepresentation getExpectedRepresentationOfAgentWhenSwitchToSchedule(AgentRepresentation agent, TimeSlot slot){
        ChargeYourselfTask task = new ChargeYourselfTask(slot);
        AgentRepresentation res = agent.clone();

        double expectedX = agent.getCoordinate().getX();
        double expectedY = agent.getCoordinate().getY();

        while (!task.shouldGoToSchedule(res)){
            Coordinate nextCoord;
            int nextBatteryState = (int) (res.batteryState - getSafetyEnergyCostToMove(1));

            if(res.getHeadedToCoordinate() != null){
                double expectedDelta = 1 / (MovementPredictor.movementFactor * MovementPredictor.movementSafetyMargin);
                Coordinate dir = res.headedToCoordinate.sub(res.getCoordinate()).normalized();
                expectedX += expectedDelta * dir.getX();
                expectedY += expectedDelta * dir.getY();
//                nextCoord = res.getCoordinate().stepTowards(res.headedToCoordinate);
            }else {
//                nextCoord = res.getCoordinate();
                expectedX += 0;
                expectedY += 0;
            }

            nextCoord = new Coordinate((int) expectedX, (int) expectedY);

            res = new AgentRepresentation(nextCoord.clone(),
                                          res.getHeadedToCoordinate(),
                                          res.hasCarry,
                                          nextBatteryState,
                                          res.getAgentID(),
                                          res.turnNb+1);
        }

        return res;
    }

    // CONSTANTS
    public static final int DECAYCONSUMPTION = EnergyValues.BATTERY_DECAY_SKIP,
            MIN_MOVE_CONSUMPTION = EnergyValues.BATTERY_DECAY_STEP,
            MAX_MOVE_CONSUMPTION = EnergyValues.BATTERY_DECAY_STEP_WITH_CARRY;


    // DETERMINING CONSUMPTION

    public static double averageConsumptionPerTurn = 1.2*(0.1d * DECAYCONSUMPTION + 0.4d * MIN_MOVE_CONSUMPTION + 0.5d * MAX_MOVE_CONSUMPTION);

    private static double getAverageConsumptionPerTurn() {
        return averageConsumptionPerTurn;
    }

    public static double safetyMargin = 1.3d;
}
