package agent.behavior.learning.slotRequest;

import agent.*;
import agent.behavior.learning.*;
import agent.behavior.managingSystem.*;

import java.util.*;

public class SlotRequesterPredictor extends Predictor {

    // CONSTRUCTOR

    public SlotRequesterPredictor(EnergyManagementBehavior energyManagementBehavior) {
        this.energyManagementBehavior = energyManagementBehavior;
    }

    private final EnergyManagementBehavior energyManagementBehavior;

    // DETERMINING WHEN TO ASK SLOTS

    /**
     * Returns true if and only if this agent should ask for a slot this turn.
     */
    public boolean shouldAskForSlot(AgentImp agent) {
        return
                isEnergyLowEnoughToAskForSlot(agent) &&
                // do not ask if dead
                agent.hasEnergyLeft() &&
                !energyManagementBehavior.hasAlreadyChargerSlot(agent);
    }

    // ENERGY THRESHOLD FOR GENERATING SLOTS
    /**
     * @note those values were evaluated by testing a lot (>500) runs on different environments and different instances of energy-management-behaviors.
     *       Those values are the ones who offer good results in general
     */
    public static double prob0Ask = 0.8;
    public static double prob1Ask = 0.8;
    public static int halvingInterval = 500;
    public static double convergenceValue = .6;

    /**
     * Returns true if this predictor deems that the agent has a low enough battery state to ask for a slot.
     */
    private boolean isEnergyLowEnoughToAskForSlot(AgentImp agent){
        return new Random().nextDouble() <=
                new ProbabilisticAcceptor(prob0Ask, prob1Ask, halvingInterval, convergenceValue)
                        .getProbabilityOfAcceptance(agent.getBatteryPercent(), agent.getNbTurns());
    }
}
