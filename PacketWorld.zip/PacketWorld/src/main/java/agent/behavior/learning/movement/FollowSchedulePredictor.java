package agent.behavior.learning.movement;

import agent.*;
import agent.behavior.learning.*;
import agent.behavior.tasks.*;

import java.util.*;

public interface FollowSchedulePredictor {

    boolean shouldStartFollowScheduledTask(AgentImp agent, TemporalTask temporalTask, List<Predictor> otherPredictors);
}
