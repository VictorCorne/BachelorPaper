package agent.behavior.learning.slotRequest;

import agent.behavior.learning.*;
import agent.behavior.learning.movement.*;
import agent.behavior.learning.slotRequest.SlotQualityStrategies.*;
import agent.behavior.schedule.*;

/**
 * A class who is specialised in calculating the expected quality of timeSlots for agents.
 */
public class SlotQualityPredictor extends Predictor {

    /**
     * Returns the heuristic value of the given slot if it were given to the agent
     */
    public static double getQualityOfSlot(AgentRepresentation agent, TimeSlot slot) {
        return getQualityOfSlot(agent, slot,
                                new EnergyPredictor(),
                                new MovementPredictor());
    }

    /**
     * Returns the heuristic value of the given slot if it were given to the agent
     */
    public static double getQualityOfSlot(AgentRepresentation agent, TimeSlot slot, EnergyPredictor energyPredictor, MovementPredictor movementPredictor){
        if(slot == null
                // Making predictions is hard. We do not want to give bad slots to the agents. However, sometimes incorrect predictions are made
//                || EnergyPredictor.getEstimatedEnergyMargeWhenFollowSchedule(agent, slot) <= EnergyValues.BATTERY_SAFE_MIN
//                || EnergyPredictor.wouldAgentDieWaitingForSlot(agent, slot)
//                || !EnergyPredictor.couldAgentReachSlot(agent, slot)
        ){
            return Double.MIN_VALUE;
        }
        return currentStrat.getQuality(agent, slot, energyPredictor, movementPredictor);
    }

    
    /**
     * The current strategy for predicting the quality
     */
    public static SlotQualityPredictorStrategy currentStrat = new FewestManagementStrategy();
}
