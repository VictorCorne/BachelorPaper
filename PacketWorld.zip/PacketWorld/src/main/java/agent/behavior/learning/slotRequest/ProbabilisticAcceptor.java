package agent.behavior.learning.slotRequest;

/**
 * The probabilistic acceptor is a module that returns the probability of items being accepted within given boundaries according to a decay function.
 */
public class ProbabilisticAcceptor {

    /**
     * Creates a probabilistic acceptor with the given values.
     *
     * @param prob0Ask  The value at which asking for a request will return 0. It must be higher than prob1Ask
     * @param prob1Ask  The value at which asking for a request will return 1. It must be lower than prob0Ask
     * @param halvingInterval    The interval at which the boundaries of this acceptor halve
     * @param convergenceValue  The value at which the acceptance threshold will converge to
     */
    public ProbabilisticAcceptor(double prob0Ask, double prob1Ask, int halvingInterval, double convergenceValue) {
        if (areValidValues(prob0Ask, prob1Ask)) {
            this.prob0Ask = prob0Ask;
            this.prob1Ask = prob1Ask;
        } else {
            this.prob1Ask = prob0Ask;
            this.prob0Ask = prob1Ask;
        }
        this.halvingInterval = halvingInterval;
        this.convergenceValue = convergenceValue;
    }

    /**
     * Creates a probabilistic acceptor that does not change over time
     */
    public ProbabilisticAcceptor(double prob0Ask, double prob1Ask) {
        this(prob0Ask, prob1Ask, 0, -1);
    }

    // FIELDS

    private double prob0Ask, prob1Ask;
    private final int halvingInterval;
    private final double convergenceValue;

    private boolean areValidValues(double prob0, double prob1){
        return prob0 >= prob1;
    }

    /**
     * Returns the probability of acceptance for the given input, according to a linear interpolation of this acceptor's boundaries (that change over the time by a
     * decay function)
     */
    public double getProbabilityOfAcceptance(double givenValue, int time){
        double x = givenValue,
                a = getUpdatedProb0(time),
                b = getUpdatedProb1(time);
        if(a == b) return x > a ? 0 : 1;
        double p = 1 - (x - b) / (a - b);
        if (p <= 0) p = 0;
        if (p >= 1) p = 1;
        return p;
    }

    /**
     * Returns prob0, updated with the decay function
     */
    private double getUpdatedProb0(int time){
        return weightedMean(prob0Ask, convergenceValue, getDecayPercent(time));
    }

    /**
     * Returns prob1, updated with the decay function
     */
    private double getUpdatedProb1(int time){
        return weightedMean(prob1Ask, convergenceValue, getDecayPercent(time));
    }

    /**
     * Returns the weighted mean between the two values with the percentage indicating how close the result should be to the second value.
     * @pre The percentage must be valid (= in the interval [0,1])
     */
    private double weightedMean(double val1, double val2, double percentToVal2){
        assert percentToVal2 >= 0 && percentToVal2 <= 1;
        return (1-percentToVal2) * val1 + val2 * percentToVal2;
    }

    /**
     * Returns the percentage [0 to 1] of the input that gets left after an exponential decay after turnNb time
     */
    private double getDecayPercent(int turnNb){
        if(halvingInterval == 0) return 0;
        return 1-Math.pow(0.5d, (double) turnNb / (double) halvingInterval);
    }
}
