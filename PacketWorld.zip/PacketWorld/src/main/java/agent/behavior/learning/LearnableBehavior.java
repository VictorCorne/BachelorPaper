package agent.behavior.learning;

import java.util.*;

public interface LearnableBehavior {

    List<Predictor> getPredictors();

    default void addPredictor(Predictor predictor){
        if(getPredictors().stream().anyMatch(o->o.getClass().equals(predictor.getClass()))) throw new RuntimeException("There is already a predictor of the same type present");
        getPredictors().add(predictor);
    }

    default void removePredictor(Predictor predictor){
        getPredictors().remove(predictor);
    }

    default Predictor getPredictorOfType(Class<? extends Predictor> predictorClass){
        return Predictor.getPredictorOfType(getPredictors(), predictorClass);
    }
}
