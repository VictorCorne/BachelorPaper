package agent.behavior.learning.slotRequest;

import agent.behavior.learning.movement.*;
import agent.behavior.schedule.*;

public abstract class SlotQualityPredictorStrategy {

    /**
     * Returns the perceived quality of the proposed slot.
     */
    abstract double getQuality(AgentRepresentation agent, TimeSlot slot, EnergyPredictor energyPredictor, MovementPredictor movementPredictor);

}
