package agent.behavior.learning;

import java.lang.reflect.*;
import java.util.*;

public abstract class Predictor {

    /**
     * Returns the first predictor in the collection that is of the same class as the one as parameter.
     *
     * If no such predictor is present, a newly generated predictor of the desired type will be returned
     */
    static public Predictor getPredictorOfType(Collection<Predictor> predictors, Class<? extends Predictor> predictorClass){
        try {
            return predictors.stream().filter(o->o.getClass().equals(predictorClass)).findFirst().orElse(predictorClass.getDeclaredConstructor().newInstance());
        } catch (InstantiationException | NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(String.format("No predictor of type %s has been found", predictorClass.getSimpleName()));
        }
    }
}
