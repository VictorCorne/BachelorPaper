package agent.behavior.learning.movement;

import agent.*;
import agent.behavior.learning.*;
import agent.behavior.tasks.*;
import agent.behavior.schedule.*;
import environment.*;

import java.util.*;

/**
 * A class who is specialised in calculating the expected costs of moving agents via learning.
 *
 * Examples are : calculating the minimum turn an agent can be present at a given location,
 *      calculating the expected duration to move to a location etc.
 */
public class MovementPredictor extends Predictor implements FollowSchedulePredictor {

    // MOVEMENT
    public static int getEstimatedNbTurnsToMove(Coordinate from, Coordinate to) {
        return (int) ((double)from.distance(to) * getMovementFactor());
    }

    public static int getSafetyNbTurnsToMove(Coordinate from, Coordinate to){
        return (int) ((double)from.distance(to) * getMovementFactor() * movementSafetyMargin);
    }

    // PRESENCE AT LOCATION

    /**
     * Returns the minimum turn the given agent can appear on the given coordinate.
     * This is assuming the agent encounters no obstacles
     */
    public static int getMinimumTurnAgentCanBePresent(AgentRepresentation agent, Coordinate to){
        return agent.getCoordinate().distance(to) + agent.getNbTurns();
    }


    // SCHEDULE FOLLOWING

    /**
     * Returns true iff this predictor deems it necessary for the agent to start following the schedule now.
     * This method only decides this by taking the distance and time to the task into account
     */
    public static boolean shouldStartFollowingScheduledTaskByTime(AgentImp agent, TemporalTask task){
        return shouldStartFollowingScheduledTaskByTime(new AgentRepresentation(agent),task);
    }

    public static boolean shouldStartFollowingScheduledTaskByTime(AgentRepresentation agent, TemporalTask task){
        TimeSlot sched = task.getSlot();
        double estTimeToMoveToGoal = getSafetyNbTurnsToMove(agent.getCoordinate(), task.getSlot().getDestination()),
                timeUntilScheduleStarts = sched.getFromTurn() - agent.getNbTurns() - 1;
        return estTimeToMoveToGoal >= timeUntilScheduleStarts;
    }


    @Override
    public boolean shouldStartFollowScheduledTask(AgentImp agent, TemporalTask temporalTask, List<Predictor> otherPredictors) {
        return shouldStartFollowingScheduledTaskByTime(agent, temporalTask);
    }

    // FIELDS

    /**
     * The factor that is multiplied with the distance to get an expected duration for the agent to move to a location.
     * This value must be greater than one.
     * Example: if the value is 1.5, this learning module will guess that the time-cost for moving 10 tiles will be 15 turns (and thus gives 5 turns breathing room)
     */
    public static double movementFactor = 1.5d;

    public static double getMovementFactor(){
        return movementFactor;
    }

    public static double movementSafetyMargin = 1.2d;
}
