package agent.behavior.learning.slotRequest;

import agent.*;
import agent.behavior.learning.movement.*;
import agent.behavior.schedule.*;
import environment.*;

public class SlotQualityStrategies {

    public static final class LatestSwitchStrategy extends SlotQualityPredictorStrategy{

        @Override
        double getQuality(AgentRepresentation agent, TimeSlot slot, EnergyPredictor energyPredictor, MovementPredictor movementPredictor) {
            return EnergyPredictor.getExpectedTurnsUntilSwitchToSchedule(agent, slot);
        }
    }

    public static final class FewestManagementStrategy extends SlotQualityPredictorStrategy{

        // number of turns agents are expected to work - nb turns spent on managed mode
        @Override
        double getQuality(AgentRepresentation agent, TimeSlot slot, EnergyPredictor energyPredictor, MovementPredictor movementPredictor) {
            double turnsWorking = EnergyPredictor.getExpectedTurnsUntilSwitchToSchedule(agent, slot);
            double turnsSwitched = EnergyPredictor.getExpectedTurnsInManagedMode(agent, slot);
            return turnsWorking - turnsSwitched;
        }
    }

    @Deprecated
    public static final class MostWorkStrategy extends SlotQualityPredictorStrategy {
        public MostWorkStrategy(double movementPenalty) {
            this.movementPenalty = movementPenalty;
        }

        double movementPenalty = 2000;
        double energyBoost = 1_000_000_000;
        double penaltySkipTurn = 500;
        double energyDeltaBonus = 10000;

        @Override
        public double getQuality(AgentRepresentation agent, TimeSlot slot, EnergyPredictor energyPredictor, MovementPredictor movementPredictor) {
            int levelOnArrival = energyPredictor.getEstimatedBatteryLevelOnSchedule(agent, slot);
            // We want the least amount of skipped turns
            int turnStartToSchedule = EnergyPredictor.getExpectedTurnWhenSwitchToSchedule(agent, slot);
            int nbSkipTurns = slot.getFromTurn() - turnStartToSchedule;

            // We want the agent to have spent (possibly a lot of) energy on its task
            int energyDelta = agent.getBatteryState() - levelOnArrival;

            // We do not want the movement to count for the energy spent
            Coordinate next = agent.getHeadedToCoordinate() == null ? agent.getCoordinate() : agent.getHeadedToCoordinate();
            double movementCost = EnergyPredictor.getEstimatedEnergyCostToMove(movementPredictor.getEstimatedNbTurnsToMove(next, slot.getDestination()));

            // We want a lot of energy gain
            double energyGain = slot.getDuration() * EnergyStationImp.LOAD;

            return energyGain * energyBoost + energyDelta * energyDeltaBonus - movementCost * movementPenalty - nbSkipTurns * penaltySkipTurn;
        }
    };

    @Deprecated
    public static final class LowestEnergyStrategy extends SlotQualityPredictorStrategy {
        @Override
        double getQuality(AgentRepresentation agent, TimeSlot slot, EnergyPredictor energyPredictor, MovementPredictor movementPredictor) {
            return -energyPredictor.getEstimatedBatteryLevelOnSchedule(agent, slot);
        }
    };

    @Deprecated
    public static final class HighestEnergyStrategy extends SlotQualityPredictorStrategy {
        @Override
        double getQuality(AgentRepresentation agent, TimeSlot slot, EnergyPredictor energyPredictor, MovementPredictor movementPredictor) {
            return energyPredictor.getEstimatedBatteryLevelOnSchedule(agent, slot);
        }
    };

    @Deprecated
    public static final class DifferenceStrategy extends SlotQualityPredictorStrategy {
        public DifferenceStrategy(int levelBeforeMarge) {
            this.levelBeforeMarge = levelBeforeMarge;
        }

        int levelBeforeMarge;

        @Override
        double getQuality(AgentRepresentation agent, TimeSlot slot, EnergyPredictor energyPredictor, MovementPredictor movementPredictor) {
            int levelBefore = energyPredictor.getEstimatedBatteryLevelOnSchedule(agent, slot),
                    levelAfter = energyPredictor.getEstimatedBatteryLevelAfterChargeTask(agent, slot),
                    difference = levelAfter - levelBefore,
                    distance = agent.getCoordinate().distance(slot.getDestination());
            return Math.pow(difference,2) + Math.pow(levelBefore- levelBeforeMarge, 3) - Math.pow(distance*100, 4);
        }
    };

    @Deprecated
    public static final class NoStrategy extends SlotQualityPredictorStrategy {
        @Override
        double getQuality(AgentRepresentation agent, TimeSlot slot, EnergyPredictor energyPredictor, MovementPredictor movementPredictor) {
            return 0;
        }
    };
}
