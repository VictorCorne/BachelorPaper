package agent.behavior.learning.movement;

import agent.*;
import agent.behavior.learning.*;
import environment.*;

/**
 * A class who is specialised in calculating the expected durations of charging agents.
 *
 * Examples are : calculating the duration needed for charging an agent up to maximum level.
 */
public class ChargingPredictor extends Predictor {

    /**
     * Returns the estimated number of turns needed to charge up to the maximum from the given level
     */
    public static int getNbTurnsToChargeFrom(int chargeLevel){
        return (int) ((double)(CHARGE_MAXIMUM - chargeLevel)/(double) CHARGEPOWER);
    }

    /**
     * Returns the best size to allocate for agents to charge.
     * The resulting size encompasses the time to charge as well as the time for an agent to get in and out of the slot
     */
    public static int getBestChargingSlotSize() {
        return MAXIMUM_TURNS_TO_CHARGE_UP + 2;
    }

    public static int getEnergyAfterCharge(int fromEnergy, int chargeDuration){
        return Math.min(fromEnergy + getEnergyDeltaAfterCharge(fromEnergy, chargeDuration), CHARGE_MAXIMUM);
    }

    public static int getEnergyDeltaAfterCharge(int fromEnergy, int chargeDuration){
        int delta = CHARGEPOWER * chargeDuration;
        if(fromEnergy + delta >= CHARGE_MAXIMUM) delta = CHARGE_MAXIMUM - fromEnergy;
        return delta;
    }

    public static double getAgentEnergyDeltaAfterCharge(int fromEnergy, int chargeDuration){
        return ((double) getEnergyDeltaAfterCharge(fromEnergy, chargeDuration)) / CHARGE_MAXIMUM;
    }

    public static double getMaximumChargeDeltaPercent(int chargeDuration){
        return ((double) chargeDuration * (double) CHARGEPOWER) /(double) CHARGE_MAXIMUM;
    }
    public static final int CHARGE_MAXIMUM = EnergyValues.BATTERY_SAFE_MAX,
            CHARGEPOWER = EnergyStationImp.LOAD,
            MAXIMUM_TURNS_TO_CHARGE_UP = getNbTurnsToChargeFrom(0);
}
