package agent.behavior.learning.slotRequest;

import agent.behavior.learning.*;
import agent.behavior.learning.movement.*;
import agent.behavior.schedule.*;
import environment.*;

/**
 * This class represents the learning module for the regional scheduler.
 */
public class RegionalSchedulerPredictor extends Predictor {

    public boolean shouldRequestNeighborsForSlot(TimeSlot slot, AgentRepresentation agent){
        return isPotentiallyUnsafe(slot, agent) ||
                EnergyPredictor.getExpectedTurnsWaitingOnSchedule(agent, slot) >= 3 * ChargingPredictor.getBestChargingSlotSize()

        ;
    }

    public boolean isPotentiallyUnsafe(TimeSlot slot, AgentRepresentation agent){
        return slot == null
                || EnergyPredictor.getEstimatedEnergyMargeWhenFollowSchedule(agent, slot) <= EnergyValues.BATTERY_SAFE_MIN
                || EnergyPredictor.wouldAgentDieWaitingForSlot(agent, slot)
                || !EnergyPredictor.couldAgentReachSlot(agent, slot)
                || SlotQualityPredictor.getQualityOfSlot(agent, slot) == Double.MIN_VALUE
                ;
    }

    public boolean shouldAcceptSlotFromOriginalScheduler(TimeSlot originOffer, TimeSlot responseOffer, AgentRepresentation representation){
        return SlotQualityPredictor.getQualityOfSlot(representation, originOffer) > SlotQualityPredictor.getQualityOfSlot(representation, responseOffer);
    }

    private boolean acceptFromOriginalSchedulerOnSafety(TimeSlot originOffer, TimeSlot responseOffer, AgentRepresentation representation){
        boolean responseSafe = !isPotentiallyUnsafe(responseOffer, representation),
                originSafe = !isPotentiallyUnsafe(originOffer, representation);

        if(responseOffer == null) return true;
        if(originSafe && responseSafe) return SlotQualityPredictor.getQualityOfSlot(representation, originOffer) > SlotQualityPredictor.getQualityOfSlot(representation, responseOffer);
        if(originSafe && !responseSafe) return true;
        if(!originSafe && responseSafe) return false;
        if(!originSafe && !responseSafe) return SlotQualityPredictor.getQualityOfSlot(representation, originOffer) - 50> SlotQualityPredictor.getQualityOfSlot(representation, responseOffer);
        return originSafe;
    }

}
