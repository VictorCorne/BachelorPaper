package agent;

import agent.behavior.schedule.*;
import environment.*;
import support.*;

/**
 * This class represents the active "behavior" of an EnergyStation.
 * It sends every turn an EnergyInfluence to the Environment.
 */
public class EnergyStationImp extends ActiveItemImp {

    public EnergyStationImp(int id, int x, int y) {
        super(id);
        this.x = x;
        this.y = y;
    }

    protected void action() {
        if(isSchedulingEntity()) {
            schedulingEntity.communication();
            schedulingEntity.action();
        }
        Influence influence = new InfEnergy(getEnvironment(), getX(), getY() - 1, getID(), LOAD);
        ActionOutcome outcome = new ActionOutcome(getID(), true, getSyncSet(), influence);
        concludePhaseWith(outcome);
    }

    // LOCATION

    protected int getX() {
        return x;
    }

    protected int getY() {
        return y;
    }

    private final int x;
    private final int y;

    /**
     * Returns the cloned coordinate of the energy station itself
     */
    public Coordinate getCoordinate(){
        return new Coordinate(x,y);
    }

    /**
     * Returns the cloned coordinate of the tile that is being charged by this station
     */
    public Coordinate getChargingFieldLocation(){
        return getCoordinate().add(0,-1);
    }


    // SCHEDULING ENTITY

    /**
     * It may be desired to have scheduling entities.
     * To avoid modifying the simulator too much, it is desired to implement those on top of the energy station imp.
     */
    private SchedulingEntity schedulingEntity = null;

    /**
     * Sets this energystation's scheduling entity to the one given as a parameter
     */
    public void setSchedulingEntity(SchedulingEntity schedulingEntity){
        this.schedulingEntity = schedulingEntity;
    }

    public SchedulingEntity getSchedulingEntity() {
        return schedulingEntity;
    }

    public boolean isSchedulingEntity(){
        return getSchedulingEntity() != null;
    }

    /**
     * The energy that is transferred per cycle to an agent.
     */
    public static final int LOAD = 200;
}