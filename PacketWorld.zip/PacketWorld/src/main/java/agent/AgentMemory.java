package agent;

import environment.*;
import environment.world.destination.DestinationRep;
import environment.world.energystation.*;
import environment.world.packet.PacketRep;

import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.stream.*;

public class AgentMemory {

	public AgentMemory() {
		packetGroups = new HashSet<>();
		energyStations = new HashSet<>();
		stationGroups = new HashMap<>();
	}

	/**
	 * Called each turn and if this agent is close to a memorised group of packets, but they do not exist anymore
	 * (they have been transported), it will forget this location and return the coordinate it has forgotten (to use
	 * in communication) if any. Else it will return null
	 *
	 */
	public List<Coordinate> forgetMissingPacketGroups(AgentImp agent){
		List<Coordinate> res = new ArrayList<>();
		Coordinate agentCoord = agent.getCoordinate();
		HashSet<Coordinate> coords = (HashSet<Coordinate>) packetGroups.clone();
		for (Coordinate coord : packetGroups) {
			if (coord.distance(agentCoord) <= rangeForgetOldPackets()){
				// The coordinate is in range
				if(!agent.seePacket()){
					coords.remove(coord);
					res.add(coord);
				}
			}
		}
		packetGroups = coords;
		return res;
	}

	/**
	 * Called to notify the memory that a new item has been found. If it is a new item it will save it.
	 * It returns true if and only if the item has been remembered
	 */
	public boolean notifyExistenceOfItem(Representation item) {
		if (isConsideredNew(item, rangeNew())) {
			rememberItem(item);
			return true;
		}
		return false;
	}

	public void notifyExistenceOfItems(List<Representation> items){
		for (Representation item : items) {
			notifyExistenceOfItem(item);
		}
	}

	/**
	 * Will remember the given item. I.e. it will put its coordinate in its collection
	 */
	private void rememberItem(Class itemType, Coordinate itemCoord, Color color){
		if (PacketRep.class.equals(itemType)) { packetGroups.add(itemCoord); }
		else if (DestinationRep.class.equals(itemType)) { stationGroups.put(itemCoord,color); }
		else if (EnergyStationRep.class.equals(itemType)) { energyStations.add(itemCoord.add(new Coordinate(0,-1)));}
	}

	private void rememberItem(Representation item){
		if(item instanceof DestinationRep){
			rememberItem(item.getClass(), new Coordinate(item.getX(), item.getY()), ((DestinationRep) item).getColor());
		}else {
			rememberItem(item.getClass(), new Coordinate(item.getX(), item.getY()), null);
		}
	}


	/**
	 * Returns true iff the considered Representation is considered new.
	 * A representation is considered new if this agentImpExtended has not seen a representation of an object of an identical class within rangeNew tiles.
	 * If the item is a station, it also must have a different color to be considered new
	 * This method is used for saving new item(representations) that are found on the way in the memory. These are in turn used for communication purposes
	 *
	 * Complexiteit : O(knownLocations)
	 */
	public boolean isConsideredNew(Class clazz, int itemX, int itemY, Color color, int rangeNew) {
		Coordinate itemCoord = new Coordinate(itemX, itemY);

		//Case item == PacketRep
		if (PacketRep.class.equals(clazz)) {
			for (Coordinate knownCoord : packetGroups) {
				// If there is a packetgroup whose location is closer than range ==> false
				// Else true
				if (knownCoord.distance(itemCoord) <= rangeNew)
					return false;
			}
			return true;
		}

		// Case DestinationRep
		else if (DestinationRep.class.equals(clazz)) {
			for (Map.Entry<Coordinate,Color> pair : stationGroups.entrySet()){
				if(pair.getValue().equals(color) &&
						pair.getKey().distance(itemCoord) < rangeNew)
					return false;
			}
			return true;
		}

		// Case EnergyStation
		else if (EnergyStationRep.class.equals(clazz)) {
			for (Coordinate knownCoord : energyStations) {
				// If there is an energyStation whose location is closer than range ==> false
				// Else true
				if (knownCoord.distance(itemCoord) <= rangeNew)
					return false;
			}
			return true;
		}
		return false;
	}

	public boolean isConsideredNew(Representation item, int rangeNew){
		if(item instanceof DestinationRep) return isConsideredNew(DestinationRep.class, item.getX(), item.getY(),
				((DestinationRep) item).getColor(), rangeNew);
		else return isConsideredNew(item.getClass(), item.getX(), item.getY(),null,rangeNew);
	}

	/**
	 * Returns the closest known item of the given class. The distance is calculated from the given location.
	 * If nothing has been found, null is returned
	 */
	public Coordinate getClosestItemOfClass(Class clazz, Coordinate fromLoc, Color color){
		Coordinate result = null;
		int closestDistance = Integer.MAX_VALUE;
		if(clazz == PacketRep.class){
			for (Coordinate packetCoord : packetGroups) {
				if(packetCoord.distance(fromLoc) < closestDistance){
					result = packetCoord;
				}
			}
		}else if (clazz == EnergyStationRep.class){
			for (Coordinate energyStationLoc : energyStations) {
				if(energyStationLoc.distance(fromLoc) < closestDistance){
					result = energyStationLoc;
				}
			}
		} else if(clazz == DestinationRep.class){
			var best = stationGroups.entrySet().stream().filter(o -> o.getValue().equals(color)).min(Comparator.comparingInt(op -> op.getKey().distance(fromLoc)));
			if(best.isPresent())return best.get().getKey();
		}
		return result;
	}

	public Coordinate getClosestCharger(AgentImp agent){
		return getClosestItemOfClass(EnergyStationRep.class, agent.getCoordinate(), null);
	}

	//Internal memory containing the coordinates of interesting items

	HashSet<Coordinate> packetGroups,
		energyStations;

	Map<Coordinate, Color> stationGroups;

	public HashSet<Coordinate> getPacketGroups() {
		return packetGroups;
	}

	public HashSet<Coordinate> getEnergyStations() {
		return energyStations;
	}

	public Map<Coordinate, Color> getStationGroups() {
		return stationGroups;
	}

	/**
	 * The class of itemsrepresentations that are considered important to communicate about when new ones are found on the map
	 */
	protected final static List<Class> vitallyCommunicatedItemsListClass = Arrays.asList(PacketRep.class,
			DestinationRep.class,
			EnergyStationRep.class);

	protected final static int rangeNew(){
		return 4;
	}

	private final static int rangeForgetOldPackets() {
		return 2;
	}

	public <T extends Item<?>> void retrieveAllItems(Collection<T> ts){
		notifyExistenceOfItems(ts.stream().map(o->o.getRepresentation()).collect(Collectors.toList()));
	}
}
