package agent;

import agent.*;

public interface AgentObserver {

    void onAgentFellFlat(AgentImp agent, int turnFellFlat);
}
