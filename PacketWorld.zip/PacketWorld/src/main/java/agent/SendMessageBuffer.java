package agent;

import agent.behavior.managingSystem.communicationStrategy.regionalPlannerBehavior.*;
import agent.behavior.schedule.*;
import environment.*;
import util.*;
import util.event.*;

import java.security.cert.*;
import java.util.*;

/**
 * A messagebuffer that allows for sending and buffering messages.
 */
public class SendMessageBuffer {

    // ATTRIBUTES

    private final List<Pair<?, Mail>> buffer = new ArrayList<>();
    private final Environment environment;

    public SendMessageBuffer(Environment environment) {
        this.environment = environment;
    }

    /**
     * Sends the contents of the buffer to its destination and clears the buffer.
     */
    public void sendBuffer(){
        for (Pair<?, Mail> mailPair : buffer) {
            if(mailPair.first instanceof AgentImp) sendMessageToAgent ((AgentImp) mailPair.first, mailPair.second);
            else if(mailPair.first instanceof SchedulingEntity) ((SchedulingEntity) mailPair.first).receiveMessage(mailPair.second);
            else if(mailPair.first instanceof Integer) sendMessageToAgentID((int) mailPair.first, mailPair.second);
            else if (mailPair.first instanceof AgentRepresentation) sendMessageToAgentID(((AgentRepresentation) mailPair.first).agentID, mailPair.second);
            else if (mailPair.first instanceof Coordinate) sendMessageToCoordinate((Coordinate) mailPair.first, mailPair.second);
            postMesssageEvent(mailPair);
        }

        clear();
    }

    private void postMesssageEvent(Pair<?,Mail> mailPair){
        var evbus = environment.getAgentImplementations().getAllAgents().get(0).getEventBus();
        evbus.post(new MsgSentEvent(this, mailPair.second));
    }

    // ADDING MESSAGE TO BUFFER

    /**
     * Adds the given message to the buffer
     * @param mailPair
     */
    private void addMessage(Pair<?, Mail> mailPair){
        buffer.add(mailPair);
    }

    /**
     * Adds the given message to this buffer
     * @param receiver
     * @param message
     */
    public void addMessage(Object receiver, Mail message){
        addMessage(new Pair<>(receiver, message));
    }

    // MEMORY

    private void clear(){
        buffer.clear();
    }

    // SENDING MESSAGES TO ENTITIES

    private void sendMessageToCoordinate(Coordinate coordinate, Mail mail) {
        sendMessageToAgent(environment.getAgentImplementations().getAgentAt(coordinate), mail);
    }

    /**
     * Sends the given message to the agent
     */
    private void sendMessageToAgent(AgentImp agent, Mail msg){
        agent.receiveMessage(msg);
    }

    /**
     * Sends the given mail to the agent with the given id
     */
    private void sendMessageToAgentID(int agentID, Mail mail){
        sendMessageToAgent(environment.getAgentImplementations().getAgentImp(agentID), mail);
    }


}
