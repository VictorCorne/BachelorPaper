import gui.video.*;

/**
 * Quick batch
 */
public class QuickBatch {

    static String imp = "regional";
    static String env = "workDensity_16Agents";
    static boolean autoLaunch = true;


    public static void main(String[] args) {
        BatchMAS mas = new BatchMAS();
        mas.setVisible(true);

        mas.setSelectedImpFile(imp);
        mas.setSelectedEnvFile(env);

        if(autoLaunch) mas.processButtonActionPerformed(null);
    }
}
