import javax.swing.UIManager;

import gui.setup.MainMenu;

/**
 * Main class for the packet world application.
 */
public class Application {

    /**
     * Initializes a new PacketWorld object
     */
    public Application() {}

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) {}

        MainMenu mm = new MainMenu();
        mm.setVisible(true);
    }
}
