package environment;


import util.communicationHelper.Communicable;

import java.util.*;

public class Mail {

    // FIELDS

    private final String from;
    private final String to;
    private final String string;
    private final List<Communicable> messages;

    // CONSTRUCTOR

    public Mail(String from, String to, String string, List<Communicable> messages) {
        this.from = from;
        this.to = to;
        this.string = string;
        this.messages = messages;
    }

    public Mail(Communicable message) {
        this(List.of(message));
    }

    public Mail(List<Communicable> messages){
        this("","","", messages);
    }

    public Mail(String from, String to, String message) {
        this(from,to,message,List.of());
    }

    // COMMUNICATION SIZE

    /**
     * Returns the communication size of this mail
     */
    public int getCommunicationSize(){
        if(messages == null || messages.isEmpty()) return 0;
        return messages.stream().filter(o->o != null).mapToInt(o -> o.getCommunicationSize()).sum();
    }


    // GETTERS

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public String getString() {
        return string;
    }

    public List<Communicable> getMessages() {
        return messages;
    }

}