package environment;

import util.*;
import util.communicationHelper.*;

import java.util.*;
import java.util.stream.*;

import static java.lang.Math.abs;
import static java.lang.Math.max;
import static java.util.Collections.shuffle;

/**
 * A class to represent a 2-dimensional coordinate.
 */

public class Coordinate extends Pair<Integer, Integer> implements Cloneable, Communicable, NullableObject<Coordinate> {

    public Coordinate(int x, int y) {
        super(x, y);
    }

    public static Coordinate fromString(String constructorString){
        constructorString = constructorString.replace('(', ' ');
        constructorString = constructorString.replace(')',' ').trim();
        String[] ints = constructorString.split(",");
        return new Coordinate(Integer.parseInt(ints[0]), Integer.parseInt(ints[1]));

    }

    public Coordinate(Integer first, Integer second) {
        super(first, second);
    }

    public int getX() {
        return this.first;
    }

    public int getY() {
        return this.second;
    }

    public String toString() {
        return String.format("[%d,%d]", this.getX(), this.getY());
    }

    /**
     * returns the manhattanDistance from the other coordinate
     * = abs(x1-x2) + abs(y1-y2)
     */
    public int manhattanDistance(Coordinate other){
        return abs(getX() - other.getX()) + abs(getY()-other.getY());
    }

    public double pythagoreanDistance(Coordinate other){
        int dx = getX() - other.getX();
        int dy = getY() - other.getY();
        double dxx = dx * dx;
        double dyy = dy * dy;
        return Math.sqrt(dxx + dyy);
    }

    /**
     * Returns the distance (=#steps, diagonals included) to the other coordinate
     */
    public int distance(Coordinate other){
        return max(abs(getX() - other.getX()),
                abs(getY()-other.getY()));
    }

    /**
     * Returns the coordinate in the set whose distance is the lowest with this coord
     * @param coords
     * @return
     */
    public Coordinate minDistanceCoord(List<Coordinate> coords){
        assert coords != null && !coords.isEmpty();
        return coords.stream().min(Comparator.comparing(o->o.distance(this))).get();
    }

    /**
     * Returns the minimum distance between this coordinate and the given group of coordinates
     */
    public int minDistance(List<Coordinate> coordinates){
        return distance(minDistanceCoord(coordinates));
    }

    /**
     * Returns the distance (=#steps, diagonals included) between the coordinates
     */
    public static int distance(Coordinate first, Coordinate second){
        return first.distance(second);
    }

    /**
     * returns the manhattanDistance between the two coordinates
     * = abs(x1-x2) + abs(y1-y2)
     */
    public static int manhattanDistance(Coordinate first, Coordinate second){
        return first.manhattanDistance(second);
    }

    /**
     * Returns a new coordinate that is this one in a normalised form (coefficients are 1 if positive, -1 if negative, 0 if zero)
     *
     * EG (4,-5) -> (1,-1)
     * (0,-2) -> (0,-1)
     */
    public Coordinate normalized(){
        int normX = Integer.compare(getX(),0),
            normY = Integer.compare(getY(),0);
        return new Coordinate(normX, normY);
    }

    // Returns true if this coordinate is normalized
    public boolean isNormalized(){
        return this.equals(this.normalized());
    }

    /**
     * Returns a new coordinate which is the sum of this one and the other one
     * The x-value is x_new = x1 + x2,
     * y_new = y1 + y2
     */
    public Coordinate add(Coordinate other){
        return new Coordinate(getX() + other.getX(), getY() + other.getY());
    }

    public Coordinate add(int x, int y) {
        return add(new Coordinate(x,y));
    }

    public Coordinate mul(int val){
        return new Coordinate(this.getX()*val, this.getY()*val);
    }
    public Coordinate mul(float val){return new Coordinate((int) (this.getX()*val), (int) (this.getY()*val));}
    public Coordinate mul(Coordinate other){return new Coordinate(this.getX()*other.getX(), getY()*other.getY());}

    public static Coordinate mean(Collection<Coordinate> coordinates){
        int totalX = coordinates.stream().mapToInt(o->o.getX()).sum();
        int totalY = coordinates.stream().mapToInt(o->o.getY()).sum();
        int size = coordinates.size();
        return new Coordinate(totalX / size, totalY / size);
    }

    /**
     * Returns a new coordinate which is the negative of this one
     * result.getX() == -this.getX()
     * result.getY() == -this.getY()
     */
    public Coordinate negative(){
        return new Coordinate(-getX(), -getY());
    }

    public Coordinate sub(Coordinate other){return add(other.negative());}

    public Coordinate sized(int size){
        return mul(size).mul((float) (1d/(double) size()));
//        boolean xIsMax = abs(getX()) > abs(getY());
//        int newX, newY;
//        if(xIsMax){
//            newX = Integer.compare(getX(),0) * size;
//            newY = (int) ((double)getX()/(double) size);
//        }else {
//            newY = Integer.compare(getY(),0) * size;
//            newX = (int) ((double)getX()/(double) size);
//        }
    }

    public int size(){
        return distance(new Coordinate(0,0));
    }

    /**
     * Returns directions who are <degree> tiles away from the given coordinate
     *
     * Returns null if the coordinate is null or (0,0)
     * EG : (1,0),1 -> {(1,1),(1,-1)}
     * EG : (-1,1),1 -> {(0,1),(-1,0)}
     * EG : (-1,0),0 -> emptyList
     * EG : (0,0) -> null
     */
    public List<Coordinate> alternateDirectionsCumulative(int degree){
        if(this.getX() == 0 && this.getY() == 0) return null;
        if(degree > cycleCoordinates.size()/2) degree = cycleCoordinates.size();

        Coordinate direction = this.normalized();
        int listIndex = cycleCoordinates.indexOf(direction);
        int n = cycleCoordinates.size();
        List<Coordinate> res = new ArrayList<>();

        for (int i = 1; i <= degree; i++) {
            res.add(cycleCoordinates.get((listIndex + n + i) % n));
            res.add(cycleCoordinates.get((listIndex + n - i) % n));
        }
        return res;
    }

    public List<Coordinate> alternateDirections(int degree){
        if(this.getX() == 0 && this.getY() == 0) return null;
        Coordinate direction = this.normalized();

        int listIndex = cycleCoordinates.indexOf(direction);
        int n = cycleCoordinates.size();

        return Arrays.asList(cycleCoordinates.get((listIndex + n + degree) % n),
                cycleCoordinates.get((listIndex + n - degree) % n));
    }

    public Coordinate rotate(boolean clockWise){
        if (clockWise) return new Coordinate(this.getY(), -this.getX());
        else return new Coordinate(-this.getY(), this.getX());
    }

    /**
     * Returns the direction this represents in a normalised manner
     *
     * Eg : (3,1) -> (1,1) with probability = 1/3
     *            -> (1,0) with probability = 2/3
     */
    public Coordinate[] getDirectionWeighted(){
        float straights = abs(abs(getX()) - abs(getY()));
        float diags = max(abs(getX()), abs(getY())) - straights;
        float chanceDiag = diags / (diags+straights);

        boolean mustDiag = (random.nextFloat() < chanceDiag);

        if(mustDiag) return new Coordinate[]{getDiagVersion(), getStraightVersion()};
        else return new Coordinate[]{getStraightVersion(), getDiagVersion()};
    }

    public Coordinate getDiagVersion(){
        return this.normalized();
    }

    public Coordinate getStraightVersion(){
        if(abs(getX()) == abs(getY())) return this.normalized();
        if(abs(getX()) > abs(getY())) return new Coordinate(getX(),0).normalized();
        else return new Coordinate(0, getY()).normalized();
    }

    public boolean isInWorldBounds(int worldX, int worldY){
        return this.getX() >= 0 && this.getY() >= 0 && this.getX() < worldX && this.getY() < worldY;
    }

    public boolean isInWorldBounds(Environment environment){
        return isInWorldBounds(environment.getWidth(), environment.height);
    }

    /**
     * A list of normalized coordinates going in a loop through (0,0)
     *
     * The list is as follows and is used for determining neighboring cells
     *
     * 0 1 2
     * 7 / 3
     * 6 5 4
     */
    private static final List<Coordinate> cycleCoordinates = Arrays.asList(
            new Coordinate(-1,1),
            new Coordinate(0,1),
            new Coordinate(1,1),
            new Coordinate(1,0),
            new Coordinate(1,-1),
            new Coordinate(0,-1),
            new Coordinate(-1,-1),
            new Coordinate(-1,0)
    );

    private static final List<Coordinate> diagCoordinates = Arrays.asList(
            new Coordinate(-1,1),
            new Coordinate(1,1),
            new Coordinate(1,-1),
            new Coordinate(-1,-1)
    );

    private static final List<Coordinate> straightCoordinates = Arrays.asList(
            new Coordinate(0,1),
            new Coordinate(1,0),
            new Coordinate(0,-1),
            new Coordinate(-1,0)
    );

    public List<Coordinate> getAbsoluteNeighborsShuffled(){
        return getNeighborsShuffled().stream().map(o->add(o)).collect(Collectors.toList());
    }

    public static final List<Coordinate> neighbors = cycleCoordinates;
    public static List<Coordinate> getNeighborsShuffled(){
        List<Coordinate> res = new ArrayList<>(neighbors);
        shuffle(res);
        return res;
    }

    public List<Coordinate> getNeighborCoords(int degree){
        return getAbsoluteNeighborCoords(degree).stream().map(o -> o.add(this)).collect(Collectors.toList());
    }

    public static List<Coordinate> getAbsoluteNeighborCoords(int degree){
        List<Coordinate> res = new ArrayList<>();
        for (int x = -degree; x <= degree; x++)
            for (int y = -degree; y <= degree; y++) res.add(new Coordinate(x, y));
        return res;
    }

    /**
     * Returns the coordinate from this list who has the shortest total distance to each other coordinate
     */
    public static Coordinate getCentralCoordinate(Collection<Coordinate> coordinates){
        return coordinates.stream().min(Comparator.comparing(o->
                coordinates.stream().map(c->c.distance(o)).reduce(0, Integer::sum))).get();
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof Coordinate && ((Coordinate) obj).getX() == getX() && ((Coordinate) obj).getY() == getY();
    }

    @Override
    public int hashCode() {
        return Objects.hash(first, second);
    }

    @Override
    public Coordinate clone()  {
        return new Coordinate(this.getX(), this.getY());
    }

    final static private Random random = new Random();

    @Override
    public int getCommunicationSize() {
        return 2 * CommunicationValues.INTSIZE;
    }

    @Override
    public Coordinate getNullableObject() {
        return nullCoordinate;
    }

    public static final Coordinate nullCoordinate = new Coordinate(0,0);

    /**
     * Returns a new coordinate, representing this one after a step has been taken towards the direction of the other coordinate.
     */
    public Coordinate stepTowards(Coordinate nextLocation) {
        Coordinate diff = nextLocation.sub(this).normalized();
        return this.add(diff);
    }
}