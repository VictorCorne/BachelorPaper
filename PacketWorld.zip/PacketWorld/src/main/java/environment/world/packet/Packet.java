package environment.world.packet;

import java.awt.Color;

import environment.Item;
import gui.video.Drawer;
import util.Debug;
import util.MyColor;

/**
 * A class for packets with a certain color.
 */

public class Packet extends Item<PacketRep> {

    private final Color color;

    /**
     * Initializes a new Packet instance
     *
     * @param  x    X-coordinate of the Packet
     * @param  y    Y-coordinate of the Packet
     * @param  col  The Packet's color
     */
    public Packet(int x, int y, Color col) {
        super(x, y);
        color = col;
        Debug.print(this, "Packet created at " + x + " " + y);
    }

    /**
     * Initializes a new Packet instance
     *
     * @param  x        X-coordinate of the Packet
     * @param  y        Y-coordinate of the Packet
     * @param  colorstr The packet's color represented by a String
     */
    public Packet(int x, int y, String colorstr) {
        this(x, y, MyColor.getColor(colorstr));
    }

    /**
     * Gets the color of this Packet
     * @return This packet's color
     */
    public Color getColor() {
        return color;
    }

    /**
     * Returns a representation of this Packet
     *
     * @return A packet-representation
     */
    @Override
    public PacketRep getRepresentation() {
        return new PacketRep(getX(), getY(), getColor());
    }

    /**
     * Draws this Packet on the GUI.
     *
     * @param drawer The visiting drawer
     */
    public void draw(Drawer drawer) {
        drawer.drawPacket(this);
    }


    public String generateEnvironmentString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s\n", this.getClass().getName()));
        sb.append(String.format("nbArgs %d\n", 3));
        sb.append(String.format("Integer %d\n", this.getX()));
        sb.append(String.format("Integer %d\n", this.getY()));
        sb.append(String.format("String \"%s\"\n", MyColor.getName(this.color)));

        return sb.toString();
    }

}
