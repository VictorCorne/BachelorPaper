package environment.world.region.constraints;

import environment.*;
import environment.world.region.*;

import java.util.*;
import java.util.stream.*;

public class MustFullyCoverConstraint implements RegionWorldConstraint {

    @Override
    public boolean satisfiesConstraints(RegionWorld regionWorld) {
        List<Coordinate> coordinates = regionWorld.getEnvironment().getCoordinates();
        for (Coordinate coordinate : coordinates) {
            List<Region> regionsOfCoordinate = regionWorld.getRegions().stream().filter(o->o.isInRegion(coordinate)).collect(Collectors.toList());
            if(regionsOfCoordinate.size() != 1) return false;
        }
        return true;
    }

    @Override
    public void fixConstraints(RegionWorld regionWorld) {
        throw new RuntimeException("Recovering regionWorld who have not been fully covered has not been implemented yet");
    }
}
