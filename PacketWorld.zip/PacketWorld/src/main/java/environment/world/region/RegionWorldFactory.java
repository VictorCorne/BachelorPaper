package environment.world.region;

import environment.*;
import environment.world.region.constraints.*;

import java.util.*;

public class RegionWorldFactory {

    /**
     * Creates a RegionWorld from the given preset for the given environment
     */
    public static RegionWorld createNewRegionWorld(PRESET preset, Environment environment){
        return new RegionWorld(environment, preset.getStrategy(environment), preset.getConstraints(environment));
    }


    /**
     * A containter class for the factory presets
     */
    public interface PRESET {
        List<RegionWorldConstraint> getConstraints(Environment environment);
        CreateRegionsStrategy getStrategy(Environment environment);
    }

    public final static PRESET ENERGY_VORONOI = new PRESET() {
        @Override
        public List<RegionWorldConstraint> getConstraints(Environment environment) {
            return List.of(new MustFullyCoverConstraint(), new MustHaveEnergyStationsConstraint(environment));
        }

        @Override
        public CreateRegionsStrategy getStrategy(Environment environment) {
            return new VoronoiRegionsStrategy(environment.getEnergyStationWorld().getItemLocations());
        }
    };
    public final static PRESET ENERGY_SMALL_RECTANGLES = new PRESET() {
        @Override
        public List<RegionWorldConstraint> getConstraints(Environment environment) {
            return List.of(new MustFullyCoverConstraint(), new MustHaveEnergyStationsConstraint(environment));
        }

        @Override
        public CreateRegionsStrategy getStrategy(Environment environment) {
            return new RectangularRegionsStrategy(environment.getWidth() / 10, environment.getHeight() / 10);
        }
    };
    public final static PRESET ENERGY_BIG_RECTANGLES = new PRESET() {
        @Override
        public List<RegionWorldConstraint> getConstraints(Environment environment) {
            return List.of(new MustFullyCoverConstraint(), new MustHaveEnergyStationsConstraint(environment));
        }

        @Override
        public CreateRegionsStrategy getStrategy(Environment environment) {
            return new RectangularRegionsStrategy(environment.getWidth() / 3, environment.getHeight() / 3);
        }
    };
}
