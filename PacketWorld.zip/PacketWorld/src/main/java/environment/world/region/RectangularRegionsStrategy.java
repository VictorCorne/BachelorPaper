package environment.world.region;

import environment.*;

import java.util.*;


/**
 * This strategy consists of dividing the environment into a number of different slices of equal size
 */
public class RectangularRegionsStrategy implements CreateRegionsStrategy {

    /**
     * The number of different regions in x and y
     */
    private final int nbXRegions, nbYRegions;

    public RectangularRegionsStrategy(int nbXRegions, int nbYRegions) {
        this.nbXRegions = nbXRegions;
        this.nbYRegions = nbYRegions;
    }

    /**
     * Creates the regions of the regionworld by dividing it into different x and y strips
     */
    @Override
    public void createRegions(RegionWorld regionWorld) {
        int w = regionWorld.getEnvironment().getWidth(), h = regionWorld.getEnvironment().getHeight();
        float xsliceDim = (float) w / (float) nbXRegions,
                ysliceDim = (float) h/(float) nbYRegions;

        List<Region> regions = new ArrayList<>();
        for (int xindex = 0; xindex < nbXRegions; xindex++)
            for (int yindex = 0; yindex < nbYRegions; yindex++)
                regions.add(initSlice((int) (xindex * xsliceDim), (int) ((xindex + 1) * xsliceDim),
                          (int) (yindex * ysliceDim), (int) ((yindex + 1) * ysliceDim)
                ));

        regions.forEach(regionWorld::addRegion);
    }

    /**
     * Initializes a new slice of the regionworld and adds it to the list of regions.
     * The newly created region is a rectangle spanning from the x-bounds and the y-bounds
     * and is initialized with a scheduler (if present)
     */
    private Region initSlice(int fromX, int toX, int fromY, int toY) {
        List<Coordinate> regCoors = getCoordinatesFromRegion(fromX, toX, fromY, toY);
        return new Region(regCoors);
    }

    /**
     * Returns all the coordinates that would be in a region, within the given limits
     */
    private List<Coordinate> getCoordinatesFromRegion(int fromX, int toX, int fromY, int toY){
        List<Coordinate> regCoors = new ArrayList<>();
        for (int x = fromX; x < toX; x++)
            for (int y = fromY; y < toY; y++)
                regCoors.add(new Coordinate(x, y));
        return regCoors;
    }
}
