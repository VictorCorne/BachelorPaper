package environment.world.region.constraints;

import environment.*;
import environment.world.region.*;

import java.util.*;
import java.util.stream.*;

/**
 * This constraint states that each region must have at least one representative in it.
 */
public class MustHaveRepresentativesConstraint implements RegionWorldConstraint {

    public MustHaveRepresentativesConstraint(Collection<Coordinate> representatives) {
        this.representatives = representatives;
    }

    /**
     * The collection of all the representatives in the regionworld
     */
    Collection<Coordinate> representatives;

    /**
     * A regionWorld satisfies the constraints if and only if each region contains a representative
     */
    @Override
    public boolean satisfiesConstraints(RegionWorld regionWorld) {
        return getInvalidRegions(regionWorld).isEmpty();
    }

    /**
     * The solution for regions who do not have a representative is to dissolve them
     */
    @Override
    public void fixConstraints(RegionWorld regionWorld) {
        getInvalidRegions(regionWorld).forEach(regionWorld::dissolveRegion);
    }

    private List<Region> getInvalidRegions(RegionWorld regionWorld){
        return regionWorld.getRegions().stream().filter(o->!isValidRegion(o)).collect(Collectors.toList());
    }

    /**
     * A region is valid if and only if at least one representative is inside the region
     */
    private boolean isValidRegion(Region region){
        List<Coordinate> regionCoords = region.getCoordinates();
        for (Coordinate reprCoord : representatives) {
            if(regionCoords.stream().anyMatch(o->o.equals(reprCoord))) return true;
        }
        return false;
    }
}
