package environment.world.region.constraints;

import environment.*;

import java.util.*;

public class MustHaveEnergyStationsConstraint extends MustHaveRepresentativesConstraint{

    public MustHaveEnergyStationsConstraint(Environment environment) {
        super(environment.getEnergyStationWorld().getItemLocations());
    }
}
