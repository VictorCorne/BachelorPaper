package environment.world.region;

import environment.*;

import java.util.*;

public class Region implements Cloneable{

    // CONSTRUCTOR
    public Region(List<Coordinate> coordinates) {
        this.coordinates = coordinates;
    }

    // COORDINATES

    private final List<Coordinate> coordinates;
    public void addCoordinate(Coordinate coordinate){
        coordinates.add(coordinate);
    }

    public List<Coordinate> getCoordinates() {
        return coordinates;
    }


    // HELPER METHODS
    public boolean isInRegion(Coordinate coordinate){
        return coordinates.contains(coordinate);
    }

    /**
     * Returns the coordinate in this region that is the closest to the one given as a parameter
     */
    public Coordinate getClosestCoordinateTo(Coordinate other){
        return getCoordinates().stream().min(Comparator.comparing(o->o.distance(other))).get();
    }

    public Coordinate getClosestCoordinatePythagoreanDistanceTo(Coordinate other){
        return getCoordinates().stream().min(Comparator.comparing(o->o.pythagoreanDistance(other))).get();
    }

    /**
     * Returns all the coordinates of the parameter who are also in this region.
     */
    public List<Coordinate> getAllMatchingCoordinates(List<Coordinate> otherCoords){
        List<Coordinate> itemsInRegion = new ArrayList<>();
        for (var c : otherCoords) {
            if(isInRegion(c)) itemsInRegion.add(c);
        }
        return itemsInRegion;
    }

    /**
     * Adds all the coordinates of the given region to this region's coordinates
     */
    public void absorbRegion(Region secondRegion) {
        this.coordinates.addAll(secondRegion.coordinates);
    }

    @Override
    public Region clone() {
        try {
            return (Region) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return null;
    }
}