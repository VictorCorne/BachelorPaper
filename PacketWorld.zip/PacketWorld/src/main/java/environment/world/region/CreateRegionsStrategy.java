package environment.world.region;

public interface CreateRegionsStrategy {

    public abstract void createRegions(RegionWorld regionWorld);
}
