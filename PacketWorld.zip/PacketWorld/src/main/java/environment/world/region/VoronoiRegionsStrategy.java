package environment.world.region;

import environment.*;

import java.util.*;


/**
 * This strategy of creating regions consists of creating regions such that each coordinate belongs to the region represented by its closest representant.
 *
 * To read more : https://en.wikipedia.org/wiki/Voronoi_diagram
 */
public class VoronoiRegionsStrategy implements CreateRegionsStrategy {

    // FIXED POINTS

    /**
     * The points this strategy uses to partition the regions
     */
    final private Collection<Coordinate> points;

    /**
     * Returns the given list of points with the duplicates removed
     * @param points
     */
    private Collection<Coordinate> removeDuplicates(Collection<Coordinate> points){
        List<Coordinate> res = new ArrayList<>();
        for (var pt : points) {
            if(!res.contains(pt)) res.add(pt);
        }
        return res;
    }

    // CONSTRUCTOR

    public VoronoiRegionsStrategy(Collection<Coordinate> points) {
        if(points.isEmpty()) throw new RuntimeException("The given points must not be empty");
        this.points = removeDuplicates(points);
    }

    // IMPLEMENTING ABSTRACT METHODS

    @Override
    public void createRegions(RegionWorld regionWorld) {
        Map<Coordinate, List<Coordinate>> partitions = generatePartitions(regionWorld);
        List<Region> regions = generateRegionsFromPartition(partitions);
        regions.forEach(regionWorld::addRegion);
    }

    // HELPER METHODS

    /**
     * Takes a partition-map as input and returns a list of regions
     */
    private List<Region> generateRegionsFromPartition(Map<Coordinate, List<Coordinate>> coordinateListMap){
        List<Region> res = new ArrayList<>();
        for (var a  : coordinateListMap.entrySet()) {
            res.add(new Region(a.getValue()));
        }
        return res;
    }

    /**
     * Returns a map containing each point used for making a partition and its respective partition.
     */
    private Map<Coordinate, List<Coordinate>> generatePartitions(RegionWorld regionWorld){
        Map<Coordinate, List<Coordinate>> pointRegionMap = new HashMap<>();
        // Init the points in the map
        for (Coordinate point : points) {
            pointRegionMap.put(point, new ArrayList<>());
        }

        for (int x = 0; x < regionWorld.getEnvironment().getWidth(); x++) {
            for (int y = 0; y < regionWorld.getEnvironment().getHeight(); y++) {
                Coordinate worldCoord = new Coordinate(x,y);
                Coordinate closestPoint = getClosestPoint(worldCoord);
                pointRegionMap.get(closestPoint).add(worldCoord);
            }
        }

        return pointRegionMap;
    }

    /**
     * Returns the closest point of this strategy's fixed point relative to the given parameter
     */
    private Coordinate getClosestPoint(Coordinate coordinate){
        // We use the pythagorean distance because it makes more sense.
        // To visualise why, please run a (large-ish) environment where 4 schedulers are placed in a rectangular fashion, the central coordinates are close enough to
        // all schedulers.
        return points.stream().min(Comparator.comparing(o->o.pythagoreanDistance(coordinate))).get();
    }
}
