package environment.world.region.constraints;

import environment.world.region.*;

public interface RegionWorldConstraint {

    boolean satisfiesConstraints(RegionWorld regionWorld);

    void fixConstraints(RegionWorld regionWorld);
}
