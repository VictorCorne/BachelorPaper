package environment.world.region;

import environment.*;
import environment.world.region.constraints.*;

import java.util.*;

/**
 * The regionworld describes how the world is divided within a number of different regions
 */
public class RegionWorld {

    /**
     * Creates a new regionworld with the given strategy, who satisfies all the given constraints
     */
    public RegionWorld(Environment environment, CreateRegionsStrategy strategy, List<RegionWorldConstraint> constraints){
        this.environment = environment;
        this.constraints = constraints;
        this.strategy = strategy;

        strategy.createRegions(this);
        correctInitCheck();
    }


    // GENERATION

    private final List<RegionWorldConstraint> constraints;
    private final CreateRegionsStrategy strategy;


    // FINDING REGIONS
    public Region findRegionOfCoordinate(Coordinate coordinate) {
        return regions.stream().filter(region -> region.isInRegion(coordinate)).findFirst().orElse(null);
    }

    public boolean isNotInAnyRegion(Coordinate coordinate) {
        return findRegionOfCoordinate(coordinate) == null;
    }

    // REGIONS

    /**
     * The collection of the different regions in this world
     */
    private final List<Region> regions = new ArrayList<>();

    void addRegion(Region region) {
        if(!regions.contains(region)) regions.add(region);
    }

    public List<Region> getRegions() {
        return regions;
    }

    // ENVIRONMENT

    /**
     * A pointer to the environment
     */
    private final Environment environment;

    public Environment getEnvironment() {
        return environment;
    }

    // HELPER METHODS

    /**
     * Goes over all the constraints of this regionworld and if one notices that this regionworld has not been correctly inited, it will try to fix it.
     */
    private void correctInitCheck() {
        for (var constraint : constraints) {
            if (!constraint.satisfiesConstraints(this)) constraint.fixConstraints(this);
        }
    }


    // METHODS TO REDISTRIBUTE REGIONS

    /**
     * Removes the second region from the collection of regions of this regionworld and adds all its coordinates to the first region
     * @param firstRegion   The region that will inherit all the coordinates of the second region
     * @param secondRegion  The region that will disappear and whose coordinates will go to the first region
     */
    public void mergeRegions(Region firstRegion, Region secondRegion){
        getRegions().remove(secondRegion);
        firstRegion.absorbRegion(secondRegion);
    }

    /**
     * Removes this region from this regionWorld's List and redistributes its coordinates to the closest region
     * @param region    The region to be dissolved
     */
    public void dissolveRegion(Region region) {
        getRegions().remove(region);
        Map<Region, List<Coordinate>> toAdd = new HashMap<>();
        for (Coordinate c : region.getCoordinates()) {
            Region closestRegion = getRegions().stream().min(Comparator.comparing(o->o.getClosestCoordinatePythagoreanDistanceTo(c).pythagoreanDistance(c))).get();
            if(!toAdd.containsKey(closestRegion)) toAdd.put(closestRegion, new ArrayList<>());
            toAdd.get(closestRegion).add(c);
        }
        toAdd.forEach((r,c) -> c.forEach(o->r.addCoordinate(o)));
    }
}
