package environment.world.energystation;

import agent.*;
import agent.behavior.managingSystem.*;
import environment.*;

import java.util.*;
import java.util.stream.*;

public class EnergyStationStatistics {

    Map<Coordinate, Statistic> statisticMap = new HashMap<>();

    public EnergyStationStatistics(Environment environment){
        initMap(environment.getEnergyStationWorld());
    }

    public void reset(){
        statisticMap.values().forEach(o->o.reset());
    }

    public void update(AgentImplementations ais, int currentTurn){
        List<EnergyManagementBehavior> behaviors = ais.getAllAgentBehaviors().stream().map(o-> ((EnergyManagementBehavior) o)).collect(Collectors.toList());
        for (Map.Entry<Coordinate, Statistic> entry : statisticMap.entrySet()) {
            boolean anyPresent = ais.getAgentAt(entry.getKey()) != null;
            boolean anyReserved = behaviors.stream().anyMatch(o->o.getManagementStrategy().hasSlotAtLocationTime(entry.getKey(), currentTurn));
            entry.getValue().update(anyPresent, anyReserved);
        }
    }

    private void initMap(EnergyStationWorld world){
        for (var c : world.getAllItems()) {
            statisticMap.put(c.getChargingFieldCoord(), new Statistic());
        }
    }


    /**
     * Returns the occupancy rate at the given location
     */
    public final double getOccupancyRateAtLocation(Coordinate location){
        if (!statisticMap.containsKey(location)) throw new IllegalArgumentException("There is no station at the location");
        var stat = statisticMap.get(location);
        try {
            return (double) stat.nbTurnsPresent / ((double) stat.totalUpdates);
        }catch (ArithmeticException zeroExc){
            return 0d;
        }
    }

    /**
     * Returns the percentage at which agents have reserved this location up to this point.
     */
    public final double getReservationRateAtLocation(Coordinate location){
        if (!statisticMap.containsKey(location)) throw new IllegalArgumentException("There is no station at the location");
        var stat = statisticMap.get(location);
        try {
            return (double) stat.nbTurnsReserved / ((double) stat.totalUpdates);
        }catch (ArithmeticException zeroExc){
            return 0d;
        }
    }

    /**
     * Returns the total number of turns an agent was supposed to be present at the location but none showed up
     */
    public final int getPresenceDeficit(Coordinate location){
        if (!statisticMap.containsKey(location)) throw new IllegalArgumentException("There is no station at the location");
        var stat = statisticMap.get(location);
        return stat.getPresenceDeficit();
    }

    /**
     * Returns the percentage of turns an agent was supposed to be present at the location but none showed up
     */
    public final double getPresenceDeficitPercentage(Coordinate location){
        if (!statisticMap.containsKey(location)) throw new IllegalArgumentException("There is no station at the location");
        var stat = statisticMap.get(location);
        int deficit = stat.getPresenceDeficit();
        return (double) deficit / (double) stat.totalUpdates;
    }

    public int getTotalDeficit() {
        return statisticMap.values().stream().mapToInt(Statistic::getPresenceDeficit).sum();
    }

    public double getAverageReservationRate() {
        return statisticMap.keySet().stream().mapToDouble(o->getReservationRateAtLocation(o)).sum() / statisticMap.size();
    }

    /**
     * Inner class to help calculate statistics
     */
    private final static class Statistic {

        public void update(boolean agentPresent, boolean agentReserved){
            if(agentReserved) canUpdate = true;

            if(canUpdate){
                totalUpdates++;
                if(agentPresent) nbTurnsPresent++;
                if(agentReserved) nbTurnsReserved++;
            }
        }

        public int getPresenceDeficit(){
            return nbTurnsReserved - nbTurnsPresent;
        }

        int totalUpdates;
        int nbTurnsPresent;
        int nbTurnsReserved;
        boolean canUpdate = false;

        public void reset() {
            totalUpdates = 0;
            nbTurnsReserved = 0;
            nbTurnsPresent = 0;
            canUpdate = false;
        }
    }
}