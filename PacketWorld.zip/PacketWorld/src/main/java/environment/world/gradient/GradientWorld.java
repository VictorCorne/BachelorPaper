package environment.world.gradient;

import java.util.*;

import com.google.common.eventbus.EventBus;

import environment.*;
import environment.world.energystation.*;
import support.Influence;

public class GradientWorld extends World<Gradient> {

    /**
     * Initialize the GradientWorld
     */
    public GradientWorld(EventBus eventBus) {
        super(eventBus);
    }


    /**
     * Place a collection of gradients inside the Gradient World.
     *
     * @param gradients The collection of gradients.
     */
    @Override
    public void placeItems(Collection<Gradient> gradients) {
        gradients.forEach(this::placeItem);
    }

    /**
     * Place a single gradient in the Gradient World.
     *
     * @param item The gradient.
     */
    @Override
    public void placeItem(Gradient item) {
        putItem(item);
    }

    public void initGradients(Environment environment){
        for (int w = 0; w < environment.getWidth(); w++) {
            for (int h = 0; h < environment.getHeight(); h++) {
                placeItem(new Gradient(w,h, distanceToClosestChargerField(environment.getEnergyStationWorld(), new Coordinate(w,h))));
            }
        }
    }

    private int distanceToClosestChargerField(EnergyStationWorld stationWorld, Coordinate from) {
        var closest =  stationWorld.getAllItems().stream()
                .min(Comparator.comparing(o->o.getChargingFieldCoord().distance(from)));
        return closest.isEmpty() ? 0 : closest.get().getChargingFieldCoord().distance(from);
    }

    @Override
    protected void effectuate(Influence inf) {}
}
