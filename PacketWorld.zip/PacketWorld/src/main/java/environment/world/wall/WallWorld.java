package environment.world.wall;

import java.util.Collection;

import com.google.common.eventbus.EventBus;

import environment.World;
import support.Influence;
import util.Debug;

/**
 * A class for a WallWorld, being a layer of the total world, that contains Walls.
 */
public class WallWorld extends World<Wall> {

    /**
     * Initializes a new WallWorld instance
     */
    public WallWorld(EventBus eventBus) {
        super(eventBus);
    }

    /**
     * Returns a string representation of this World
     *
     * @return "WallWorld"
     */
    public String toString() {
        return "WallWorld";
    }

    /**
     * Brings a given influence in effect in this world.
     * This method knows the effects of certain influences and realizes them
     * in this world.
     *
     * @param inf The influence to bring in effect
     */
    @Override
    public void effectuate(Influence inf) {
        //no-op, nothing is done in this world (yet)
    }

    /**
     * Adds Walls to this WallWorld.
     *
     * @param walls An array containing the walls to add to this world
     */
    @Override
    public void placeItems(Collection<Wall> walls) {
        walls.forEach(this::placeItem);
    }

    /**
     * Adds a Wall to this WallWorld.
     *
     * @param wall The walls to place in this world
     */
    @Override
    public void placeItem(Wall wall) {
        try {
            this.putItem(wall);
        } catch (ClassCastException exc) {
            Debug.alert(this, "Can only place a Wall in WallWorld.");
        }
    }
}
