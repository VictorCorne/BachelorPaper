package environment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import java.util.Vector;

import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.Subscribe;

import agent.AgentImplementations;
import environment.world.agent.Agent;
import environment.world.destination.Destination;
import environment.world.energystation.EnergyStation;
import environment.world.packet.Packet;
import environment.world.wall.Wall;
import synchronizer.CentralSynchronization;
import synchronizer.Synchronization;
import util.AsciiReader;
import util.Debug;
import util.Variables;
import util.event.GameOverEvent;

/**
 * This is the main class for the GUI application.
 * It allows for the setup and initialisation of the application.
 */
@SuppressWarnings("FieldCanBeLocal")
public class ApplicationRunner {

    //--------------------------------------------------------------------------
    //		CONSTRUCTOR
    //--------------------------------------------------------------------------

    /**
     * Initializes a new Setup object
     */
    public ApplicationRunner() {
        this.eventBus = new EventBus();
        this.eventBus.register(this);
    }


    @Subscribe
    private void handleGameOverEvent(GameOverEvent event) {
        this.stop();
    }


    //--------------------------------------------------------------------------
    //		INSPECTORS
    //--------------------------------------------------------------------------

    public boolean isCustom() {
        return custom;
    }

    public synchronized void checkSuspended() {
        if (steps > 0) {
            steps--;
        }

        try {
            if (!stepMode) {
                // Only sleep when in play mode, no need to stall execution when manually
                // walking through step by step
                Thread.sleep(playSpeed);
            }
        } catch (InterruptedException ignored) {}
        try {
            synchronized (dummy) {
                while (paused() || (stepMode && steps <= 0)) {
                    dummy.wait();
                }
            }
        } catch (InterruptedException ignored) {}
    }

    //--------------------------------------------------------------------------
    //		MUTATORS
    //--------------------------------------------------------------------------


    public void prepareAgents() {
        ais.startAllAgentImps();
    }



    public void play() {
        if (stopped) {
            return;
        }
        stepMode = false;
        pause = false;
        synchronized (dummy) {
            dummy.notify();
        }
    }

    public void stop() {
        setPaused();
        stopped = true;
    }

    public void reset() {
        stopped = false;
        pause = false;

        synchronized (dummy) {
            dummy.notify();
        }
        env.finish();
        ais.finish();
        env = null;
        ais = null;
        aObjects.clear();
        make(isCustom());
    }

    public boolean paused() {
        return pause;
    }

    public void setPaused() {
        this.pause = true;
    }

    public void step() {
        if (stopped) {
            return;
        }
        stepMode = true;
        pause = false;
        steps++;
        synchronized (dummy) {
            dummy.notify();
        }
    }


    /**
     * Initializes the core modules of the application
     *
     * @param isCustom whether to create a custom world or not
     * @post    an Environment instance is created and the contents of the
     *          environment package are set up
     * @post    an Synchronization instance is created and the contents of the
     *          synchronization package are set up
     * @post    an AgentImplementations instance is created and the contents
     *          of the AgentImplementations package are set up
     * @post    A gui is built and shown containing the play grid and related
     *          items
     */
    public void make(boolean isCustom) {
        setCustom(isCustom);
        Environment env = null;

        if (isCustom) {
            env = new Environment(DEFAULT_WORLD_WIDTH, DEFAULT_WORLD_HEIGHT);
            createCustomWorlds(getDefaultWorlds(), env, eventBus, DEFAULT_WORLD_WIDTH, DEFAULT_WORLD_HEIGHT, 
                DEFAULT_NB_AGENTS, DEFAULT_VIEW, DEFAULT_NB_PACKET_KINDS, DEFAULT_NB_PACKETS_PER_KIND);
        } else {
            env = initializeEnvironment(Variables.ENVIRONMENTS_PATH + getEnvFile() + ".txt");
        }

        if (env == null) {
            Debug.alert(this, "env is null !!");
        }
        setEnvironment(env);
        Synchronization sync = null;
        if (getSyncMode().equals("Central synchronization")) {
            sync = new CentralSynchronization();
        }

        if (sync == null) {
            Debug.alert(this, "sync is null !!");
        }
        AgentImplementations ais = new AgentImplementations();
        setAgentImplementations(ais);

        sync.setEnvironment(env);
        env.setAgentImplementations(ais);
        ais.setEnvironment(env);
        sync.setAgentImplementations(ais);
        ais.setSynchronizer(sync);
        env.createEnvironment(this, eventBus);
        try {
            ais.createAgentImps(getNbAgents(), implementation, eventBus);
            ais.createObjectImps(getActiveObjects());
            sync.createSynchroPackage();
        } catch (Exception e) {
            Debug.alert(this, "Error during setup.make() " + e.getMessage());
        }
    }

    /**
     * Instantiates the worlds.
     *
     * @param worldClasses the classes of the worlds to create
     * @param env          the environment
     */
    public static void createWorlds(List<Class<? extends World<?>>> worldClasses, Environment env, EventBus eventBus, int width, int height) {
        for (Class<? extends World<?>> worldClass : worldClasses) {
            try {
                World<?> w = worldClass.getDeclaredConstructor(EventBus.class).newInstance(eventBus);
                w.initialize(width, height, env);

                env.addWorld(w);
            } catch (Exception e) {
                throw new RuntimeException("Could not create all the different worlds.\n" + e.getStackTrace());
            }
        }
    }


    /**
     * Creates the provided worlds and populates the agent, packet and desination worlds
     * randomly according to the provided parameters.
     * 
     * @param worldClasses The classes of all the worlds that should be initiliazed.
     * @param env The environment in which to create all the worlds and objects.
     * @param width The width of the environment to be created.
     * @param height The height of the environment to be created.
     * @param nbAgents The number of agents to be randomly created in the world.
     * @param view The view of the agents to be created.
     * @param nbPacketKinds The number of types of packets to be added.
     * @param nbPacketsPerKind The number of packets per type to be added to the world.
     */
    private static void createCustomWorlds(List<Class<? extends World<?>>> worldClasses, Environment env, EventBus eventBus,
                                           int width, int height, int nbAgents, int view, int nbPacketKinds, int nbPacketsPerKind) {

        ApplicationRunner.createWorlds(worldClasses, env, eventBus, width, height);
        env.getAgentWorld().createWorld(nbAgents, view);
        env.getPacketWorld().createWorld(nbPacketKinds, nbPacketsPerKind);
        env.getDestinationWorld().createWorld(nbPacketKinds);
    }


    /**
     * Initialize the environment and ApplicationRunner according to the provided
     * environment configuration file.
     * 
     * @param configFile The configuration file containing the environment.
     * @return The environment created according to the provided configuration file.
     */
    public Environment initializeEnvironment(String configFile) {
        aObjects.clear();

        Environment env = ApplicationRunner.createEnvFromFile(configFile, this.eventBus);

        this.setEnvironment(env);

        // Add active objects retroactively
        env.getEnergyStationWorld().getItems().stream()
            .flatMap(List::stream)
            .filter(Objects::nonNull)
            .forEach(this::addActiveObject);

        this.setNbAgents(env.getNbAgents());
            
        return env;
    }

    /**
     * Creates an environment from a file.
     *
     * @param  configFile A textfile with a configuration of an environment
     * @param  eventBus   The event bus on which to publish events in the application.
     * @return            A new environment created from the description in
     *                    the specified file
     */
    public static Environment createEnvFromFile(String configFile, EventBus eventBus) {
        try {
            AsciiReader reader = new AsciiReader(configFile);
            // Initiate Worlds

            reader.check("width");
            int width = reader.readInt();
            reader.check("height");
            int height = reader.readInt();

            Environment env = new Environment(width, height);

            createWorlds(getDefaultWorlds(), env, eventBus, width, height);

            // Initiate Items

            // Agents
            reader.check("nbAgents");

            int nbAgents = reader.readInt();

            Collection<Agent> agents = new ArrayList<>();
            for (int i = 0; i < nbAgents; i++) {
                Agent agent = (Agent) reader.readClassConstructor();
                agent.setEnvironment(env);
                agents.add(agent);
            }


            // Packets
            reader.check("nbPackets");
            int nbPackets = reader.readInt();

            Collection<Packet> packets = new ArrayList<>();
            for (int i = 0; i < nbPackets; i++) {
                packets.add((Packet) reader.readClassConstructor());
            }


            // Destinations
            reader.check("nbDestinations");
            int nbDest = reader.readInt();

            Collection<Destination> destinations = new ArrayList<>();
            for (int i = 0; i < nbDest; i++) {
                destinations.add((Destination) reader.readClassConstructor());
            }

            // Walls
            reader.check("nbWalls");
            int nbWalls = reader.readInt();

            Collection<Wall> walls = new ArrayList<>();
            for (int i = 0; i < nbWalls; i++) {
                walls.add((Wall) reader.readClassConstructor());
            }

            // EnergyStations
            reader.check("nbEnergyStations");
            int nbBatteries = reader.readInt();

            Collection<EnergyStation> batteries = new ArrayList<>();
            for (int i = 0; i < nbBatteries; i++) {
                EnergyStation energyStation = (EnergyStation) reader.readClassConstructor();
                batteries.add(energyStation);
            }

            // If no energy stations in the world -> do not keep agent's battery in mind during execution of actions
            EnergyValues.ENERGY_ENABLED = nbBatteries != 0;


            env.getAgentWorld().placeItems(agents);
            env.getPacketWorld().placeItems(packets);
            env.getDestinationWorld().placeItems(destinations);
            env.getWallWorld().placeItems(walls);
            env.getEnergyStationWorld().placeItems(batteries);
            env.getGradientWorld().initGradients(env);
            return env;
        } catch (FileNotFoundException e) {
            System.err.println("Environment config file not found: " +
                               configFile + "\n" + e.getMessage());
        } catch (IOException e) {
            System.err.println("Something went wrong while reading: " +
                               configFile + "\n" + e.getMessage());
        } catch (NullPointerException e) {
            System.err.println(
                "Something went wrong while creating the environment. " +
                "Probably not all kinds of items are defined" +
                "in the config file.");
        } catch (Exception e) {
            throw e;
        }

        return null;
    }


    /**
     * Loads a list of properties from a file into an array
     *
     * @param filename the name of the properties file
     * @return an array with the loaded properties
     */
    public static String[] getPropertiesFromFile(String filename) {
        Properties prop = new Properties();
        try {
            FileInputStream sf = new FileInputStream(filename);
            prop.load(sf);
        } catch (Exception e) {
            System.err.println("Error with properties file " + filename + " : " + e);
        }
        String[] propStrings = new String[prop.size()];
        for (int i = 1; i <= propStrings.length; i++) {
            propStrings[i - 1] = prop.getProperty(String.valueOf(i));
        }
        return propStrings;
    }

    //--------------------------------------------------------------------------
    //		GETTERS & SETTERS
    //--------------------------------------------------------------------------
    @SuppressWarnings("unchecked")
    public static List<Class<? extends World<?>>> getDefaultWorlds() {
        String[] worldNames = getPropertiesFromFile(Variables.WORLD_PROPERTIES_FILE);
        List<Class<? extends World<?>>> result = new ArrayList<>();

        for (String name : worldNames) {
            try {
                result.add((Class<? extends World<?>>) Class.forName(name));
            } catch (ClassNotFoundException | ClassCastException e) {
                e.printStackTrace();
                throw new RuntimeException("Could not add world with name " + name);
            }
        }

        return result;
    }

    public String getImplementation() {
        return implementation;
    }

    public String getSyncMode() {
        return syncMode;
    }

    public int getNbPacketKinds() {
        return nbPacketKinds;
    }

    public int getNbAgents() {
        return nbAgents;
    }

    public int getNbPacketsPerKind() {
        return nbPacketsPerKind;
    }

    public Vector<ActiveItem<?>> getActiveObjects() {
        return aObjects;
    }

    public int getView() {
        return view;
    }

    public int getSpeed() {
        return playSpeed;
    }

    public String getEnvFile() {
        return envFile;
    }

    public Environment getEnvironment() {
        return env;
    }

    public AgentImplementations getAgentImplementations() {
        return ais;
    }

    public EventBus getEventBus() {
        return eventBus;
    }



    /**
     * Sets the implementation of this Setup
     * @param s The new implementation value
     */
    public void setImplementation(String s) {
        implementation = s;
    }

    /**
     * Sets the syncMode of this Setup
     * @param s The new syncMode value
     */
    public void setSyncMode(String s) {
        syncMode = s;
    }

    /**
     * Sets the amount of different kinds of packets
     * @param nbKinds The new nbPacketKinds value
     */
    public void setNbPacketKinds(int nbKinds) {
        nbPacketKinds = nbKinds;
    }

    /**
     * Sets the number of agents
     * @param nbAgents the new nbAgents value
     */
    public void setNbAgents(int nbAgents) {
        this.nbAgents = nbAgents;
    }

    /**
     * Sets the amount of packets per kind of packet
     * @param nb The new nbPacketsPerKind value
     */
    public void setNbPacketsPerKind(int nb) {
        nbPacketsPerKind = nb;
    }

    /**
     * Add an active object to the environment
     * @param aObject the newly created active object to add
     */
    public void addActiveObject(ActiveItem<?> aObject) {
        aObjects.add(aObject);
    }


    /**
     * Sets the range of view for agents
     * @param v The new view value
     */
    public void setView(int v) {
        view = v;
    }

    public void setEnvFile(String fileName) {
        envFile = fileName;
    }

    public void setSpeed(int s) {
        playSpeed = s;
    }

    public void setCustom(boolean cust) {
        this.custom = cust;
    }

    public void setEnvironment(Environment env) {
        this.env = env;
    }

    private void setAgentImplementations(AgentImplementations ais) {
        this.ais = ais;
    }

    //--------------------------------------------------------------------------
    //		ATTRIBUTES
    //--------------------------------------------------------------------------

    private final String DEFAULT_SYNCMODE = "Central synchronization";
    private final int DEFAULT_WORLD_WIDTH = 16;
    private final int DEFAULT_WORLD_HEIGHT = 16;
    private final int DEFAULT_NB_AGENTS = 4;
    private final int DEFAULT_NB_PACKET_KINDS = 4;
    private final int DEFAULT_NB_PACKETS_PER_KIND = 5;
    private final int DEFAULT_VIEW = 3;

    private String implementation;
    private String envFile;
    private String syncMode = DEFAULT_SYNCMODE;
    private int nbPacketKinds;
    private int nbPacketsPerKind;
    private int nbAgents;
    private final Vector<ActiveItem<?>> aObjects = new Vector<>();
    private int view;
    private boolean custom;

    private Environment env = null;
    private AgentImplementations ais = null;

    private final Object dummy = new Object();
    private int steps = 0;
    private boolean pause = true;
    private boolean stepMode = false;
    private boolean stopped = false;
    private int playSpeed = 100;
    private final EventBus eventBus;

}
