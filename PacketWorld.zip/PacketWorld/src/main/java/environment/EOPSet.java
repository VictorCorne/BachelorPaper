package environment;

/**
 * @super
 * A class facilitating the communication between Spheres and the EOPHandler.
 */
public class EOPSet extends ToHandle {

    public EOPSet(Sphere sender) {
        super(sender);
    }

}
