import gui.setup.*;

/**
 * The quick-launch allows to start the application without going through the process of setting up the environment and selecting the implementations.
 * This is particularly useful for quick debugging.
 */
public class QuickLaunch {

//    public static final String implFile = "basic";
    public static final String implFile = "slave";
//    public static final String implFile = "regional";
//    public static final String implFile = "informationSharing";

//    public static final String envFile = "scattered_25Agents";
    public static final String envFile = "clumps_20Agents";
//    public static final String envFile = "ring_32Agents";

//    public static final String envFile = "workDensity_24Agents";
//    public static final String envFile = "demo";
//    public static final String envFile = "mist";

    public static final int playSpeed = 50;

    public static final boolean autoStart = true;

    public static void main(String[] args) throws InterruptedException {
        GUISetup setup = new GUISetup();

        setup.getApplicationRunner().setImplementation(implFile);
        setup.getApplicationRunner().setEnvFile(envFile);
        setup.getApplicationRunner().setSpeed(playSpeed);

        setup.getApplicationRunner().make(false);
        setup.startGui();
        if(autoStart) setup.userPanel.playActionListener.actionPerformed(null);
    }
}