package gui.video;

import agent.behavior.managingSystem.communicationStrategy.regionalPlannerBehavior.*;
import com.google.common.eventbus.*;
import environment.*;
import environment.world.agent.*;
import environment.world.destination.*;
import environment.world.energystation.*;
import environment.world.packet.*;
import environment.world.pheromone.*;
import environment.world.region.*;
import util.*;
import util.event.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;


/**
 * Panel for the videopanel containing the grid of the world.
 */
public class VideoPanel extends JPanel {

    //--------------------------------------------------------------------------
    //		CONSTRUCTOR
    //--------------------------------------------------------------------------

    public VideoPanel() {
        drawer = new ItemDrawer();
    }

    //--------------------------------------------------------------------------
    //		INSPECTORS
    //--------------------------------------------------------------------------

    //--------------------------------------------------------------------------
    //		MUTATORS
    //--------------------------------------------------------------------------


    @Subscribe
    private void handleWorldProcessedEvent(WorldProcessedEvent event) {
        this.repaint();
    }

    public void warning(String message) {
        JOptionPane.showMessageDialog(this, message);
    }


    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (started) {
            getDrawer().init(g, getWidth(), getHeight(),
                             getEnvironment().getWidth(),
                             getEnvironment().getHeight(), getBackground());

            getDrawer().drawGrid();
            getDrawer().clear();

            try {
                //Draw Pheromones (those which fill the whole area),
                Environment env = getEnvironment();

                drawItems(env.getWorld(PheromoneWorld.class).getItemsCopied());
                drawItems(env.getWorld(EnergyStationWorld.class).getItemsCopied());

                Collection<World<?>> worlds = env.getWorlds();
                for (World<?> world : worlds) {
                    if (!(world instanceof PheromoneWorld ||
                            world instanceof EnergyStationWorld)) {
                        drawItems(world.getItemsCopied());
                    }
                }

                tryDrawRegions();
            } catch (NullPointerException exc) {
                Debug.alert(this, "Error while painting the components. " +
                            "Probably one of the needed worlds is not defined.\n");
            }
        }
    }

    private void tryDrawRegions() {
        try{
            RegionalBehavior rb = (RegionalBehavior) env.getAgentImplementations().getAllAgentBehaviors().get(0);
            if(rb.getRegionSchedulerMap() == null) return;
            var regions = rb.getRegionSchedulerMap().getAllRegions();
            int nbRegions = regions.size();
            for (Region region : regions) {
                float regionPercent = (float) regions.indexOf(region) / nbRegions;
                Color color = Color.getHSBColor(regionPercent, .75f, .85f);
                color = new Color(color.getRed(), color.getGreen(), color.getBlue(), 70);
                getDrawer().drawRegion(region, color);
            }
        }catch (NullPointerException | ClassCastException e){
            return;
        }
    }

    public void initiate() {
        started = true;
        repaint();
    }

    private <T extends Item<?>> void drawItems(List<List<T>> items) {
        for (int i = 0; i < getEnvironment().getWidth(); i++) {
            for (int j = 0; j < getEnvironment().getHeight(); j++) {
                if (items.get(i).get(j) != null) {
                    items.get(i).get(j).draw(getDrawer());
                }
            }
        }
    }

    private void redrawAgent(Agent agent) {
        int ax = agent.getX();
        int ay = agent.getY();
        getDrawer().clearItem(ax, ay);
        agent.draw(getDrawer());
    }

    public void putPacket(int toX, int toY, Item<?> oldTo, Packet packet, Agent agent) {
        if (! (oldTo instanceof Destination)) {
            packet.draw(getDrawer());
        }
        redrawAgent(agent);
    }

    public void pickPacket(int fromX, int fromY, Packet packet, Agent agent) {
        redrawAgent(agent);
    }

    public void moveAgent(int fromX, int fromY, int toX, int toY, Agent agent) {
        getDrawer().clearItem(fromX, fromY);
        agent.draw(getDrawer());
    }

    public void refresh() {
        repaint();
    }

    public void step(int fx, int fy, int tx, int ty, Agent agent) {
        repaint();
    }

    public void put(int tx, int ty, Packet packet, Agent agent) {
        repaint();
    }

    public void pick(int px, int py, Packet packet, Agent agent) {
        repaint();
    }

    public void step() {
        repaint();
    }

    public void put() {
        repaint();
    }

    public void pick() {
        repaint();
    }


    //--------------------------------------------------------------------------
    //		GETTERS & SETTERS
    //--------------------------------------------------------------------------

    public void setEnvironment(Environment environ) {
        this.env = environ;
    }

    public Environment getEnvironment() {
        return env;
    }
    private ItemDrawer getDrawer() {
        return drawer;
    }

    //--------------------------------------------------------------------------
    //		ATTRIBUTES
    //--------------------------------------------------------------------------

    private Environment env;
    boolean started;

    /**
     * Visitor for the drawing of items.
     */
    private final ItemDrawer drawer;
}

