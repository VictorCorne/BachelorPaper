package gui.video;

import com.google.common.eventbus.*;
import environment.*;
import gui.setup.*;
import util.communicationHelper.*;
import util.event.*;

import javax.swing.*;
import javax.swing.plaf.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import static util.communicationHelper.CommunicationValues.getCommunicationQuantityString;


public class UserPanel extends JPanel {

    public UserPanel(GUISetup guiSetup, VideoPanel videoPanel) {
        this.guiSetup = guiSetup;
        ApplicationRunner applicationRunner = guiSetup.getApplicationRunner();

        setLayout(new BorderLayout());
        add(new JLabel(), "North");

        var gridbag = new GridBagLayout();
        JPanel buttonPanel = new JPanel(gridbag);
        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.BOTH;
        // c.anchor = GridBagConstraints.CENTER;
        c.weightx = 1;

        scoreLabel = new JLabel(" Energy = " + score);
        gridbag.setConstraints(scoreLabel, c);
        messagesLabel = new JLabel("Messages = ");
        gridbag.setConstraints(messagesLabel, c);
        deliveredLabel = new JLabel("Packets delivered = " + delivered);
        gridbag.setConstraints(deliveredLabel, c);

        cycliLabel = new JLabel(" Cycles = " + nbCycli);
        gridbag.setConstraints(cycliLabel, c);
        
        c.gridwidth = GridBagConstraints.REMAINDER;
        var speedLabel = new JLabel("Simulation speed");
        speedLabel.setHorizontalAlignment(JLabel.CENTER);
        gridbag.setConstraints(speedLabel, c);

        buttonPanel.add(scoreLabel);
        buttonPanel.add(messagesLabel);
        buttonPanel.add(deliveredLabel);
        buttonPanel.add(cycliLabel);
        buttonPanel.add(speedLabel); // For spacing


        var defaultButtonSizeX = 200;
        var defaultButtonSizeY = 25;

        c.weightx = 0;
        c.gridheight = 2;

        c.fill = GridBagConstraints.NONE;
        c.gridwidth = GridBagConstraints.BOTH;
        c.insets = new InsetsUIResource(0, 0, 0, 5);
        // c.anchor = GridBagConstraints.CENTER;

        playButton = new JButton("play");
        playButton.setEnabled(true);
        playButton.setPreferredSize(new Dimension(defaultButtonSizeX, defaultButtonSizeY));
        playButton.setMaximumSize(new Dimension(defaultButtonSizeX, defaultButtonSizeY));
        gridbag.setConstraints(playButton, c);
        buttonPanel.add(playButton);


        pauseButton = new JButton("pause");
        pauseButton.setEnabled(false);
        pauseButton.setPreferredSize(new Dimension(defaultButtonSizeX, defaultButtonSizeY));
        pauseButton.setMaximumSize(new Dimension(defaultButtonSizeX, defaultButtonSizeY));
        gridbag.setConstraints(pauseButton, c);
        buttonPanel.add(pauseButton);

        stepButton = new JButton("step");
        stepButton.setEnabled(true);
        stepButton.setPreferredSize(new Dimension(defaultButtonSizeX, defaultButtonSizeY));
        stepButton.setMaximumSize(new Dimension(defaultButtonSizeX, defaultButtonSizeY));
        gridbag.setConstraints(stepButton, c);
        buttonPanel.add(stepButton);

        restartButton = new JButton("reset");
        restartButton.setEnabled(false);
        restartButton.setPreferredSize(new Dimension(defaultButtonSizeX, defaultButtonSizeY));
        restartButton.setMaximumSize(new Dimension(defaultButtonSizeX, defaultButtonSizeY));
        gridbag.setConstraints(restartButton, c);
        buttonPanel.add(restartButton);

        playActionListener = ev -> {
            if (!agentsStarted) {
                agentsStarted = true;
                applicationRunner.prepareAgents();
            }
            applicationRunner.play();
            playButton.setEnabled(false);
            stepButton.setEnabled(false);
            restartButton.setEnabled(true);
            pauseButton.setEnabled(true);
        };

        playButton.addActionListener(playActionListener);

        pauseButton.addActionListener(ev -> {
            applicationRunner.setPaused();
            this.playButton.setEnabled(true);
            this.stepButton.setEnabled(true);
            this.pauseButton.setEnabled(false);
        });

        stepButton.addActionListener(ev -> {
            if (!agentsStarted) {
                agentsStarted = true;
                applicationRunner.prepareAgents();
            }
            applicationRunner.step();
            this.restartButton.setEnabled(true);
        });

        restartButton.addActionListener(ev -> {
            guiSetup.reset();
            videoPanel.setEnvironment(applicationRunner.getEnvironment());
            videoPanel.repaint();
            agentsStarted = false;
            this.playButton.setEnabled(true);
            this.stepButton.setEnabled(true);
            this.pauseButton.setEnabled(false);
            this.restartButton.setEnabled(false);
        });

        playSpeed = new JSlider(0, 2000, 100);
        playSpeed.setPreferredSize(new Dimension(250, 50));
        playSpeed.setMajorTickSpacing(250);
        playSpeed.setMinorTickSpacing(50);
        playSpeed.setPaintTicks(true);
        playSpeed.setSnapToTicks(true);
        Dictionary<Integer, JLabel> ticks = new Hashtable<>();
        ticks.put(0, new JLabel("Fast"));
        ticks.put(2000, new JLabel("Slow"));
        playSpeed.setLabelTable(ticks);
        playSpeed.setPaintLabels(true);
        
        
        playSpeed.addChangeListener(e -> applicationRunner.setSpeed(playSpeed.getValue()));
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.gridheight = 2;
        c.fill = GridBagConstraints.BOTH;
        gridbag.setConstraints(playSpeed, c);

        buttonPanel.add(playSpeed);
        add(new JLabel(" "), BorderLayout.CENTER);
        add(buttonPanel, "South");


        applicationRunner.getEventBus().register(this);
    }

    

    @Subscribe
    public void handleAgentActionEvent(AgentActionEvent event) {
        score += EnergyValues.calculateEnergyCost(event, false);

        if (event.getAction() == AgentActionEvent.DELIVER) {
            delivered++;
        }

        this.repaint();
    }


    @Subscribe
    public void handleMsgSentEvent(MsgSentEvent event) {
        msgs++;
        msgInfo += event.getMsg().getCommunicationSize();
        this.repaint();
    }


    @Subscribe
    void handleWorldProcessedEvent(WorldProcessedEvent e) {
        nbCycli++;
        this.repaint();
    }



    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (scoreLabel != null) {
            scoreLabel.setText(" Energy = " + score);
            messagesLabel.setText("Messages = " + msgs + "= " + getCommunicationQuantityString(msgInfo));
            deliveredLabel.setText("Packets delivered = " + delivered);
            cycliLabel.setText(" Cycles = " + nbCycli);
        }
    }


    public void reset() {
        this.score = 0;
        this.msgs = 0;
        msgInfo = 0;
        this.delivered = 0;
        this.nbCycli = 0;

        this.repaint();
    }


    final JLabel scoreLabel;
    final JLabel messagesLabel;
    final JLabel deliveredLabel;
    final JLabel cycliLabel;

    int score = 0;
    int msgs = 0;
    int msgInfo = 0;
    int delivered = 0;
    int nbCycli = 0;

    public final JButton playButton;
    final JButton stepButton;
    final JButton pauseButton;
    final JButton restartButton;
    final JSlider playSpeed;

    final GUISetup guiSetup;

    boolean agentsStarted = false;


    public ActionListener playActionListener;
}
