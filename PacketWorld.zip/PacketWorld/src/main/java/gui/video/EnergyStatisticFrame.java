package gui.video;

import agent.*;
import com.google.common.eventbus.*;
import environment.*;
import environment.world.energystation.*;
import util.event.*;

import javax.swing.*;
import java.util.*;
import java.util.stream.*;

/**
 * Used for visually seeing which agent has a reservation when and where
 */
public class EnergyStatisticFrame extends JFrame {

    public EnergyStatisticFrame(Environment environment) {
        nbRow = environment.getAgentImplementations().getNbEnergyStations();
        energyStationCoords = environment.getAgentImplementations().getAllEnergyStations().stream().map(o->o.getChargingFieldLocation()).collect(Collectors.toList());
        ais = environment.getAgentImplementations();

        Object[][] data = new Object[nbRow+1][5];
        for (int i = 0; i < nbRow; i++) {
            data[i][0] = energyStationCoords.get(i);
        }
        data[nbRow][0] = "Total";

        Object[] columns = {"Battery coordinate", "Reservation rate", "Occupancy rate", "Presence deficit (absolute)", "Presence deficit (relative)"};
        jTable = new JTable(data, columns);
        jScrollPane1 = new JScrollPane(jTable);
        energyStationStatistics = new EnergyStationStatistics(environment);
    }

    @Subscribe
    private void handleWorldProcessedEvent(WorldProcessedEvent event) {
        currentTurn ++;
        energyStationStatistics.update(ais, currentTurn);
        for (Coordinate coordinate : energyStationCoords) {
            updateRow(coordinate);
        }
        jTable.setValueAt(energyStationStatistics.getTotalDeficit(),nbRow,3);
    }

    private void updateRow(Coordinate coordinate){
        int rowNb = energyStationCoords.indexOf(coordinate);
        double reserv = energyStationStatistics.getReservationRateAtLocation(coordinate) * 100;
        double occup = energyStationStatistics.getOccupancyRateAtLocation(coordinate) * 100;
        int deficitAbs = energyStationStatistics.getPresenceDeficit(coordinate);
        double deficitRel = energyStationStatistics.getPresenceDeficitPercentage(coordinate) * 100;

        jTable.setValueAt(String.format("%.2f", reserv) + "%", rowNb, 1);
        jTable.setValueAt(String.format("%.2f", occup) + "%", rowNb, 2);
        jTable.setValueAt(String.format("%d", deficitAbs), rowNb, 3);
        jTable.setValueAt(String.format("%.2f", deficitRel) + "%", rowNb, 4);

    }


    public void reset(AgentImplementations agents) {
        energyStationStatistics.reset();
        this.ais = agents;
        currentTurn = 0;
    }

    public void initialize() {
        jTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_LAST_COLUMN);

        jTable.getColumnModel().getColumn(0).setPreferredWidth(100);
        jTable.getColumnModel().getColumn(1).setPreferredWidth(75);
        jTable.getColumnModel().getColumn(2).setPreferredWidth(75);



        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);
        setSize(new java.awt.Dimension(350, 75 + jTable.getRowHeight() * jTable.getRowCount()));

        setTitle("Slot-reservations");
        jScrollPane1.getViewport().add(jTable);
        setLocation(0,700);
    }

    int nbRow;
    final List<Coordinate> energyStationCoords;
    int currentTurn = 0;

    private AgentImplementations ais;
    private EnergyStationStatistics energyStationStatistics;

    private final JTable jTable;
    private final JScrollPane jScrollPane1;
}
