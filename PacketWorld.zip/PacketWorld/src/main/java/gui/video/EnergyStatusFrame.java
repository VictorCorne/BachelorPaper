package gui.video;

import agent.*;
import agent.behavior.managingSystem.*;
import agent.behavior.schedule.*;
import com.google.common.eventbus.*;
import util.custom.statistics.*;
import util.event.*;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

/**
 * Used for visually seeing which agent has a reservation when and where
 */
public class EnergyStatusFrame extends JFrame{

    AgentImplementations ais;
    int[] ids;

    public EnergyStatusFrame(AgentImplementations ais) {
        this.ais = ais;
        Object[] columns = {"AgentID", "Reservation", "Moving to reservation", "Living status", "Number of reservations", "Percentage time spent in meta mode"};

        Object[][] data = new Object[ais.getNbAgents()+1][columns.length];
        ids = ais.getAllAgentID();
        for (int i = 0; i < ais.getNbAgents(); i++) {
            data[i][0] = "" + ids[i];
        }

        jTable = new JTable(data, columns);
        jTable.getColumnModel().getColumn(2).setCellRenderer(new ColorCellRenderer());
        jTable.getColumnModel().getColumn(3).setCellRenderer(new ColorCellRenderer());

        jScrollPane1 = new JScrollPane(jTable);
        agentBehaviorStatistics = new AgentBehaviorStatistics(ais);
    }


    @Subscribe
    private void handleWorldProcessedEvent(WorldProcessedEvent event) {
        agentBehaviorStatistics.update(ais);
        for (AgentImp agent : ais.getAllAgents()) {
            EnergyManagementBehavior behavior = ((EnergyManagementBehavior) agent.getCurrentBehavior());
            int rowNb = agent.getID()-1;

            TimeSlot scheduledItem = behavior.getFirstScheduledItem();
            String description = scheduledItem == null ? "No slot" : scheduledItem.toString();
            jTable.getModel().setValueAt(description, rowNb, 1);

            if(behavior.isMovingToStation(agent))jTable.setValueAt(Color.green, rowNb, 2);
            else jTable.setValueAt(Color.gray, rowNb, 2);

            Color livingCol = Color.green;
            if(behavior.livingStatus == EnergyManagementBehavior.LIVING_STATUS.DEATH_HAD_SLOT) livingCol = Color.ORANGE;
            if(behavior.livingStatus == EnergyManagementBehavior.LIVING_STATUS.DEATH_NO_SLOT) livingCol = Color.RED;
            jTable.setValueAt(livingCol, rowNb, 3);

            int nbRes = behavior.getAllTimeSlots().size();
            jTable.setValueAt(nbRes, rowNb, 4);

            double percentMeta = agentBehaviorStatistics.getPercentTurnsSpentInMetaModeForAgent(agent.getID()) * 100;
            jTable.setValueAt(String.format("%.2f", percentMeta), rowNb, 5);
        }
        double percentTotal = agentBehaviorStatistics.getPercentageSpentInMetaMode() * 100;
        jTable.setValueAt(String.format("%.2f", percentTotal), ais.getNbAgents(), 5);
    }

    private AgentBehaviorStatistics agentBehaviorStatistics;


    public void reset(AgentImplementations ais){
        this.ais = ais;
        agentBehaviorStatistics.reset(ais);
    }

    public void initialize() {
        jTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_LAST_COLUMN);

        jTable.getColumnModel().getColumn(0).setPreferredWidth(20);
        jTable.getColumnModel().getColumn(1).setPreferredWidth(200);
        jTable.getColumnModel().getColumn(2).setPreferredWidth(20);
        jTable.getColumnModel().getColumn(3).setPreferredWidth(20);
        jTable.getColumnModel().getColumn(4).setPreferredWidth(20);
        jTable.getColumnModel().getColumn(5).setPreferredWidth(80);


        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);
        setSize(new java.awt.Dimension(300, 75 + jTable.getRowHeight() * jTable.getRowCount()));

        setTitle("Slot-reservations");
        jScrollPane1.getViewport().add(jTable);
    }

    private final JTable jTable;
    private final JScrollPane jScrollPane1;

    private static class ColorCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
            JLabel l = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
            l.setBackground((Color) table.getValueAt(row, col));
            l.setText("");
            return l;
        }
    }
}
