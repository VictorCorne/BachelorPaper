package gui.video;

import com.google.common.eventbus.*;
import environment.*;
import gui.setup.*;
import util.*;
import util.custom.*;
import util.event.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;

@SuppressWarnings("FieldCanBeLocal")
public class BatchMAS extends JFrame {

    public static void main(String[] arg) {
        BatchMAS prog = new BatchMAS();
        prog.setVisible(true);
    }

    /**
     * The ultrabatch is an experimental feature to test all run configurations.
     */
    private static final boolean allowUltraBatch = false;

    // Backwards compatibility
    public void init() {}

    public BatchMAS() {
        this.applicationRunner = new ApplicationRunner();

        initialize();
        this.setSize(new Dimension(710, 400));
        this.setLocation(new Point(30, 30));
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        textFieldNrRuns.setText(Integer.toString(DEFAULT_NB_RUNS));

        processButton.setEnabled(true);
        allRunButton.setEnabled(true);
        abortButton.setEnabled(false);
        textFieldNrRuns.setEnabled(true);

        this.applicationRunner.getEventBus().register(this);
    }


    /**
     * Called each time a simulation has been finished.
     * If this wasn't the last simulation, a new one will start
     * Otherwise, the batch ends
     */
    @Subscribe
    private void handleGameOverEvent(GameOverEvent e) {
        endRun(e);
        // restart a new run
        if (Integer.parseInt(textFieldNrRuns.getText()) > indexCurrentRun) {
            indexCurrentRun++;
            startRun(indexCurrentRun);
        } else {
            finishBatch();
            if(isIteratorMode()){
                startNewBatch();
            }
        }
    }

    private void finishBatch() {
        writeRunData();
        this.setStatus("Done.", new Color(20, 140, 30));

        batchObserver.onEndSimulation();
        batchObserver = null;

        allRunButton.setEnabled(true);
        processButton.setEnabled(true);
        abortButton.setEnabled(false);
        textFieldNrRuns.setEnabled(true);
    }

    private void startNewBatch() {
        processButtonActionPerformed(null);
    }

    public void restartRun() {
        applicationRunner.getEventBus().post(new GameOverEvent(this, false));
    }

    /**
     * Called each time a turn in the simulator has been processed.
     * It updates the nrCycles counter, updates the labels and repaints objects on the frame
     */
    @Subscribe
    private void handleWorldProcessedEvent(WorldProcessedEvent e) {
        updateProgressBar();
        nrCycles++;
        labelCurrentRunAdj.setText("" + indexCurrentRun);
        labelEnergySpent.setText("" + eventTracker.getEnergySpent());
        labelDeliveredPackets.setText("" + (nrStartPackets - nrCurrentPackets));
        progressBar.setValue(Math.round(progress));
        panelRunInformation.repaint();
        batchObserver.onWorldProcessedEvent(e);
    }



    /**
     * Creates all components
     */
    public void initialize() {
        //int labelSizeX = 34;
        int labelSizeX = 70;
        int labelSizeY = 25;


        implementationList = new JComboBox<>(WorldConfigurationPanel.getDirList(Variables.IMPLEMENTATIONS_PATH));
        environmentList = new JComboBox<>(WorldConfigurationPanel.getDirList(Variables.ENVIRONMENTS_PATH));

        implementationList.addItemListener(e -> updateOutputFile());
        environmentList.addItemListener(e -> updateOutputFile());

        labelEnergySpent.setText("");
        labelEnergySpent.setMinimumSize(new java.awt.Dimension(labelSizeX, labelSizeY));
        labelEnergySpent.setMaximumSize(new java.awt.Dimension(labelSizeX, labelSizeY));
        labelEnergySpent.setPreferredSize(new java.awt.Dimension(labelSizeX, labelSizeY));
        labelEnergySpent.setHorizontalAlignment(SwingConstants.RIGHT);
        labelEnergySpent.setToolTipText("");
        labelDeliveredPackets.setText("");
        labelDeliveredPackets.setMinimumSize(new java.awt.Dimension(labelSizeX, labelSizeY));
        labelDeliveredPackets.setMaximumSize(new java.awt.Dimension(labelSizeX, labelSizeY));
        labelDeliveredPackets.setPreferredSize(new java.awt.Dimension(labelSizeX, labelSizeY));
        labelDeliveredPackets.setHorizontalAlignment(SwingConstants.RIGHT);
        labelDeliveredPackets.setToolTipText("");
        textPane.setText("");
        textPane.setBounds(new java.awt.Rectangle(149, 74, 76, 6));
        textPane.setPreferredSize(new java.awt.Dimension(420, 6));
        textPane.setEditable(false);
        scrollPaneRunOutput.setBorder(javax.swing.BorderFactory.createLineBorder(new
            java.awt.Color(0, 0, 0), 1));
        scrollPaneRunOutput.setPreferredSize(new java.awt.Dimension(420, 200));
//        scrollPaneRunOutput.setMinimumSize(new java.awt.Dimension(420, 200));
        scrollPaneRunOutput.setBackground(new java.awt.Color(212, 208, 200));
        scrollPaneRunOutput.setSize(new java.awt.Dimension(420, 259));


        JLabel labelEnvironmentFile = new JLabel("Environment:   ");
        labelEnvironmentFile.setToolTipText("");
        JLabel labelImplementationFile = new JLabel("Agent implementation:   ");
        labelImplementationFile.setToolTipText("");
        JLabel labelOutputFile = new JLabel("Output file:   ");
        labelOutputFile.setToolTipText("");

        JLabel labelNrRuns = new JLabel("Number of runs: ");
        labelNrRuns.setToolTipText("");
        labelNrRuns.setVerticalAlignment(javax.swing.SwingConstants.CENTER);
        JLabel labelCurrentRun = new JLabel("Current run: ");
        labelCurrentRun.setToolTipText("");
        JLabel labelEnergySpent = new JLabel("Energy spent in this run: ");
        labelEnergySpent.setToolTipText("");
        JLabel labelPacketsDelivered = new JLabel("Packets delivered this run: ");
        labelPacketsDelivered.setToolTipText("");

        JLabel estimatedTimeAverage = new JLabel("Estimated time average: ");



        panelRunInformation.setBounds(new java.awt.Rectangle(3, 96, 10, 10));
        panelRunInformation.setLayout(new java.awt.GridBagLayout());
        panelRunInformation.setAlignmentX(0.5f);
        panelRunInformation.setAlignmentY(0.5f);

        panelRunInformation.add(labelNrRuns,
            new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER,
                GridBagConstraints.HORIZONTAL,
                new Insets(0, 0, 0, 0), 0, 0));
        panelRunInformation.add(labelCurrentRun,
            new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
                GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0, 0, 0, 0), 0, 0));

        panelRunInformation.add(textFieldNrRuns,
            new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER,
                GridBagConstraints.NONE,
                new Insets(0, 0, 0, 0), 0, 0));
        panelRunInformation.add(labelCurrentRunAdj,
            new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
                GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0, 0, 0, 0), 0, 0));

        panelRunInformation.add(labelEnergySpent,
            new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
                GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0, 0, 0, 0), 0, 0));
        panelRunInformation.add(this.labelEnergySpent,
            new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0,
                GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0, 0, 0, 0), 0, 0));

        panelRunInformation.add(labelPacketsDelivered,
            new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0,
                GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0, 0, 0, 0), 0, 0));
        panelRunInformation.add(labelDeliveredPackets,
            new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
                GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0, 0, 0, 0), 0, 0));

        panelRunInformation.add(estimatedTimeAverage,
                new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0,
                        GridBagConstraints.WEST, GridBagConstraints.NONE,
                        new Insets(0, 0, 0, 0), 0, 0));
        panelRunInformation.add(labelETA,
                new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0,
                        GridBagConstraints.WEST, GridBagConstraints.NONE,
                        new Insets(0, 0, 0, 0), 0, 0));



        labelOutputFile.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        labelOutputFile.setVerticalAlignment(javax.swing.SwingConstants.CENTER);
        panelConfigurationInput.setPreferredSize(new java.awt.Dimension(420, 120));
        panelConfigurationInput.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelConfigurationInput.setLayout(new java.awt.GridBagLayout());
        panelConfigurationInput.setMinimumSize(new java.awt.Dimension(200, 44));
        panelConfigurationInput.add(labelImplementationFile,
            new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
                    GridBagConstraints.WEST,
                    GridBagConstraints.NONE,
                    new Insets(5, 5, 5, 5), 0, 0));
        panelConfigurationInput.add(labelEnvironmentFile,
            new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
                    GridBagConstraints.WEST,
                    GridBagConstraints.NONE,
                    new Insets(5, 5, 5, 5), 0, 0));
        panelConfigurationInput.add(labelOutputFile,
            new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
                    GridBagConstraints.WEST,
                    GridBagConstraints.NONE,
                    new Insets(5, 5, 5, 5), 0, 0));
        panelConfigurationInput.add(implementationList,
            new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
                    GridBagConstraints.CENTER,
                    GridBagConstraints.NONE,
                    new Insets(5, 5, 5, 5), 0, 0));
        panelConfigurationInput.add(environmentList,
            new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
                    GridBagConstraints.CENTER,
                    GridBagConstraints.NONE,
                    new Insets(5, 5, 5, 5), 0, 0));
        panelConfigurationInput.add(scrollPaneOutputFile,
            new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0,
                    GridBagConstraints.CENTER,
                    GridBagConstraints.NONE,
                    new Insets(5, 5, 5, 5), 0, 0));

        implementationList.setMinimumSize(new Dimension(200, 20));
        implementationList.setPreferredSize(new Dimension(300, 20));

        environmentList.setMinimumSize(new Dimension(200, 20));
        environmentList.setPreferredSize(new Dimension(300, 20));


        scrollPaneOutputFile.setMinimumSize(new Dimension(200, 40));
        scrollPaneOutputFile.setPreferredSize(new Dimension(300, 40));
        scrollPaneOutputFile.getViewport().add(outputFile);
        scrollPaneOutputFile.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        ((DefaultCaret) outputFile.getCaret()).setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        outputFile.getDocument().addDocumentListener(new DocumentListener() {

            @Override
            public void changedUpdate(DocumentEvent e) {}

            @Override
            public void insertUpdate(DocumentEvent e) {
                var bar = scrollPaneOutputFile.getHorizontalScrollBar();
                Optional<Point> caretPos = Optional.ofNullable(outputFile.getCaret().getMagicCaretPosition());
                int desired = caretPos.map(p -> (int) p.getX()).orElse(bar.getMaximum());
                bar.setValue(Math.max(desired - 30, 30));
            }

            @Override
            public void removeUpdate(DocumentEvent arg0) {}
        });
        outputFile.setText(getDefaultOutputFile());
        scrollPaneOutputFile.getHorizontalScrollBar().setValue(scrollPaneOutputFile.getHorizontalScrollBar().getMaximum());

        panelConfiguration.setLayout(new javax.swing.BoxLayout(panelConfiguration,
            javax.swing.BoxLayout.X_AXIS));
        panelConfiguration.add(panelConfigurationInput);
        panelConfiguration.add(panelRun);
        setBounds(new java.awt.Rectangle(0, 0, 661, 393));
        setTitle("PacketWorld batch run program");
        getContentPane().add(panelRunOutput, java.awt.BorderLayout.CENTER);
        getContentPane().add(jToolBar1, java.awt.BorderLayout.SOUTH);
        getContentPane().add(panelConfiguration, java.awt.BorderLayout.NORTH);
        panelRun.setPreferredSize(new java.awt.Dimension(200, 10));
        panelRun.setSize(new java.awt.Dimension(50, 60));
        panelRun.add(processButton);
        panelRun.add(abortButton);
        panelRun.add(progressBar);
        if(allowUltraBatch) panelRun.add(allRunButton);
        //processButton.setText("jButton1");
        //processButton.setLabel("Process");
        allRunButton.setText("Ultra-batch");
        allRunButton.setToolTipText("Runs all the possible configurations of environment with the selected implementation. WARNING, it may be buggy");
        processButton.setText("Process");
        jToolBar1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.
            swing.border.BevelBorder.LOWERED));
        jToolBar1.setMinimumSize(new java.awt.Dimension(4, 20));
        jToolBar1.setMaximumSize(new java.awt.Dimension(4, 20));
        jToolBar1.setPreferredSize(new java.awt.Dimension(4, 20));
        jToolBar1.add(status);
        this.setStatus("");
        status.setAlignmentX(0.0f);
        status.setToolTipText("");
        status.setForeground(new java.awt.Color(255, 51, 51));
        panelRunOutput.setLayout(new javax.swing.BoxLayout(panelRunOutput,
            javax.swing.BoxLayout.X_AXIS));
        panelRunOutput.add(scrollPaneRunOutput);
        panelRunOutput.add(panelRunInformation);
        progressBar.setValue(0);
        //abortButton.setText("jButton1");
        //abortButton.setLabel("Abort");
        abortButton.setText("Abort");
        abortButton.addActionListener(this::abortButtonActionPerformed);
        processButton.addActionListener(this::processButtonActionPerformed);
        scrollPaneRunOutput.getViewport().add(textPane);
        scrollPaneRunOutput.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        ((DefaultCaret) textPane.getCaret()).setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        labelCurrentRunAdj.setText("");
        labelCurrentRunAdj.setMinimumSize(new java.awt.Dimension(labelSizeX, labelSizeY));
        labelCurrentRunAdj.setMaximumSize(new java.awt.Dimension(labelSizeX, labelSizeY));
        labelCurrentRunAdj.setPreferredSize(new java.awt.Dimension(labelSizeX, labelSizeY));
        labelCurrentRunAdj.setHorizontalAlignment(SwingConstants.RIGHT);
        labelCurrentRunAdj.setToolTipText("");

        labelETA.setText("");
        labelETA.setMinimumSize(new java.awt.Dimension(labelSizeX, labelSizeY));
        labelETA.setMaximumSize(new java.awt.Dimension(labelSizeX, labelSizeY));
        labelETA.setPreferredSize(new java.awt.Dimension(labelSizeX, labelSizeY));
        labelETA.setHorizontalAlignment(SwingConstants.RIGHT);
        labelETA.setToolTipText("");

        textFieldNrRuns.setMinimumSize(new java.awt.Dimension(75, 25));
        textFieldNrRuns.setPreferredSize(new java.awt.Dimension(75, 25));
    }


    /**
     * Routine for pressing abort button.
     * Stops simulation and resets GUI
     */
    public void abortButtonActionPerformed(ActionEvent e) {
        this.applicationRunner.stop();
        writeRunData();
        this.applicationRunner.reset();
        this.setStatus("Aborted!");
        batchObserver.onAbortActionPerformed();
        processButton.setEnabled(true);
        allRunButton.setEnabled(true);
        abortButton.setEnabled(false);
        textFieldNrRuns.setEnabled(true);
    }

    /**
     * Routine for pressing 'process' button. Reads setup file, creates simulation
     * and starts first run
     */
    public void processButtonActionPerformed(ActionEvent e) {
        runResults.clear();
        // Check value for number of runs
        try {
            Integer.parseInt(textFieldNrRuns.getText());
        } catch (NumberFormatException ignored) {
            this.setStatus("Invalid number of runs specified. Integer required.");
            return;
        }

        // Check if file exists -> ask for confirmation in case it does
        File file = new File(outputFile.getText());
        if (file.exists() && !isIteratorMode()) {
            var sure = JOptionPane.showConfirmDialog(this, "File already exists. Overwrite?",
                    "Overwrite file?", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

            if (sure != JOptionPane.YES_OPTION) {
                return;
            }
        }

        if (implementationList.getSelectedIndex() == -1 || environmentList.getSelectedIndex() == -1) {
            this.setStatus("Make sure you have correctly selected an implementation and environment.");
            return;
        }

        textPane.setText("");

        String impl, env;

        if(isIteratorMode()) {
            BatchConfig config;
            if(runIterator == null){
                initIterator(Integer.parseInt(textFieldNrRuns.getText()));
                config = runIterator.getFirst();
            }else{
                config = runIterator.next();
            }
            setSelectedImpFile(config.getImpString());
            setSelectedEnvFile(config.getEnvString());
            impl = config.getImpString();
            env = config.getEnvString();
            updateOutputFile(env, impl);
        }else {
            impl = getSelectedImplFile();
            env = getSelectedEnvFile();
        }

        this.setStatus("");
        this.applicationRunner.setImplementation(impl);
        this.applicationRunner.setEnvFile(env);
        this.applicationRunner.make(false);
//         Setup.getInstance().reset();

        eventTracker = new EventTracker(t -> {}, this.applicationRunner);

        batchObserver = new BatchObserver(true,this);

        processButton.setEnabled(false);
        abortButton.setEnabled(true);
        textFieldNrRuns.setEnabled(false);

        this.applicationRunner.setSpeed(0);

        //start execution
        indexCurrentRun = 1;
        startRun(1);
        batchObserver.onPressedStartButton(env, impl);
        resultsDescription = batchObserver.getStartString();
    }

    public void setSelectedEnvFile(String s){
        environmentList.setSelectedItem(s);
    }

    public void setSelectedImpFile(String s){
        implementationList.setSelectedItem(s);
    }

    private String getSelectedEnvFile() {
        return environmentList.getItemAt(environmentList.getSelectedIndex());
    }

    private String getSelectedImplFile(){
        return implementationList.getItemAt(implementationList.getSelectedIndex());
    }

    private void initIterator(int nbTurns){
        runIterator = new TestRunIterator(List.of(WorldConfigurationPanel.getDirList(Variables.ENVIRONMENTS_PATH)),
                                          getSelectedImplFile(),
                                          nbTurns);
    }


    /**
     * Starts a simulation run. Resets statistics and GUI
     */
    private void startRun(int nb) {
        nrStartPackets = this.applicationRunner.getEnvironment().getPacketWorld().getNbPackets();
        nrCurrentPackets = nrStartPackets;

        batchObserver.onStartRun(nb, applicationRunner.getEnvironment(), applicationRunner.getEventBus());

        this.applicationRunner.prepareAgents();
        this.applicationRunner.play();
    }

    private void applyBatchConfig(BatchConfig config){
        environmentList.setSelectedItem(config.getEnvString());
        implementationList.setSelectedItem(config.getImpString());
    }


    /**
     * Ends current simulation run. Resets simulation and prints statistics to log area
     * @param e
     */
    private void endRun(GameOverEvent e) {

        labelETA.setText(getEtaCalculator().getETA());
        panelRunInformation.repaint();

        if(SAVE_RESULTS) runResults.add(batchObserver.getResultString());
        this.applicationRunner.reset();
        batchObserver.onRunEnded(e);
        nrCycles = 0;
        eventTracker.reset();
    }

    private ETACalculator getEtaCalculator() {
        return batchObserver.getETACalculator();
    }


    /**
     * Updates progress bar
     */
    private void updateProgressBar() {
        nrCurrentPackets = this.applicationRunner.getEnvironment().getPacketWorld().
            getNbPackets();
        int nbrun = Integer.parseInt(textFieldNrRuns.getText());
        float relrun = 100 / (float) nbrun;
        progress = (indexCurrentRun - 1 +
                 ( (nrStartPackets - nrCurrentPackets) / (float) nrStartPackets)) * relrun;

    }


    /**
     * Writes a line of text in log area
     */
    public void textOut(String text) {
        textPane.setText(textPane.getText() + text);
    }


    /**
     * Writes away the data of the batched runs when it is time to stop to the specified output file in the output box.
     */
    private void writeRunData() {
        try {
            FileWriter writer = new FileWriter(outputFile.getText());
            writer.write(resultsDescription);
            writer.write(String.join("",runResults));
            writer.close();
        } catch (IOException ioe) {
            this.setStatus("Could not write to output file.");
        }
    }

    private void setStatus(String text) {
        this.setStatus(text, new Color(255, 51, 51));
    }

    private void setStatus(String text, Color color) {
        status.setForeground(color);
        status.setText(text);
    }

    private String getDefaultOutputFile() {
        return Variables.OUTPUT_PATH + " " + getSelectedEnvFile() + " " + getSelectedImplFile() + ".txt";
    }

    private void updateOutputFile(String env, String imp){
        outputFile.setText(Variables.OUTPUT_PATH + " " + env + " " + imp + ".txt");
    }

    private void updateOutputFile(){
        updateOutputFile(getSelectedEnvFile(), getSelectedImplFile());
    }


    int nrCurrentPackets;
    private int nrStartPackets;
    public int indexCurrentRun;
    int nrCycles = 0;
    private float progress;
    EventTracker eventTracker;

//    JSONArray resultsRuns;
    String resultsDescription;
    List<String> runResults = new LinkedList<>();

    private final JPanel panelConfigurationInput = new JPanel();

    private JComboBox<String> implementationList;
    private JComboBox<String> environmentList;
    private final JTextField outputFile = new JTextField();
    private final JScrollPane scrollPaneOutputFile = new JScrollPane();

    private final JPanel panelConfiguration = new JPanel();
    private final JPanel panelRun = new JPanel();
    private final JButton processButton = new JButton();
    private final JToolBar jToolBar1 = new JToolBar();
    private final JLabel status = new JLabel();
    private final JPanel panelRunOutput = new JPanel();
    private final JScrollPane scrollPaneRunOutput = new JScrollPane();
    private final JPanel panelRunInformation = new JPanel();
    private final JTextPane textPane = new JTextPane();
    private final JProgressBar progressBar = new JProgressBar();
    private final JCheckBox allRunButton = new JCheckBox();
    private final JButton abortButton = new JButton();
    public final JTextField textFieldNrRuns = new JTextField();
    private final JLabel labelCurrentRunAdj = new JLabel();
    private final JLabel labelEnergySpent = new JLabel();
    private final JLabel labelDeliveredPackets = new JLabel();
    private final JLabel labelETA = new JLabel();

    private BatchObserver batchObserver;
    TestRunIterator runIterator;
    private static final boolean SAVE_RESULTS = true;
    private static final int DEFAULT_NB_RUNS = 100;

    private final String DEFAULT_OUTPUT_FILE = Variables.OUTPUT_PATH + "outputBatch.txt";
    private ApplicationRunner applicationRunner;

    public EventTracker getEventTracker() {
        return eventTracker;
    }

    public int getNrCycles() {
        return nrCycles;
    }

    public int getNrCurrentPackets() {
        return nrCurrentPackets;
    }

    public int getIndexCurrentRun() {
        return indexCurrentRun;
    }

    public boolean isIteratorMode() {
        return allRunButton.isSelected();
    }
}
