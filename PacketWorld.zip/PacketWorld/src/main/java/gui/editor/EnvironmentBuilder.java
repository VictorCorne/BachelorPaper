package gui.editor;

import com.google.common.eventbus.*;
import environment.*;
import environment.world.agent.*;
import environment.world.destination.*;
import environment.world.energystation.*;
import environment.world.packet.*;
import environment.world.wall.*;
import gui.video.*;
import util.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.List;
import java.util.*;
import java.util.stream.*;

/**
 * A graphical editor for editing environment files.
 */
public class EnvironmentBuilder extends JFrame {

    public static void main(String[] arg) {
        EnvironmentBuilder builder = new EnvironmentBuilder();
        builder.init();
        builder.setVisible(true);
    }

    public void initColorList(boolean includeColorless) {
        jComboBoxColor.removeAllItems();

        if (includeColorless) {
            jComboBoxColor.addItem("None");
        }

        MyColor.getColors().stream()
            .map(MyColor::getName)
            .forEach(jComboBoxColor::addItem);
    }

    /**
     * Initializes the application. Calls initialize() and does some more init
     */
    public void init() {
        panel1 = videoPanel;
        initialize();
        initColorList(false);
        for (int i = 4; i <= MAXSIZE; i++) {
            jComboBoxWidth.addItem("" + i);
            jComboBoxHeight.addItem("" + i);
        }
        for (int i = 1; i <= MAXVIEW; i++) {
            jComboBoxView.addItem("" + i);
        }
        jComboBoxWidth.addActionListener(this::sizeActionPerformed);
        jComboBoxHeight.addActionListener(this::sizeActionPerformed);
        jComboBoxView.addActionListener(this::sizeActionPerformed);
        newFile();
    }

    /**
     * Creates all components
     */
    protected void initialize() {

        //getContentPane().add(panel3, java.awt.BorderLayout.SOUTH);
        getContentPane().add(panel2, java.awt.BorderLayout.NORTH);
        getContentPane().add(panel1, java.awt.BorderLayout.CENTER);
        panel2.setLayout(new java.awt.GridBagLayout());
        panel2.setSize(new java.awt.Dimension(481, 40));
        panel2.add(lblWidth,
            new java.awt.GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(jComboBoxWidth,
            new java.awt.GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(lblHeight,
            new java.awt.GridBagConstraints(2, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(jComboBoxHeight,
            new java.awt.GridBagConstraints(3, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(lblView,
            new java.awt.GridBagConstraints(4, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(jComboBoxView,
            new java.awt.GridBagConstraints(5, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(lblColor,
            new java.awt.GridBagConstraints(6, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(jComboBoxColor,
            new java.awt.GridBagConstraints(7, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(btnPacket,
            new java.awt.GridBagConstraints(8, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(btnDest,
            new java.awt.GridBagConstraints(9, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(btnAgent,
            new java.awt.GridBagConstraints(10, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(btnBattery,
            new java.awt.GridBagConstraints(11, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(btnWall,
            new java.awt.GridBagConstraints(12, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));
        panel2.add(btnRemove,
            new java.awt.GridBagConstraints(13, 0, 1, 1, 0.0, 0.0,
            java.awt.GridBagConstraints.CENTER,
            java.awt.GridBagConstraints.NONE,
            new java.awt.Insets(0, 0, 0, 0), 0, 0));

        lblColor.setText(" Color");
        jComboBoxColor.setSize(new java.awt.Dimension(60, 21));
        jComboBoxColor.setEnabled(false);
        btnPacket.setText("Packet");
        btnPacket.addActionListener(this::packetButtonActionPerformed);
        btnDest.setText("Destination");
        btnDest.setActionCommand("Destination");
        btnDest.addActionListener(this::destButtonActionPerformed);
        btnAgent.setText("Agent");
        btnAgent.addActionListener(this::agentButtonActionPerformed);
        btnBattery.setText("Battery");
        btnBattery.addActionListener(this::batteryButtonActionPerformed);
        btnWall.setText("Wall");
        btnWall.addActionListener(this::wallButtonActionPerformed);

        setResizable(true);
        setDefaultCloseOperation(javax.swing.JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                exitActionPerformed(e);
            }
        });

        setTitle(WINDOW_TITLE);
        setSize(new java.awt.Dimension(600, 800));
        //setBounds(new java.awt.Rectangle(0, 0, 731, 487));
        setBounds(new java.awt.Rectangle(0, 0, 1000, 800));
        lblWidth.setText("Width ");
        lblWidth.setToolTipText("");
        lblHeight.setText(" Height ");
        lblView.setText(" View ");
        btnRemove.setText("Remove");
        btnRemove.setToolTipText("");
        btnRemove.addActionListener(this::removeButtonActionPerformed);
        jComboBoxWidth.setPreferredSize(new java.awt.Dimension(50, 25));
        jComboBoxHeight.setPreferredSize(new java.awt.Dimension(50, 25));

        jComboBoxView.setMinimumSize(new java.awt.Dimension(50, 25));
        jComboBoxView.setSize(new java.awt.Dimension(30, 25));
        jComboBoxView.setPreferredSize(new java.awt.Dimension(50, 25));

        panel1.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                panelMouseClicked(e);
            }
        });
        panel1.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if(e.getButton() == MouseEvent.BUTTON1) panelMouseClicked(e);
                else if(e.getButton() == MouseEvent.BUTTON3){
                    switchWithSecondary();
                }
            }
        });
        /*
        button4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SaveActionPerformed(e);
            }
        });
        */

        //Menubar
        setJMenuBar(menuBar);

        //Menu File
        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        fileMenu.getAccessibleContext().setAccessibleDescription(
                "Opens the file menu");
        menuBar.add(fileMenu);

        JMenuItem menuItem;
        //File > New
        menuItem = new JMenuItem("New");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
        menuItem.getAccessibleContext().setAccessibleDescription(
                "Creates a new environment file");
        menuItem.addActionListener(this::newActionPerformed);
        fileMenu.add(menuItem);
        //File > Load
        menuItem = new JMenuItem("Open...");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_O, InputEvent.CTRL_DOWN_MASK));
        menuItem.getAccessibleContext().setAccessibleDescription(
                "Loads an environment file");
        menuItem.addActionListener(this::loadActionPerformed);
        fileMenu.add(menuItem);
        //File > Save
        menuItem = new JMenuItem("Save");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));
        menuItem.getAccessibleContext().setAccessibleDescription(
                "Saves the active environment file");
        menuItem.addActionListener(this::saveActionPerformed);
        fileMenu.add(menuItem);
        //File > Save as
        menuItem = new JMenuItem("Save as...");
        //menuItem.setAccelerator(KeyStroke.getKeyStroke(
        //        KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));
        menuItem.getAccessibleContext().setAccessibleDescription(
                "Saves the active environment file with a new name");
        menuItem.addActionListener(this::saveAsActionPerformed);
        fileMenu.add(menuItem);

        fileMenu.addSeparator();
        //File > Exit
        menuItem = new JMenuItem("Exit");
        menuItem.getAccessibleContext().setAccessibleDescription(
                "Quits the editor");
        menuItem.addActionListener(this::exitActionPerformed);
        fileMenu.add(menuItem);


    }

    private void addRandomPacket() {
        if(selected == Selection.Packet){
            int x = new Random().nextInt(env.getWidth());
            int y = new Random().nextInt(env.getHeight());

            List<Coordinate> figure = List.of(new Coordinate(1,0),
                                              new Coordinate(0,0),
                                              new Coordinate(-1,0),
                                              new Coordinate(0,-1),
                                              new Coordinate(0,1)
                                              );
            figure.forEach(o->{
                int i = x+o.getX();
                int j = y+o.getY();
                Packet p = new Packet(i, j, (String) jComboBoxColor.getSelectedItem());
                getEnvironment().free(i, j);
                getEnvironment().getPacketWorld().placeItem(p);
            });

            changed = true;
        }
    }

    /**
     * Routine for pressing packet button
     */
    public void packetButtonActionPerformed(ActionEvent e) {
        buttonClear();
        btnPacket.setBackground(DEFAULT_COLOR);
        // btnPacket.setBackground(selectedColor);
        this.initColorList(false);
        jComboBoxColor.setEnabled(true);
        selected = Selection.Packet;
    }

    /**
     * Routine for pressing destination button
     */
    public void destButtonActionPerformed(ActionEvent e) {
        buttonClear();
        btnDest.setBackground(DEFAULT_COLOR);
        // btnDest.setBackground(selectedColor);
        this.initColorList(false);
        jComboBoxColor.setEnabled(true);
        selected = Selection.Destination;
    }

    /**
     * Routine for pressing agent button
     */
    public void agentButtonActionPerformed(ActionEvent e) {
        buttonClear();
        btnAgent.setBackground(DEFAULT_COLOR);
        this.initColorList(true);
        jComboBoxColor.setEnabled(true);
        selected = Selection.Agent;
    }

    /**
     * Routine for pressing battery button
     */
    public void batteryButtonActionPerformed(ActionEvent e) {
        buttonClear();
        btnBattery.setBackground(DEFAULT_COLOR);
        selected = Selection.Battery;
    }

    public void wallButtonActionPerformed(ActionEvent e) {
        buttonClear();
        btnWall.setBackground(DEFAULT_COLOR);
        selected = Selection.Wall;
    }

    /**
     * Routine for pressing remove button
     */
    public void removeButtonActionPerformed(ActionEvent e) {
        buttonClear();
        btnRemove.setBackground(DEFAULT_COLOR);
        selected = Selection.Remove;
    }

    /**
     * Resets a buttons
     */
    private void buttonClear() {
        jComboBoxColor.setEnabled(false);
        btnPacket.setBackground(null);
        btnDest.setBackground(null);
        btnAgent.setBackground(null);
        btnRemove.setBackground(null);
        btnBattery.setBackground(null);
        btnWall.setBackground(null);
    }

    /**
     * Routine for adjusting size combo
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void sizeActionPerformed(ActionEvent e) {
        int width = Integer.parseInt( (String) jComboBoxWidth.getSelectedItem());
        int height = Integer.parseInt( (String) jComboBoxHeight.getSelectedItem());
        int newView = Integer.parseInt( (String) jComboBoxView.getSelectedItem());
        setView(newView);
        Environment newenv = new Environment(width, height);

        for (Class<? extends World<?>> worldClass : WORLDS) {
            try {
                World<?> w = worldClass.getDeclaredConstructor(EventBus.class).newInstance((Object) null);
                w.initialize(width, height, newenv);

                newenv.addWorld(w);
            } catch (Exception exc) {
                System.err.println("Error setting worlds" + exc);
            }
        }

        // The environment does not need an ApplicationRunner or EventBus in this case
        // since we are not planning on actually running it, but merely
        // constructing it
        newenv.createEnvironment(null, null);

        if (getEnvironment() != null) {
            for (Class<? extends World<?>> worldClass : WORLDS) {
                World oldWorld = env.getWorld(worldClass);
                World newWorld = newenv.getWorld(worldClass);

                for (int i = 0; i < width; i++) {
                    for (int j = 0; j < height; j++) {
                        if (i < getEnvironment().getWidth() && j < getEnvironment().getHeight()) {
                            if (oldWorld.getItem(i, j) != null) {
                                newWorld.placeItem(oldWorld.getItem(i, j));
                                if (oldWorld.getItem(i, j) instanceof Agent) {
                                    ((Agent) newWorld.getItem(i, j)).setEnvironment(newenv);
                                    ((Agent) newWorld.getItem(i, j)).setView(newView);
                                }
                            }
                        }
                    }
                }
            }
        }
        changed = true;
        setEnvironment(newenv);

        videoPanel.setEnvironment(getEnvironment());
        videoPanel.initiate();
    }


    /**
     * Routine for clicking in the environment area
     */
    public void panelMouseClicked(MouseEvent e) {

        int x = e.getPoint().x;
        int y = e.getPoint().y;
        int fw = Math.min(panel1.getWidth(), panel1.getHeight());
        int s = Math.max(getEnvironment().getWidth(),
                         getEnvironment().getHeight());
        int o = 20;
        int w = fw - 2 * o;
        int cs = w / s;
        int i = (x - o) / cs;
        int j = (y - o) / cs;
        if (i >= getEnvironment().getWidth() || j >= getEnvironment().getHeight()) {
            //Clicked outside grid
            //Could cause NullPointerException
            //No-op
            return;
        }
        if (getEnvironment().getWorld(AgentWorld.class).getItem(i, j) != null) {
            removeAgent(i, j);
        }
        switch (selected) {
            case None:
                return;
            case Packet:
                Packet p = new Packet(i, j, (String) jComboBoxColor.getSelectedItem());
                getEnvironment().free(i, j);
                getEnvironment().getPacketWorld().placeItem(p);
                changed = true;
                break;
            case Destination:
                Destination d = new Destination(i, j, (String) jComboBoxColor.getSelectedItem());
                getEnvironment().free(i, j);
                getEnvironment().getDestinationWorld().placeItem(d);
                changed = true;
                break;
            case Agent:
                String color = (String) jComboBoxColor.getSelectedItem();
                Agent a = new Agent(i, j, getEnvironment(), getView(), 
                                    agents.size() + 1,
                                    "" + (agents.size() + 1), 
                                    color.equals("None") ? null : MyColor.getColor(color));
                agents.add(a);
                getEnvironment().free(i, j);
                getEnvironment().getAgentWorld().placeItem(a);

                // Adjust energy station IDs if any are present
                var energyStations = getEnvironment().getEnergyStationWorld().getItems().stream()
                    .flatMap(List::stream)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());

                for (int index = 0; index < energyStations.size(); ++index) {
                    var energyStation = energyStations.get(index);
                    getEnvironment().free(energyStation.getX(), energyStation.getY());
                    getEnvironment().getEnergyStationWorld().placeItem(
                        new EnergyStation(energyStation.getX(), energyStation.getY(), agents.size() + 1 + index));
                }

                changed = true;
                break;
            case Battery:
                EnergyStation es = new EnergyStation(i, j, agents.size() + 1);
                getEnvironment().free(i, j);
                getEnvironment().getEnergyStationWorld().placeItem(es);
                changed = true;
                break;
            case Wall:
                Wall wa = new Wall(i, j);
                getEnvironment().free(i, j);
                getEnvironment().getWallWorld().placeItem(wa);
                changed = true;
                break;
            case Remove:
                getEnvironment().free(i, j);
                changed = true;
                break;
            default:
                return;
        }
        videoPanel.refresh();
    }

    /**
     * Removes an agent from location (i,j). All agents with ID greater than
     * the removed agent are replaced by an agent with an ID that is 1 lower.
     */
    private void removeAgent(int i, int j) {
        List<Agent> newAgents = new ArrayList<>();

        for (var agent : agents) {
            if (!(agent.getX() == i && agent.getY() == j)) {
                // Not the agent to be removed, add as new agent with adjusted ID
                newAgents.add(new Agent(agent.getX(), agent.getY(), 
                                        getEnvironment(), 
                                        getView(), 
                                        newAgents.size() + 1, 
                                        Integer.toString(newAgents.size() + 1),
                                        agent.getColor().orElse(null)));
            }
        }

        agents = newAgents;
        for (int k = 0; k < agents.size(); k++) {
            getEnvironment().getAgentWorld().placeItem(agents.get(k));
        }
    }

    public void newActionPerformed(ActionEvent e) {
        if (changed) {
            int sel = JOptionPane.showConfirmDialog(this,
                "Environment has been modified. Do you want to save changes?",
                "Save modified file?",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE);
            if (sel == JOptionPane.YES_OPTION) {
                saveDialog();
                newFile();
            } else if (sel == JOptionPane.NO_OPTION) {
                newFile();
            }
            //else: CANCEL_OPTION --> No-op
        }
        newFile();
    }

    public void loadActionPerformed(ActionEvent e) {
        if (changed) {
            int sel = JOptionPane.showConfirmDialog(this,
                "Environment has been modified. Do you want to save changes?",
                "Save modified file?",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE);
            if (sel == JOptionPane.YES_OPTION) {
                saveDialog();
                if (loadDialog()) changed = false;
            } else if (sel == JOptionPane.NO_OPTION) {
                if (loadDialog()) changed = false;
            }
            //else: CANCEL_OPTION --> No-op
        } else {
            if (loadDialog()) changed = false;
        }
    }

    /**
     * Routine for pressing save button
     */
    public void saveActionPerformed(ActionEvent e) {
        if (changed) {
            if (curFile != null) {
                if (writeFile(curFile)) {
                    changed = false;
                } else {
                    this.videoPanel.warning("Could not write to output file.");
                }
            } else {
                if (saveDialog()) {
                    changed = false;
                }
            }
        }
    }

    public void saveAsActionPerformed(ActionEvent e) {
        if (saveDialog()) {
            changed = false;
        }
    }

    public void exitActionPerformed(java.awt.AWTEvent e) {
        if (changed) {
            int sel = JOptionPane.showConfirmDialog(this,
                "Environment has been modified. Do you want to save changes?",
                "Save modified file?",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE);
            if (sel == JOptionPane.YES_OPTION) {
                if (saveDialog()) {
                    System.exit(0);
                }
            } else if (sel == JOptionPane.NO_OPTION) {
                System.exit(0);
            }
            //Else: cancel --> No-op
        } else {
            System.exit(0);
        }
    }

    /**
     * Shows a save file dialog. Returns <code>true</code> if the loading has
     * succeeded, <code>false</code> otherwise.
     */
    public boolean loadDialog() {
        fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new TxtFileFilter());
        fileChooser.setAcceptAllFileFilterUsed(false);
        fileChooser.setCurrentDirectory(new File(Variables.ENVIRONMENTS_PATH));
        int returnVal = fileChooser.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            if (file != null) {
                readFile(file);
                setCurrentFile(file);
                return true;
            }
        }
        return false;
    }

    /**
     * Shows a save file dialog. Returns <code>true</code> if the saving has
     * succeeded, <code>false</code> otherwise.
     */
    public boolean saveDialog() {
        boolean valid = false;
        File file = new File("");
        while (!valid) {
            fileChooser = new JFileChooser();
            fileChooser.setFileFilter(new TxtFileFilter());
            fileChooser.setAcceptAllFileFilterUsed(false);
            fileChooser.setCurrentDirectory(new File(Variables.ENVIRONMENTS_PATH));
            int returnVal = fileChooser.showSaveDialog(this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                file = fileChooser.getSelectedFile();
                if (!file.getAbsolutePath().endsWith(".txt")) {
                    file = new File(file.getAbsolutePath() + ".txt");
                }
                if (file.isFile()) {
                    int sel = JOptionPane.showConfirmDialog(this,
                        "File already exists! Do you want to overwrite it?",
                        "Overwrite file?",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);
                    if (sel == JOptionPane.YES_OPTION) {
                        valid = true;
                    }
                } else {
                    valid = true;
                }
            } else {
                return false;
            }
        }
        if (!writeFile(file)) {
            this.videoPanel.warning("Could not write to output file.");
            return false;
        } else {
            setCurrentFile(file);
            return true;
        }
    }

    private void newFile() {
        setEnvironment(null);
        sizeActionPerformed(null);
        selected = Selection.None;
        agents = new Vector<>();
        changed = false;
    }

    /**
     * @see   @link{guisetup.Setup#createEnvFromFile(String)}
     * @param file
     */
    private void readFile(File file) {
        String configFile = file.getAbsolutePath();

        //Sets the values of the width and height combo boxes
        try {
            AsciiReader reader = new AsciiReader(configFile);
            reader.check("width");
            int worldWidth = reader.readInt();
            reader.check("height");
            int worldHeight = reader.readInt();
            //reader.check("agentview");

            jComboBoxWidth.setSelectedItem(String.valueOf(worldWidth));
            jComboBoxHeight.setSelectedItem(String.valueOf(worldHeight));

            setEnvironment(ApplicationRunner.createEnvFromFile(configFile, null));
            List<Agent> agents = getEnvironment().getAgentWorld().getAgents();
            this.agents = new Vector<>();
            for (Agent agent : agents) {
                this.agents.add(agent);
            }
            try {
                jComboBoxView.setSelectedItem(String.valueOf(getEnvironment().getAgentWorld().getAgent(1).getView()));
            } catch (NullPointerException exc) {
                jComboBoxView.setSelectedIndex(0);
            }
            videoPanel.setEnvironment(getEnvironment());
            videoPanel.initiate();
            changed = false;
        } catch (FileNotFoundException e) {
            System.err.println("Environment config file not found: " +
                    configFile + "\n" + e.getMessage());
        } catch (IOException e) {
            System.err.println("Something went wrong while reading: " +
                    configFile + "\n" + e.getMessage());
        }
    }

    /**
     * Writes configuration file
     */
    private boolean writeFile(File file) {
        String configFile = file.getAbsolutePath();
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(configFile));
            writer.write("width " + getEnvironment().getWidth() + "\n");
            writer.write("height " + getEnvironment().getHeight() + "\n");

            writer.write("\n");
            // var agents = getEnvironment().getAgentWorld().getAgents();
            writer.write("nbAgents " + agents.size() + "\n");
            for (var agent : agents) {
                writer.write(agent.generateEnvironmentString());
            }
            
            var packets = getEnvironment().getPacketWorld().getItems().stream()
                .flatMap(List::stream)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
            writer.write("\nnbPackets " + packets.size() + "\n");
            for (var packet : packets) {
                writer.write(packet.generateEnvironmentString());
            }

            var destinations = getEnvironment().getDestinationWorld().getItems().stream()
                .flatMap(List::stream)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
            writer.write("\nnbDestinations " + destinations.size() + "\n");
            for (var destination : destinations) {
                writer.write(destination.generateEnvironmentString());
            }

            var walls = getEnvironment().getWallWorld().getItems().stream()
                .flatMap(List::stream)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
            writer.write("\nnbWalls " + walls.size() + "\n");
            for (var wall : walls) {
                writer.write(wall.generateEnvironmentString());
            }

            var energyStations = getEnvironment().getEnergyStationWorld().getItems().stream()
                .flatMap(List::stream)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
            writer.write("\nnbEnergyStations " + energyStations.size() + "\n");
            for (var energyStation : energyStations) {
                writer.write(energyStation.generateEnvironmentString());
            }

            writer.close();
            return true;
        } catch (IOException ioe) {
            return false;
        }
    }

    //--------------------------------------------------------------------------
    //		GETTERS & SETTERS
    //--------------------------------------------------------------------------

    private Environment getEnvironment() {
        return env;
    }

    private void setEnvironment(Environment env) {
        this.env = env;
    }

    private int getView() {
        return view;
    }

    private void setView(int view) {
        this.view = view;
    }

    private void setCurrentFile(File file) {
        curFile = file;
        setTitle(WINDOW_TITLE + " - " + file.getName());
    }

    //--------------------------------------------------------------------------
    //		ATTRIBUTES
    //--------------------------------------------------------------------------

    private JPanel panel1 = new JPanel();
    private final JPanel panel2 = new JPanel();
    private final JButton btnPacket = new JButton();
    private final JButton btnDest = new JButton();
    private final JButton btnAgent = new JButton();
    private final JButton btnBattery = new JButton();
    private final JButton btnWall = new JButton();
    private final JButton btnRemove = new JButton();

    private final JLabel lblWidth = new JLabel();
    private final JLabel lblHeight = new JLabel();
    private final JLabel lblView = new JLabel();
    private final JLabel lblColor = new JLabel();
    private final JComboBox<String> jComboBoxWidth = new JComboBox<>();
    private final JComboBox<String> jComboBoxHeight = new JComboBox<>();
    private final JComboBox<String> jComboBoxView = new JComboBox<>();
    private final JComboBox<String> jComboBoxColor = new JComboBox<>();
    private final JMenuBar menuBar = new JMenuBar();
    private JFileChooser fileChooser;
    private final Color DEFAULT_COLOR = java.awt.Color.gray;
    private final String WINDOW_TITLE = "Environment Creator";

    private File curFile = null;
    private boolean changed = false;

    private Environment env;
    private int view;
    private final List<Class<? extends World<?>>> WORLDS = ApplicationRunner.getDefaultWorlds();
    private final VideoPanel videoPanel = new VideoPanel();
    private Selection selected = Selection.Packet;
    private List<Agent> agents = new ArrayList<>();

    private final static int MAXSIZE = 100;
    private final static int MAXVIEW = 100;


    private enum Selection { None, Packet, Destination, Agent, Battery, Wall, Remove };

    // Secondary selection

    private void switchWithSecondary() {
        var temp = selected;
        selected = secondary;
        secondary = temp;
    }
    Selection secondary = Selection.Remove;
}
