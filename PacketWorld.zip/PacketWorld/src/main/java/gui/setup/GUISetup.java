package gui.setup;

import agent.behavior.managingSystem.*;
import environment.*;
import gui.video.*;

import javax.swing.*;

public class GUISetup {
    

    public GUISetup() {
        this.applicationRunner = new ApplicationRunner();
    }


    /**
     * Start the gui for this application
     *
     * @post A VideoFrame containing the grid and it's contents is created and shown.
     */
    public void startGui() {
        var eventBus = this.applicationRunner.getEventBus();

        determineEnergyMode();

        if(energyMode){
            energyStatusFrame = new EnergyStatusFrame(this.applicationRunner.getAgentImplementations());
            energyStatusFrame.initialize();
            energyStatusFrame.setVisible(true);
            eventBus.register(energyStatusFrame);

            energyStatisticFrame = new EnergyStatisticFrame(this.applicationRunner.getEnvironment());
            energyStatisticFrame.initialize();
            energyStatisticFrame.setVisible(true);
            eventBus.register(energyStatisticFrame);
        }else {
            BehaviorWatch bw = new BehaviorWatch(this.applicationRunner.getAgentImplementations());
            bw.initialize();
            bw.setVisible(true);
            eventBus.register(bw);
        }

        if(allowEHM){
            this.ehm = new EventHistoryMonitor(this.applicationRunner);
            ehm.initialize();
            ehm.setVisible(true);
        }

        videoPanel = new VideoPanel();
        videoPanel.setEnvironment(this.applicationRunner.getEnvironment());
        eventBus.register(videoPanel);

        userPanel = new UserPanel(this, videoPanel);

        VideoFrame videoFrame = new VideoFrame(videoPanel, userPanel);
        videoFrame.setVisible(true);
    }

    /**
     * Used for determining if the slot reservations should be shown
     */
    private void determineEnergyMode() {
        energyMode = applicationRunner.getAgentImplementations().getAllAgentBehaviors().stream().allMatch(o->o instanceof EnergyManagementBehavior);
    }


    public void selectSettings() {
        JFrame worldConfigurationFrame = new WorldConfigurationFrame(this);
        worldConfigurationFrame.setVisible(true);
    }


    public void reset() {
        applicationRunner.reset();
        videoPanel.setEnvironment(applicationRunner.getEnvironment());
        
        if (this.ehm != null) {
            this.ehm.reset();
        }
        if (this.userPanel != null) {
            this.userPanel.reset();
        }
        if(this.energyStatusFrame != null){
            energyStatusFrame.reset(applicationRunner.getAgentImplementations());
        }
        if(this.energyStatisticFrame != null){
            energyStatisticFrame.reset(applicationRunner.getAgentImplementations());
        }
    }



    public ApplicationRunner getApplicationRunner() {
        return this.applicationRunner;
    }



    public UserPanel userPanel;
    private VideoPanel videoPanel;
    private EventHistoryMonitor ehm = null;
    private EnergyStatusFrame energyStatusFrame = null;
    private EnergyStatisticFrame energyStatisticFrame = null;

    private Boolean energyMode = null;


    private static final boolean allowEHM = false;
    private ApplicationRunner applicationRunner;
}
