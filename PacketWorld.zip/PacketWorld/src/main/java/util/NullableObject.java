package util;

/**
 * An interface for allowing objects to implement the null object design pattern
 */
public interface NullableObject<T> {

    /**
     * Returns the null-type object of this class
     */
    T getNullableObject();
}
