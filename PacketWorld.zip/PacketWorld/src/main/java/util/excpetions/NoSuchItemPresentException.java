package util.excpetions;

public class NoSuchItemPresentException extends Exception{
}
