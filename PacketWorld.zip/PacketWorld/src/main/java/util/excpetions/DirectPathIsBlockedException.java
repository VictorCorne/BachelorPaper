package util.excpetions;

public class DirectPathIsBlockedException extends Exception{

}
