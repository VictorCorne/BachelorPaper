package util.event;

import agent.*;

public class NoSlotAvailableEvent extends Event{

    /**
     * Constructs a new event, given the object that throws this event.
     *
     * @param throwingObject the object that throws this event
     */
    public NoSlotAvailableEvent(Object throwingObject, AgentImp agent) {
        super(throwingObject);
        requester = agent;
    }

    public final AgentImp requester;
}
