package util.event;

import agent.*;
import agent.behavior.managingSystem.*;
import agent.behavior.schedule.*;

public class SlotCanceledEvent extends Event{

    public SlotCanceledEvent(Object thrower, AgentImp agent, TimeSlot cancelledSlot) {
        super(thrower);
        this.agentImp = agent;
        this.slot = cancelledSlot;
    }

    public final AgentImp agentImp;
    public final TimeSlot slot;
}
