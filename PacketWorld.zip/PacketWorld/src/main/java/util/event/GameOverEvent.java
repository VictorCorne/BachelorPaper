package util.event;

public class GameOverEvent extends Event {
    public GameOverEvent(Object thrower) {
        this(thrower, true);
    }

    public GameOverEvent(Object thrower, boolean everythingFinished) {
        super(thrower);
        this.everythingFinished = everythingFinished;
    }

    public final boolean everythingFinished;
}
