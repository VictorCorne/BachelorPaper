package util.event;

import agent.*;
import agent.behavior.schedule.*;

public class SlotReceivedEvent extends Event{
    /**
     * Constructs a new event, given the object that throws this event.
     *
     * @param throwingObject the object that throws this event
     */
    public SlotReceivedEvent(Object throwingObject, AgentImp agent, TimeSlot slot) {
        super(throwingObject);
        this.agentImp = agent;
        this.slot = slot.clone();
    }

    public final AgentImp agentImp;
    public final TimeSlot slot;
}
