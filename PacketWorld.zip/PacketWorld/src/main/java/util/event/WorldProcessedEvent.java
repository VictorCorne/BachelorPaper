package util.event;

public class WorldProcessedEvent extends Event {
    public WorldProcessedEvent(Object thrower) {
        super(thrower);
    }
}
