package util.event;

import agent.behavior.BehaviorChange;

public class BehaviorChangeEvent extends Event {
    public BehaviorChangeEvent(Object thrower) {
        super(thrower);
    }

    public int getAgent() {
        return agent;
    }

    public void setAgent(int agent) {
        this.agent = agent;
    }

    public String getBehavName() {
        return behavName;
    }

    public void setBehavName(String behavName) {
        this.behavName = behavName;
    }

    public BehaviorChange getChange() {
        return (BehaviorChange) getThrower();
    }

    private int agent;
    private String behavName;

}
