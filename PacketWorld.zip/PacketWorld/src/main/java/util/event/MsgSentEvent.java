package util.event;

import environment.*;

public class MsgSentEvent extends Event {
    public MsgSentEvent(Object thrower) {
        super(thrower);
    }

    public MsgSentEvent(Object thrower, Mail mail){
        this(thrower);
        setMsg(mail);
    }

    public Mail getMsg() {
        return msg;
    }

    public void setMsg(Mail msg) {
        this.msg = msg;
    }

    public boolean isQuestion() {
        return msg.getString().charAt(7) == '?';
    }

    private Mail msg;
}
