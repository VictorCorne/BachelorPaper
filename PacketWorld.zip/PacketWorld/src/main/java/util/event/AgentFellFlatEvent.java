package util.event;

import agent.*;
import agent.behavior.managingSystem.EnergyManagementBehavior.*;

public class AgentFellFlatEvent extends Event{
    public final AgentImp agent;
    public final Integer turnFellFlat;
    public final boolean hadSlot, movingToStation;

    public AgentFellFlatEvent(Object thrower, AgentImp agent, Integer turnFellFlat, boolean hadSlot, boolean movingToStation) {
        super(thrower);
        this.agent = agent;
        this.turnFellFlat = turnFellFlat;
        this.hadSlot = hadSlot;
        this.movingToStation = movingToStation;
    }
}
