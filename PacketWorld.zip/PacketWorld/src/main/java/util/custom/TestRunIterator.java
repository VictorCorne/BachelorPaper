package util.custom;

import util.*;

import java.util.*;

public class TestRunIterator implements Iterator<BatchConfig>{

    public TestRunIterator(List<String> envsString, String impsString, int nbTurnsEach) {
        this.envsString = new ArrayList<>(envsString);
        this.impsString = impsString;
        this.nbRuns = nbTurnsEach;
    }

    private final List<String> envsString;
    private final String impsString;

    private int currentEnvIndex = 0;
    private final int nbRuns;

    @Override
    public boolean hasNext() {
//        if(currentEnvIndex == envsString.size() && currentImpIndex == impsString.size()) return false;
        return true;
    }

    @Override
    public BatchConfig next() {
        currentEnvIndex ++;
        return new BatchConfig(nbRuns, envsString.get(currentEnvIndex), impsString);
    }

    public BatchConfig getFirst(){
        return new BatchConfig(nbRuns, envsString.get(0), impsString);
    }
}
