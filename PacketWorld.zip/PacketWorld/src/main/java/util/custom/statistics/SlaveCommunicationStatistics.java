package util.custom.statistics;

import agent.behavior.*;
import agent.behavior.managingSystem.communicationStrategy.masterSlaveBehavior.*;
import agent.behavior.schedule.*;
import com.google.common.eventbus.*;

import java.util.*;

/**
 * A class whose purpose is to monitor the communication that happens inside agents with slave-behavior
 */
public class SlaveCommunicationStatistics extends CommunicationStatistics{


    public SlaveCommunicationStatistics(EventBus bus, Class<? extends Behavior> targetedBehavior) {
        super(bus, targetedBehavior);
        assert targetedBehavior.equals(SlaveBehavior.class);
    }

    @Override
    protected void initStatisticsMap() {
        statistics = new HashMap<>(){{
            put(SlotRequestMail.class, 0);
            put(SlotReservedMail.class, 0);
        }};
    }

}
