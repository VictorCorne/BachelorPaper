package util.custom.statistics;

import agent.behavior.*;
import agent.behavior.managingSystem.communicationStrategy.informationSharing.*;
import com.google.common.eventbus.*;

import java.util.*;

public class InformationSharingCommunicationStatistics extends CommunicationStatistics{

    public InformationSharingCommunicationStatistics(EventBus bus, Class<? extends Behavior> targetedBehavior) {
        super(bus, targetedBehavior);
        assert targetedBehavior.equals(InformationSharingBehavior.class);
    }

    @Override
    protected void initStatisticsMap() {
        statistics = new HashMap<>(){{
            put(SlotReservedNotification.class, 0);
        }};
    }
}
