package util.custom.statistics;

import agent.behavior.*;
import com.google.common.eventbus.*;

public class NullCommunicationStatistics extends CommunicationStatistics{

    protected NullCommunicationStatistics(EventBus bus, Class<? extends Behavior> targetedBehavior) {
        super(bus, targetedBehavior);
    }

    @Override
    protected void initStatisticsMap() {

    }
}
