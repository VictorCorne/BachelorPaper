package util.custom.statistics;

import agent.behavior.learning.slotRequest.*;
import agent.behavior.schedule.*;
import com.google.common.eventbus.*;
import util.event.*;

import java.util.*;

public class SlotReceivedStatistics {

    private EventBus bus;

    public SlotReceivedStatistics(EventBus bus) {
        bus.register(this);
        this.bus = bus;
    }

    public void reset(){
        if(bus != null) bus.unregister(this);
        receivedSlots.clear();
        bus = null;
        active = false;
    }

    private boolean active = true;

    @Subscribe
    public void handleSlotReceivedEvent(SlotReceivedEvent event){
        if(!active) return;
        receivedSlots.add(event.slot.clone());
        nbAddition ++;
        nbTotal++;
    }

    @Subscribe
    synchronized public void handleSlotCancelledEvent(SlotCanceledEvent event){
        if(!active) return;
        boolean wasPresent = receivedSlots.remove(event.slot);
        nbCancellations ++;
        nbTotal --;
    }

    List<TimeSlot> receivedSlots = new ArrayList<>();
    private int nbCancellations = 0,
    nbAddition = 0,
    nbTotal = 0;

    public double getAverageSlotQuality(){
        if(receivedSlots.isEmpty()) return -1000_000;
        return receivedSlots.stream().filter(d->d != null).
                mapToDouble(d -> SlotQualityPredictor.getQualityOfSlot(d.getAgentRepresentation(), d)).average().orElse(0);
    }

    public int getNbCancellations() {
        return nbCancellations;
    }

    public int getNbAddition() {
        return nbAddition;
    }

    public int getNbTotal() {
        return nbTotal;
    }
}
