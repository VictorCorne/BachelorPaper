package util.custom.statistics;

import agent.behavior.*;
import agent.behavior.managingSystem.communicationStrategy.regionalPlannerBehavior.*;
import agent.behavior.schedule.*;
import com.google.common.eventbus.*;

import java.util.*;

public class RegionalCommunicationStatistics extends CommunicationStatistics{

    public RegionalCommunicationStatistics(EventBus bus, Class<? extends Behavior> targetedBehavior) {
        super(bus, targetedBehavior);
        assert targetedBehavior.equals(RegionalBehavior.class);
    }

    @Override
    protected void initStatisticsMap() {
        statistics = new HashMap<>(){{
            put(SlotRequestMail.class, 0);
            put(SlotReservedMail.class, 0);
            put(SchedulerSlotAck.class, 0);
            put(SchedulerSlotAnswerMail.class, 0);
            put(SchedulerSlotRequestMail.class, 0);
        }};
    }
}
