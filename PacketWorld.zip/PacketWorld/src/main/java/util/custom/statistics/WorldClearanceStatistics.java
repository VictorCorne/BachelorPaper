package util.custom.statistics;

import environment.*;
import util.*;

import java.util.*;

/**
 * A utility class that is used to determine the clearance rate of an environment
 */
public class WorldClearanceStatistics {

    /**
     * The collection that holds count of the statistics of this world.
     *
     * The first item represents the turn-nb, the second represents the number of packets remaining in the environment
     */
    private List<Pair<Integer, Integer>> clearanceStatistics;

    /**
     * The number of packets the environment started with
     */
    private int startPackets;

    Environment environment;

    public WorldClearanceStatistics(Environment environment){
        this(environment.getPacketWorld().getNbPackets());
        this.environment = environment;
    }

    public WorldClearanceStatistics(int nbStartPackets){
        initialise(nbStartPackets);
    }

    public void reset(Environment environment){
        clearanceStatistics.clear();
    }

    private void initialise(int nbPackets){
        clearanceStatistics = new ArrayList<>();
        startPackets = nbPackets;
    }

    public void update(){
        update(environment);
    }

    public void update(Environment environment){
        int currentPackets = environment.getPacketWorld().getNbPackets();
        int currentTurn = environment.getNbTurns();
        update(currentTurn, currentPackets);
    }

    public void update(int turnNb, int currentPacketNb){
        int latestUpdate = getLatestUpdateTime();
        int latestUpdatePackets = getLatestUpdateNbPackets();
        if(currentPacketNb > latestUpdatePackets || turnNb <= latestUpdate || currentPacketNb < 0) throw new IllegalArgumentException();


        clearanceStatistics.add(new Pair<>(turnNb, currentPacketNb));
    }

    // GETTING INFORMATION

    public int getTurnAtNbPacketsRemaining(int nbPackets){
        assert nbPackets >= 0;

        return clearanceStatistics.stream().filter(o->o.second <= nbPackets).findFirst().orElse(new Pair<>(0,0)).first;
    }

    public int getTurnAtCompletionPercent(double completionPercent){
        assert completionPercent >= 0 && completionPercent <= 1;

        int packetsRemaining = (int) Math.round((1-completionPercent) * (double) startPackets);
        return getTurnAtNbPacketsRemaining(packetsRemaining);
    }

    // CHECKS

    private Pair<Integer, Integer> getLatestUpdate() {
        return clearanceStatistics.stream().max(Comparator.comparingInt(o->o.first)).orElse(null);
    }

    private int getLatestUpdateTime(){
        return getLatestUpdate() == null ? -1 : getLatestUpdate().first;
    }

    private int getLatestUpdateNbPackets(){
        return getLatestUpdate() == null ? startPackets : getLatestUpdate().second;
    }
}
