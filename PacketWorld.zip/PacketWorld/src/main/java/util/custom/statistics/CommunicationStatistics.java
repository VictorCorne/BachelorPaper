package util.custom.statistics;

import agent.behavior.*;
import agent.behavior.managingSystem.communicationStrategy.informationSharing.*;
import agent.behavior.managingSystem.communicationStrategy.masterSlaveBehavior.*;
import agent.behavior.managingSystem.communicationStrategy.regionalPlannerBehavior.*;
import com.google.common.eventbus.*;
import environment.*;
import util.event.*;

import java.util.*;

public abstract class CommunicationStatistics {

    private EventBus eventBus;

    protected CommunicationStatistics(EventBus bus, Class<? extends Behavior> targetedBehavior){
        bus.register(this);
        this.eventBus = bus;
        initStatisticsMap();
    }

    public static CommunicationStatistics getInstance(EventBus bus, Class<? extends Behavior> target) {
        if (target.equals(SlaveBehavior.class)) return new SlaveCommunicationStatistics(bus, target);
        if (target.equals(RegionalBehavior.class)) return new RegionalCommunicationStatistics(bus, target);
        if (target.equals(InformationSharingBehavior.class)) return new InformationSharingCommunicationStatistics(bus, target);
        return new NullCommunicationStatistics(bus, target);
    }

    // INTERACTION

    protected void addReceivedMail(Mail msg) {
        var statistics = getStatistics();
        assert statistics.containsKey(msg.getClass());
        var nbEntries = statistics.get(msg.getClass());
        statistics.put(msg.getClass(), nbEntries+1);
    }

    @Subscribe
    public void handleMsgSentEvent(MsgSentEvent event) {
        addReceivedMail(event.getMsg());
    }

    public void reset(){
        try {
            statistics.clear();
            statistics = new HashMap<>();
            initStatisticsMap();
            if(eventBus != null) eventBus.unregister(this);
            eventBus = null;
        }catch (Exception ignored){}
    }

    protected final Map<Class<? extends Mail>, Integer> getStatistics(){
        return statistics;
    }

    protected Map<Class<? extends Mail>, Integer> statistics = new HashMap<>();

    protected abstract void initStatisticsMap();

    // EXPORT DATA

    public static String getName(){
        return "Communication statistics";
    }

    public String getTitles(){
        StringBuilder res = new StringBuilder();
        var stats = getStatistics();
        stats.forEach((cls, i) -> res.append(cls.getSimpleName() + "\t"));
        return res.toString();
    }

    public String getDataString(){
        StringBuilder res = new StringBuilder();
        var stats = getStatistics();
        stats.forEach((cls, i) -> res.append(i + "\t"));
        return res.toString();
    }
}
