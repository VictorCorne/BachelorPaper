package util.custom.statistics;

import agent.*;
import agent.behavior.*;
import agent.behavior.managingSystem.*;

import java.util.*;

/**
 * A module designed to track the time spent by each agent in its meta behavior
 */
public class AgentBehaviorStatistics {

    // GETTING INFORMATION

    public int getNbTurnsSpentInMetaModeForAgent(int agentID){
        return statisticMap.get(agentID).turnsMetaMode;
    }

    public double getPercentTurnsSpentInMetaModeForAgent(int agentID){
        return (double) getNbTurnsSpentInMetaModeForAgent(agentID) / (double) statisticMap.get(agentID).getTotalTurns();
    }

    public int getTotalNbTurnsSpentInMetaMode(){
        return statisticMap.values().stream().mapToInt(o->o.turnsMetaMode).sum();
    }

    private int getTotalEffectiveTurns() {
        return statisticMap.values().stream().mapToInt(o->o.getTotalTurns()).sum();
    }

    public double getPercentageSpentInMetaMode(){
        int meta = getTotalNbTurnsSpentInMetaMode();
        int total = getTotalEffectiveTurns();
        return ((double) meta) / ((double) total);
    }

    // INTERACTION

    public void update(AgentImplementations ais){
        statisticMap.forEach((integer, statistic) -> {
            AgentImp imp = ais.getAgentImp(integer);
            Behavior behavior = imp.getCurrentBehavior();
            if (behavior instanceof EnergyManagementBehavior && imp.hasEnergyLeft())
                statistic.update(((EnergyManagementBehavior) behavior).isMovingToStation(imp));
        });
    }

    public void reset(AgentImplementations ais){
        statisticMap.clear();
        init(ais);
    }

    // CONSTRUCTOR

    public AgentBehaviorStatistics(AgentImplementations agentImplementations) {
        init(agentImplementations);
    }

    private void init(AgentImplementations ais){
        statisticMap = new HashMap<>();
        Arrays.stream(ais.getAllAgentID()).forEach(o->statisticMap.put(o, new Statistic()));
    }

    // STATISTICS

    private Map<Integer, Statistic> statisticMap;

    private static class Statistic {
        int turnsMetaMode, turnsNormalMode;

        protected void update(boolean isMetaMode){
            if(isMetaMode) turnsMetaMode ++;
            else turnsNormalMode ++;
        }

        protected int getTotalTurns(){
            return turnsMetaMode + turnsNormalMode;
        }
    }
}
