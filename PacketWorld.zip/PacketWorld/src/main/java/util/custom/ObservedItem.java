package util.custom;

public abstract class ObservedItem {

    private final String description,
        title;

    public ObservedItem(String description, String title) {
        this.description = description;
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public abstract String getData();

    public String getTitle() {
        return title;
    }
}
