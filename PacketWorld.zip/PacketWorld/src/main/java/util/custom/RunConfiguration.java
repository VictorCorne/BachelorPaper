package util.custom;

import agent.behavior.learning.movement.*;
import agent.behavior.learning.slotRequest.*;
import agent.behavior.managingSystem.*;

public class RunConfiguration {

    public RunConfiguration(boolean removeDeadAgents,
                            boolean shouldBaseBehaviorDropAllTasksOnSchedule,
                            double probability0AskSlot,
                            double probability1AskSlot,
                            int halvingProbabilityInterval,
                            double probabilityConvergence,
                            double movementFactor,
                            double movementSafetyMargin,
                            double energyAverageConsumption,
                            double energySafetyMargin,
                            SlotQualityPredictorStrategy slotQualityStrategy) {

        this.removeDeadAgents = removeDeadAgents;
        this.shouldBaseBehaviorDropAllTasksOnSchedule = shouldBaseBehaviorDropAllTasksOnSchedule;
        this.probability0AskSlot = probability0AskSlot;
        this.probability1AskSlot = probability1AskSlot;
        this.halvingProbabilityInterval = halvingProbabilityInterval;
        this.probabilityConvergence = probabilityConvergence;
        this.movementFactor = movementFactor;
        this.movementSafetyMargin = movementSafetyMargin;
        this.energyAverageConsumption = energyAverageConsumption;
        this.energySafetyMargin = energySafetyMargin;
        this.slotQualityStrategy = slotQualityStrategy;

        testFixProbAsk();
    }

    private void testFixProbAsk() {
        if(probability0AskSlot > probability1AskSlot){
            var temp = probability0AskSlot;
            probability0AskSlot = probability1AskSlot;
            probability1AskSlot = temp;
        }
    }

    // ENVIRONMENT
    private boolean removeDeadAgents;

    // BEHAVIOR
    private boolean shouldBaseBehaviorDropAllTasksOnSchedule;

    // SLOT REQUEST
    private double probability0AskSlot, probability1AskSlot;
    private int halvingProbabilityInterval;
    private double probabilityConvergence;

    // PREDICTING MOVEMENT
    private double movementFactor, movementSafetyMargin;
    private double energyAverageConsumption, energySafetyMargin;

    // SLOT QUALITY
    private SlotQualityPredictorStrategy slotQualityStrategy;

    public void apply(){
        EnergyManagementBehavior.environmentShouldRemoveDeadAgents = removeDeadAgents;

        SlotRequesterPredictor.prob0Ask = probability0AskSlot;
        SlotRequesterPredictor.prob1Ask = probability1AskSlot;
        SlotRequesterPredictor.convergenceValue = probabilityConvergence;
        SlotRequesterPredictor.halvingInterval = halvingProbabilityInterval;

        MovementPredictor.movementFactor = movementFactor;
        MovementPredictor.movementSafetyMargin = movementSafetyMargin;

        EnergyPredictor.averageConsumptionPerTurn = energyAverageConsumption;
        EnergyPredictor.safetyMargin = energySafetyMargin;
    }
}
