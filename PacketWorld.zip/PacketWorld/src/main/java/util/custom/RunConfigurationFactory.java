package util.custom;

import agent.behavior.learning.slotRequest.*;
import environment.*;

import java.util.*;

public class RunConfigurationFactory {

    public RunConfigurationFactory(boolean removeDeadAgents,
                                   boolean shouldBaseBehaviorDropAllTasksOnSchedule,
                                   double minProbability0AskSlot,
                                   double maxProbability0AskSlot,
                                   double minProbability1AskSlot,
                                   double maxProbability1AskSlot,
                                   int minHalvingProbabilityInterval,
                                   int maxHalvingProbabilityInterval,
                                   double minProbabilityConvergence,
                                   double maxProbabilityConvergence,
                                   double minMovementFactor,
                                   double maxMovementFactor,
                                   double minMovementSafetyMargin,
                                   double maxMovementSafetyMargin,
                                   double minEnergyAverageConsumption,
                                   double maxEnergyAverageConsumption,
                                   double minEnergySafetyMargin,
                                   double maxEnergySafetyMargin,
                                   SlotQualityPredictorStrategy slotQualityStrategy) {
        this.removeDeadAgents = removeDeadAgents;
        this.shouldBaseBehaviorDropAllTasksOnSchedule = shouldBaseBehaviorDropAllTasksOnSchedule;
        this.minProbability0AskSlot = minProbability0AskSlot;
        this.maxProbability0AskSlot = maxProbability0AskSlot;
        this.minProbability1AskSlot = minProbability1AskSlot;
        this.maxProbability1AskSlot = maxProbability1AskSlot;
        this.minHalvingProbabilityInterval = minHalvingProbabilityInterval;
        this.maxHalvingProbabilityInterval = maxHalvingProbabilityInterval;
        this.minProbabilityConvergence = minProbabilityConvergence;
        this.maxProbabilityConvergence = maxProbabilityConvergence;
        this.minMovementFactor = minMovementFactor;
        this.minMovementSafetyMargin = minMovementSafetyMargin;
        this.maxMovementFactor = maxMovementFactor;
        this.maxMovementSafetyMargin = maxMovementSafetyMargin;
        this.minEnergyAverageConsumption = minEnergyAverageConsumption;
        this.minEnergySafetyMargin = minEnergySafetyMargin;
        this.maxEnergyAverageConsumption = maxEnergyAverageConsumption;
        this.maxEnergySafetyMargin = maxEnergySafetyMargin;
        this.slotQualityStrategy = slotQualityStrategy;
    }

    public RunConfiguration getNextRunConfiguration(){
        return new RunConfiguration(
        removeDeadAgents,
        shouldBaseBehaviorDropAllTasksOnSchedule,
        getProbability(minProbability0AskSlot, maxProbability0AskSlot),
        getProbability(minProbability1AskSlot, maxProbability1AskSlot),
        getProbability(minHalvingProbabilityInterval, maxHalvingProbabilityInterval),
        getProbability(minProbabilityConvergence, maxProbabilityConvergence),
        getProbability(minMovementFactor, maxMovementFactor),
        getProbability(minMovementSafetyMargin, maxEnergySafetyMargin),
        getProbability(minEnergyAverageConsumption, maxEnergyAverageConsumption),
        getProbability(minEnergySafetyMargin, maxEnergySafetyMargin),
        slotQualityStrategy);
    }

    public static RunConfigurationFactory getDefaultRunConfigurationFactory() {
        return new RunConfigurationFactory(
                true,
                true,
                0.4,
                0.9,
                0.5,
                1,
                0,
                2000,
                0,
                1,
                0.5,
                2,
                0.5,
                2,
                EnergyValues.BATTERY_DECAY_STEP,
                EnergyValues.BATTERY_DECAY_STEP_WITH_CARRY,
                0.5,
                2,
                new SlotQualityStrategies.LatestSwitchStrategy());
    }

    private double getProbability(double minProb, double maxProb){
        assert maxProb >= minProb;
        double rng = new Random().nextDouble();
        double space = maxProb - minProb;
        return minProb + rng * space;
    }

    private int getProbability(int minVal, int maxVal){
        assert maxVal >= minVal;
        double rng = new Random().nextDouble();
        int space = maxVal - minVal;
        return (int) (minVal + rng * space);
    }

    // ENVIRONMENT
    private boolean removeDeadAgents;

    // BEHAVIOR
    private boolean shouldBaseBehaviorDropAllTasksOnSchedule;

    // SLOT REQUEST
    private double minProbability0AskSlot, maxProbability0AskSlot, minProbability1AskSlot, maxProbability1AskSlot;
    private int minHalvingProbabilityInterval, maxHalvingProbabilityInterval;
    private double minProbabilityConvergence, maxProbabilityConvergence;

    // PREDICTING MOVEMENT
    private double minMovementFactor, minMovementSafetyMargin;
    private double maxMovementFactor, maxMovementSafetyMargin;
    private double minEnergyAverageConsumption, minEnergySafetyMargin;
    private double maxEnergyAverageConsumption, maxEnergySafetyMargin;

    // SLOT QUALITY
    private SlotQualityPredictorStrategy slotQualityStrategy;
}
