package util.custom;

import gui.video.*;

import java.text.*;
import java.util.*;


/**
 * A class whose purpose is to format the observed data to be correctly printed
 */
public class DataFormatter {

    /**
     * True if the data must be printed in a human-readable fashion
     * False if the values of the data is just printed "as-is"
     */
    private final boolean printDataRaw;

    private List<ObservedItem> observedItems;

    public DataFormatter(boolean printDataRaw, List<ObservedItem> observedItems) {
        this.printDataRaw = printDataRaw;
        this.observedItems = observedItems;
    }

    public List<String> getEndRunMessages(BatchMAS batchMAS) {
        List<String> res = new ArrayList<>();
        if(!printDataRaw){
            for (ObservedItem ob  : observedItems) res.add(ob.getDescription() + ": " + ob.getData());
            res.add(String.format("*** Ending run number %d ***\n", batchMAS.indexCurrentRun));
        }else{
            for (ObservedItem ob  : observedItems) res.add(ob.getData() + "\t");
            res.add("\n");
        }
        return res;
    }


    public List<String> getStartRunMessages(BatchMAS batchMAS, int runNb) {
        List<String> res = new ArrayList<>();
        if(!printDataRaw){
            res.add("*** Starting run number " + runNb + " ***\n");
        }
        return res;
    }

    public List<String> getStartSimulationMessage(String env, String impl) {
        List<String> res = new ArrayList<>();
        if(!printDataRaw){
            res.add("****** Starting batch run ******\n");
            res.add("Environment:\t " + env);
            res.add("Implementation:\t " + impl);
            Date now = new Date();
            DateFormat df = DateFormat.getTimeInstance(SimpleDateFormat.MEDIUM, Locale.FRENCH);
            String time = df.format(now);
            res.add("Current time:\t " + time + "\n");
        }
        else {
            for (ObservedItem item : observedItems){
                res.add("# " + item.getTitle() + " : " + item.getDescription() + "\n");
            }

            for (ObservedItem observed  : observedItems) {
                res.add(observed.getTitle() + "\t");
            }
            res.get(res.size()-1).replace("\t","");
        }
        res.add("\n");
        return res;
    }

    public List<String> getAbortedMessages() {
        List<String> res = new ArrayList<>();
        if(!printDataRaw){
            res.add("****** ABORTED ******");
        }
        return res;
    }

    public List<String> getEndSimulationMessages() {
        List<String> res = new ArrayList<>();
        if(!printDataRaw) {
            Date now = new Date();
            DateFormat df = DateFormat.getTimeInstance(SimpleDateFormat.MEDIUM, Locale.FRENCH);
            String time = df.format(now);
            res.add("****** Ending batch run ******\n");
            res.add("End time:    \t " + time + "\n");
            res.add("******************************\n");
        }
        return res;
    }
}
