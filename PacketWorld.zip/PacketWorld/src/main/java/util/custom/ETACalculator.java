package util.custom;

import gui.video.*;

import java.util.*;

public class ETACalculator {

    public ETACalculator(BatchMAS batch) {
        this.batch = batch;
    }

    public String getETA() {
        int secondsToSpend = getSecondsETA(),
                minutesToSpend = secondsToSpend /60,
                hoursToSpend = minutesToSpend / 60;

        return String.format("%d:%d:%d",
                hoursToSpend,
                minutesToSpend % 60,
                secondsToSpend % 60);
    }

    public int getSecondsETA(){
        long estimatedTimePerSimulation = getEstimatedTimePerSimulation();
        int simulationsTodo = Integer.parseInt(batch.textFieldNrRuns.getText()) - batch.indexCurrentRun;
        long millisToSpend = estimatedTimePerSimulation * simulationsTodo;
        return (int) (millisToSpend / 1000);
    }

    private long getEstimatedTimePerSimulation(){
        try {
            return (timeStarts.get(timeStarts.size()-1) - timeStarts.get(0)) / timeStarts.size();
        }catch (NullPointerException | IndexOutOfBoundsException | ArithmeticException e){
            return 1;
        }
    }

    public void addTimeNeededEntry(){
        //if(timeStarts.size() >= ROLLING_AVERAGE_SIZE) timeStarts.remove(0);
        timeStarts.add(new Date().getTime());
    }

    /**
     * Returns the time needed to finish the last simulation in millis
     */
    public long getTimeForLastSimulation(){
        int nbSimulations = timeStarts.size();
        if(nbSimulations <= 1) return new Date().getTime() - startTime;

        return timeStarts.get(nbSimulations - 1) - timeStarts.get(nbSimulations - 2);
    }

    public void setStartTime(long startTime){
        this.startTime = startTime;
    }

    public void onAbortActionPerformed() {
        reset();
    }

    private void reset() {
        timeStarts.clear();
    }

    // ATTRIBUTES
    List<Long> timeStarts = new ArrayList<>();
    static final int ROLLING_AVERAGE_SIZE = 4;
    long startTime;
    BatchMAS batch;
}
