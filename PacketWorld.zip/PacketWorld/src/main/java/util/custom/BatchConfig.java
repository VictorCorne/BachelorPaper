package util.custom;

public class BatchConfig {
    int nbRun;
    String envString;

    public int getNbRun() {
        return nbRun;
    }

    public String getEnvString() {
        return envString;
    }

    public String getImpString() {
        return impString;
    }

    String impString;

    public BatchConfig(int nbRun, String envString, String impString) {
        this.nbRun = nbRun;
        this.envString = envString;
        this.impString = impString;
    }
}
