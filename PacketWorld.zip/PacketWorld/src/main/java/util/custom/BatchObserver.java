package util.custom;

import agent.*;
import agent.behavior.*;
import agent.behavior.learning.movement.*;
import agent.behavior.learning.slotRequest.*;
import com.google.common.eventbus.*;
import environment.*;
import environment.world.energystation.*;
import gui.video.*;
import util.custom.statistics.*;
import util.event.*;

import java.util.*;

public class BatchObserver {

    private static final boolean CHANGE_RUN_PARAMETERS = true;

    public BatchObserver(boolean printDataRaw, BatchMAS batchMAS) {
        this.batchMAS = batchMAS;
        etaCalculator = new ETACalculator(batchMAS);
        dataFormatter = new DataFormatter(printDataRaw, observedItems);
        customEventTracker = new CustomEventTracker();
    }



    // ACTIONS PERFORMED

    public void onEndSimulation() {
        for (String str : dataFormatter.getEndSimulationMessages()) textOut(str);
        deleteme();
    }

    public void onRunEnded(GameOverEvent e) {
        dataFormatter.getEndRunMessages(batchMAS).forEach(str -> textOut(str));

        etaCalculator.addTimeNeededEntry();
        if(CHANGE_RUN_PARAMETERS) changeRunParameters();
        customEventTracker.reset();
        communicationStatistics.reset();
        slotReceivedStatistics.reset();
        energyStationStatistics.reset();
    }

    public void onPressedStartButton(String env, String impl) {
        for (String str : dataFormatter.getStartSimulationMessage(env, impl)) textOut(str);
        etaCalculator.setStartTime(new Date().getTime());
    }

    public void onAbortActionPerformed() {
        for (String str : dataFormatter.getAbortedMessages()) textOut(str);
        deleteme();
    }


    public void onStartRun(int runNb, Environment environment, EventBus eventBus) {
        currentBus = eventBus;
        currentAis = environment.getAgentImplementations();
        currentEnv = environment;
        currentBehavior = currentAis.getAllAgentBehaviors().get(0);
        customEventTracker.observeAgents(currentAis.getAllAgents());
        agentBehaviorStatistics = new AgentBehaviorStatistics(currentAis);
        Behavior behavior = currentAis.getAllAgentBehaviors().get(0);
        communicationStatistics = CommunicationStatistics.getInstance(eventBus, behavior.getClass());
        worldClearanceStatistics = new WorldClearanceStatistics(environment);
        energyStationStatistics = new EnergyStationStatistics(environment);
        slotReceivedStatistics = new SlotReceivedStatistics(eventBus);
        for (String a  : dataFormatter.getStartRunMessages(batchMAS, runNb)) textOut(a);

        setTimeOutTimer();
    }

    private void setTimeOutTimer() {
        if(timer != null) timer.stop();
        timer = new javax.swing.Timer(timerDelay, e -> resetRun());
        timer.start();
    }

    private javax.swing.Timer timer;

    /**
     * If the simulation has not finished within this delay, the simulation will reset.
     * This field represents the number of milliseconds of the timer.
     */
    private int timerDelay = 20_000;

    private void stopTimer(){
        if(timer != null) timer.stop();
    }

    private void resetRun(){
        batchMAS.restartRun();
    }

    /**
     * If there are no more living agents in the current environment, it resets the simulation.
     */
    private void doEnvStoppedCheck(){
        if(currentEnv.getAgentImplementations().getNbLivingAgents() == 0) resetRun();
    }

    public void onWorldProcessedEvent(WorldProcessedEvent e){
        worldClearanceStatistics.update();
        agentBehaviorStatistics.update(currentAis);
        energyStationStatistics.update(currentAis, currentEnv.getNbTurns());
        doEnvStoppedCheck();
    }


    // ETA

    private final ETACalculator etaCalculator;

    public ETACalculator getETACalculator() {
        return etaCalculator;
    }

    // PRINTING TEXT

    private void textOut(String str) {
        //batchMAS.textOut(str);
    }

    public String getResultString(){
        return String.join("", dataFormatter.getEndRunMessages(batchMAS));
    }

    public String getStartString() {
        return String.join("", dataFormatter.getStartSimulationMessage(currentEnv.toString(), currentAis.toString()));
    }

    // CHANGING RUN PARAMETERS

    private void changeRunParameters(){
//        changeCommunicationThresholds();
        //runConfigurationFactory.getNextRunConfiguration().apply();
    }

    private void changeCommunicationThresholds(){
        double max = new Random().nextDouble();
        double min = new Random().nextDouble();

        if(min > max) {
            double temp = min;
            min = max;
            max = temp;
        }

        SlotRequesterPredictor.prob0Ask = max;
        SlotRequesterPredictor.prob1Ask = max;

        SlotRequesterPredictor.convergenceValue = min;
    }


    // ATTRIBUTES

    /**
     * A pointer to the batch that this observer is observing
     */
    private final BatchMAS batchMAS;
    /**
     * A reference to the entity that is responsible for formatting the data to be outputted to the batchMAS
     */
    private final DataFormatter dataFormatter;
    /**
     * A reference to the custom event tracker
     */
    private final CustomEventTracker customEventTracker;
    private AgentBehaviorStatistics agentBehaviorStatistics;
    private CommunicationStatistics communicationStatistics;
    private WorldClearanceStatistics worldClearanceStatistics;
    private EnergyStationStatistics energyStationStatistics;
    private SlotReceivedStatistics slotReceivedStatistics;
    private final RunConfigurationFactory runConfigurationFactory = RunConfigurationFactory.getDefaultRunConfigurationFactory();
    private Behavior currentBehavior;
    private EventBus currentBus;
    private AgentImplementations currentAis;
    private Environment currentEnv;

    private void deleteme() {
        etaCalculator.onAbortActionPerformed();
        stopTimer();
        timer = null;
        customEventTracker.reset();
        communicationStatistics.reset();
        communicationStatistics = null;

        slotReceivedStatistics.reset();
    }



    // OBSERVED ITEM

    // GENERAL DATA
    public ObservedItem energySpent = new ObservedItem("Energy spent this run", "Energy") {
        @Override
        public String getData() {
            return batchMAS.getEventTracker().getEnergySpent() + "";
        }};
    public ObservedItem nbCycles = new ObservedItem("Number of cycles needed to finish the run", "Cycles") {
        @Override
        public String getData() {
            return batchMAS.getNrCycles() + "";
        }
    };
    public ObservedItem timeManaged = new ObservedItem("Time that agents spent being managed", "timeManaged") {
        @Override
        public String getData() {
            return agentBehaviorStatistics.getPercentageSpentInMetaMode() + "";
        }
    };
    public ObservedItem communication = new ObservedItem(CommunicationStatistics.getName(), "") {
        @Override
        public String getData() {
            return communicationStatistics.getDataString();
        }

        @Override
        public String getTitle() {
            return CommunicationStatistics.getInstance(currentBus, currentBehavior.getClass()).getTitles();
        }
    };
    public ObservedItem cleared = new ObservedItem("Boolean indicating that the environment was cleared", "Cleared") {
        @Override
        public String getData() {
            return currentEnv.isCleared() + "";
        }
    };
    public ObservedItem reservation = new ObservedItem("Percentage of the time chargers were reserved by agents", "Reservation") {
        @Override
        public String getData() {
            return energyStationStatistics.getAverageReservationRate() + "";
        }
    };
    public ObservedItem slotQuality = new ObservedItem("The average received slot quality", "SlotQuality") {
        @Override
        public String getData() {
            return slotReceivedStatistics.getAverageSlotQuality() + "";
        }
    };

    // CLEARING THE ENVIRONMENT
    public ObservedItem time50clear = new ObservedItem("The time needed to clear 50% of the environment", "Clear50") {
        @Override
        public String getData() {
            return worldClearanceStatistics.getTurnAtCompletionPercent(0.5d) + "";
        }
    };
    public ObservedItem time80clear = new ObservedItem("The time needed to clear 80% of the environment", "Clear80") {
        @Override
        public String getData() {
            return worldClearanceStatistics.getTurnAtCompletionPercent(0.8d) + "";
        }
    };
    public ObservedItem time100clear = new ObservedItem("The time needed to clear 100% of the environment", "Clear100") {
        @Override
        public String getData() {
            return worldClearanceStatistics.getTurnAtCompletionPercent(1d) + "";
        }
    };

    // SLOTS
    public ObservedItem nbCancels = new ObservedItem("The number of slots that got cancelled", "cancelledSlots") {
        @Override
        public String getData() {
            return slotReceivedStatistics.getNbCancellations() + "";
        }
    };

    // ASKING FOR SLOTS
    public ObservedItem minBoundAsk = new ObservedItem("The minimal threshold value at which agents will ask for a slot","minBoundAsk") {
        @Override
        public String getData() {
            return SlotRequesterPredictor.prob1Ask + "";
        }
    };
    public ObservedItem maxBoundAsk = new ObservedItem("The maximal threshold value at which agents will ask for a slot","maxBoundAsk") {
        @Override
        public String getData() {
            return SlotRequesterPredictor.prob0Ask + "";
        }
    };
    public ObservedItem convergenceAsk = new ObservedItem("The convergence value at which agents will ask for a slot","convergenceBoundAsk") {
        @Override
        public String getData() {
            return SlotRequesterPredictor.convergenceValue + "";
        }
    };
    public ObservedItem decayAsk = new ObservedItem("The halving interval for the value at which agents will ask for a slot","decayAsk") {
        @Override
        public String getData() {
            return SlotRequesterPredictor.halvingInterval + "";
        }
    };

    // PREDICTORS
    public ObservedItem movFactor = new ObservedItem("The multiplier factor taken into account when calculating when agents move from point A to point B", "MovementFactor") {
        @Override
        public String getData() {
            return MovementPredictor.movementFactor + "";
        }
    };
    public ObservedItem movSafety = new ObservedItem("The safety factor taken into account when calculating when agents move from point A to point B", "MovementSafety") {
        @Override
        public String getData() {
            return MovementPredictor.movementSafetyMargin + "";
        }
    };
    public ObservedItem energyFactor = new ObservedItem("The multiplier factor taken into account for calculating the average consumption of agents", "EnergyFactor") {
        @Override
        public String getData() {
            return EnergyPredictor.averageConsumptionPerTurn + "";
        }
    };
    public ObservedItem energySafety = new ObservedItem("The safety factor taken into account for calculating the average consumption of agents", "EnergySafety") {
        @Override
        public String getData() {
            return EnergyPredictor.safetyMargin + "";
        }
    };

    // AGENTS FALLING FLAT
    public ObservedItem fallenAgents = new ObservedItem("Number of agents who fell flat without having an energy slot", "Fail") {
        @Override
        public String getData() {
            return currentAis.getNbDeadAgents() + "";
        }
    };
    public ObservedItem fallenWithoutSlot = new ObservedItem("Number of agents who fell flat without having a charger slot","FailNoSlot") {
        @Override
        public String getData() {
            return currentAis.getDeadAgentsWithoutSlot() + "";
        }
    };
    public ObservedItem fallenWithSlot = new ObservedItem("Number of agents who fell flat whilst having a slot", "FailAndSlot") {
        @Override
        public String getData() {
            return currentAis.getDeadAgentsWithSlot() + "";
        }
    };
    public ObservedItem fallenOnTheWayToStation = new ObservedItem("Number of agents who fell flat whilst moving to the station", "FailOnWay") {
        @Override
        public String getData() {
            return customEventTracker.getNbAgentsFellFlatOnTheWayToCharger() + "";
        }
    };
    public ObservedItem fallenNotOnTheWayToStation = new ObservedItem("Number of agents who fell flat whilst not moving to the station", "FailNotOnWay") {
        @Override
        public String getData() {
            return customEventTracker.getNbAgentsFellFlatNotOnTheWayToCharger() + "";
        }
    };

    // DEBUG
    public ObservedItem timeSpentInTheRun = new ObservedItem("Time needed to finish this run", "Time") {
        @Override
        public String getData() {
            return etaCalculator.getTimeForLastSimulation() + "";
        }
    };
    public ObservedItem totalMemory = new ObservedItem("Total memory used by the app", "TotalMemory") {
        @Override
        public String getData() {
            return Runtime.getRuntime().totalMemory() + "";
        }
    };

    // MONITORING CONFIGURATION
    List<ObservedItem> simple = new ArrayList<>(){{
        add(energySpent);
        add(nbCycles);
    }};

    List<ObservedItem> fellFlat = new ArrayList<>(){{
        add(energySpent);
        add(nbCycles);
        add(timeSpentInTheRun);
        add(fallenAgents);
        add(fallenWithoutSlot);
        add(fallenWithSlot);
        add(fallenOnTheWayToStation);
        add(fallenNotOnTheWayToStation);
    }};

    List<ObservedItem> debug = new ArrayList<>(){{
        add(timeSpentInTheRun);
        add(totalMemory);
    }};

    List<ObservedItem> evaluation = new ArrayList<>(){{
        add(cleared);
        add(energySpent);
        add(communication);
        add(timeManaged);
        add(time50clear);
        add(time80clear);
        add(time100clear);
        add(fallenAgents);
        add(reservation);
        add(slotQuality);
    }};

    List<ObservedItem> getParams = new ArrayList<>(){{
        add(cleared);
        add(energySpent);
        add(communication);
        add(timeManaged);
        add(time50clear);
        add(time80clear);
        add(time100clear);
        add(fallenAgents);
        add(fallenWithoutSlot);
        add(fallenWithSlot);
        add(minBoundAsk);
        add(maxBoundAsk);
        add(convergenceAsk);
        add(decayAsk);
        add(movFactor);
        add(movSafety);
        add(energyFactor);
        add(energySafety);
    }};

    List<ObservedItem> getBestAskParam = new ArrayList<>(){{
        add(cleared);
        add(fallenAgents);
        add(nbCycles);
        add(minBoundAsk);
        add(maxBoundAsk);
        add(convergenceAsk);
        add(decayAsk);
    }};

    List<ObservedItem> getBestMovParam = new ArrayList<>(){{
        add(movFactor);
        add(movSafety);
        add(energyFactor);
        add(energySafety);
    }};

    /**
     * The list that keeps track of all the observed fields in the simulation
     */
    List<ObservedItem> observedItems = evaluation;
}
