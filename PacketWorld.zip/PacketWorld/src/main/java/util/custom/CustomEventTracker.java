package util.custom;

import agent.*;
import agent.behavior.managingSystem.*;

import java.util.*;

/**
 * A custom-made event tracker.
 * Its purpose is to add a way of monitoring event without interfering with the already existent classes
 */
public class CustomEventTracker implements AgentObserver {

    // OBSERVING
    @Override
    public void onAgentFellFlat(AgentImp agent, int turnFellFlat) {
        boolean fellOnTheWayToStation = ((EnergyManagementBehavior) agent.getCurrentBehavior()).isMovingToStation(agent);
        boolean hadASlot = ((EnergyManagementBehavior) agent.getCurrentBehavior()).hasAlreadyChargerSlot(agent);
        AgentFallsFlatAction action = new AgentFallsFlatAction(agent, turnFellFlat, fellOnTheWayToStation, hadASlot);
        addAgentFallsFlatAction(action);
    }

    private void addAgentFallsFlatAction(AgentFallsFlatAction agentFallsFlatAction){
        agentFallsFlatActions.add(agentFallsFlatAction);
    }

    private final List<AgentFallsFlatAction> agentFallsFlatActions = new ArrayList<>();

    // OBSERVERS
    /**
     * Adds this observer to all the agents
     */
    public void observeAgents(Collection<AgentImp> agents){
        agents.forEach(o->o.getCurrentBehavior().addObserver(this));
        observedAgents = agents;
    }

    /**
     * Removes this observer from all the agents
     */
    public void unObserveAgents(Collection<AgentImp> agents){
        agents.forEach(o-> {
            try{o.getCurrentBehavior().removeObserver(this);}catch (Exception e){}
        });
    }

    /**
     * A collection of all the agents this object is observing
     */
    Collection<AgentImp> observedAgents;

    // CLEANUP
    private void clearData(){
        agentFallsFlatActions.clear();
    }

    public void reset(){
        clearData();
        unObserveAgents(observedAgents);
    }


    // AGENT FALL
    public int getNbAgentsFellFlat(){
        return agentFallsFlatActions.size();
    }

    public int getNbAgentsFellFlatWithoutSlot(){
        return (int) agentFallsFlatActions.stream().filter(o->!o.hadAChargerSlot).count();
    }

    public int getNbAgentsFellFlatWithASlot(){
        return (int) agentFallsFlatActions.stream().filter(o->o.hadAChargerSlot).count();
    }

    public int getNbAgentsFellFlatOnTheWayToCharger(){
        return (int) agentFallsFlatActions.stream().filter(o->o.fellOnTheWayToAStation).count();
    }

    public int getNbAgentsFellFlatNotOnTheWayToCharger(){
        return (int) agentFallsFlatActions.stream().filter(o->!o.fellOnTheWayToAStation).count();
    }

    /**
     * A container class to contain the data of when an agent fell flat
     */
    static final class AgentFallsFlatAction {
        final AgentImp agent;
        final int turnFellFlat;
        final boolean fellOnTheWayToAStation;
        final boolean hadAChargerSlot;

        AgentFallsFlatAction(AgentImp agent, int turnFellFlat, boolean fellOnTheWayToAStation, boolean hadAChargerSlot) {
            this.agent = agent;
            this.turnFellFlat = turnFellFlat;
            this.fellOnTheWayToAStation = fellOnTheWayToAStation;
            this.hadAChargerSlot = hadAChargerSlot;
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("agent " + agent.getID() +
                    " fell on turn " + turnFellFlat);

            if(fellOnTheWayToAStation) sb.append(" whilst moving to a station");
            else sb.append(" without moving to a station");

            if(hadAChargerSlot) sb.append(" and had a slot");
            else sb.append(" and had no slot");

            return sb.toString();
        }
    }
}
