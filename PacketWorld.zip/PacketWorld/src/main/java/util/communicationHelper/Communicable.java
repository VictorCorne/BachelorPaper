package util.communicationHelper;

/**
 * An interface whose purpose is to mark items that are able to be communicated about such as item locations and tasks
 */
public interface Communicable {

    /**
     * Returns the communication-size of this item. It represents the number of fields of this item.
     */
    int getCommunicationSize();
}
