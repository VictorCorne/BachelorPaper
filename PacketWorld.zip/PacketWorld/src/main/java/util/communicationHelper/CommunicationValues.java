package util.communicationHelper;

public class CommunicationValues {

    public static String getCommunicationQuantityString(int bits){
        int nbByte = bits / 8;
        int exp = (int) (Math.log(nbByte) / Math.log(2));
        if(exp < 10) return nbByte + " b";
        if(exp < 20) return  String.format("%.2f", nbByte / Math.pow(2, 10)) + " kb";
        return String.format("%.2f", nbByte / Math.pow(2, 20)) + " mb";
    }

    public static final int INTSIZE = 32;
    public static final int BYTESIZE = 8;
    public static final int BOOLSIZE = 1;
}
