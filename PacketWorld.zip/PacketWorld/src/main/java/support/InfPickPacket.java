package support;

import java.awt.Color;

import environment.Environment;
import environment.world.packet.PacketWorld;

/**
 * A class for influences for picking up packages.
 */
public class InfPickPacket extends Influence {

    /**
     * Initializes a new InfPickPacket object
     * Cfr. super
     */
    public InfPickPacket(Environment environment, int x, int y, int agent, Color color) {
        super(environment, x, y, agent, color);
    }

    /**
     * Gets the area of effect (the World it wants to effect) for this Influence
     * @return The PacketWorld
     */
    @Override
    public PacketWorld getAreaOfEffect() {
        return getEnvironment().getWorld(PacketWorld.class);
    }

}
