package support;

import environment.Environment;
import environment.World;

public class InfNOP extends Influence {

    public InfNOP(Environment environment, int itemId) {
        super(environment, -1, -1, itemId, null);
    }

    @Override
    public World<?> getAreaOfEffect() {
        return getEnvironment().getAgentWorld();
    }
}
