rm(list = ls())
setwd("~/Documents/Kulak/Wesenshaften/packetworld/packetWorld/output/LatestSwitchStrategy/")

# LOAD DATA
clumps10IS <- read.delim(" clumps_10Agents informationSharing.txt", comment.char="#")
clumps10RP <- read.delim(" clumps_10Agents regional.txt", comment.char="#")
clumps10MS <- read.delim(" clumps_10Agents slave.txt", comment.char="#")
clumps20IS <- read.delim(" clumps_20Agents informationSharing.txt", comment.char="#")
clumps20RP <- read.delim(" clumps_20Agents regional.txt", comment.char="#")
clumps20MS <- read.delim(" clumps_20Agents slave.txt", comment.char="#")
clumps30IS <- read.delim(" clumps_30Agents informationSharing.txt", comment.char="#")
clumps30RP <- read.delim(" clumps_30Agents regional.txt", comment.char="#")
clumps30MS <- read.delim(" clumps_30Agents slave.txt", comment.char="#")
ring16IS <- read.delim(" ring_16Agents informationSharing.txt", comment.char="#")
ring16RP <- read.delim(" ring_16Agents regional.txt", comment.char="#")
ring16MS <- read.delim(" ring_16Agents slave.txt", comment.char="#")
ring24IS <- read.delim(" ring_24Agents informationSharing.txt", comment.char="#")
ring24RP <- read.delim(" ring_24Agents regional.txt", comment.char="#")
ring24MS <- read.delim(" ring_24Agents slave.txt", comment.char="#")
ring32IS <- read.delim(" ring_32Agents informationSharing.txt", comment.char="#")
ring32RP <- read.delim(" ring_32Agents regional.txt", comment.char="#")
ring32MS <- read.delim(" ring_32Agents slave.txt", comment.char="#")
scattered15IS <- read.delim(" scattered_15Agents informationSharing.txt", comment.char="#")
scattered15RP <- read.delim(" scattered_15Agents regional.txt", comment.char="#")
scattered15MS <- read.delim(" scattered_15Agents slave.txt", comment.char="#")
scattered20IS <- read.delim(" scattered_20Agents informationSharing.txt", comment.char="#")
scattered20RP <- read.delim(" scattered_20Agents regional.txt", comment.char="#")
scattered20MS <- read.delim(" scattered_20Agents slave.txt", comment.char="#")
scattered25IS <- read.delim(" scattered_25Agents informationSharing.txt", comment.char="#")
scattered25RP <- read.delim(" scattered_25Agents regional.txt", comment.char="#")
scattered25MS <- read.delim(" scattered_25Agents slave.txt", comment.char="#")
workDensity8IS <- read.delim(" workDensity_8Agents informationSharing.txt", comment.char="#")
workDensity8RP <- read.delim(" workDensity_8Agents regional.txt", comment.char="#")
workDensity8MS <- read.delim(" workDensity_8Agents slave.txt", comment.char="#")
workDensity16IS <- read.delim(" workDensity_16Agents informationSharing.txt", comment.char="#")
workDensity16RP <- read.delim(" workDensity_16Agents regional.txt", comment.char="#")
workDensity16MS <- read.delim(" workDensity_16Agents slave.txt", comment.char="#")
workDensity24IS <- read.delim(" workDensity_24Agents informationSharing.txt", comment.char="#")
workDensity24RP <- read.delim(" workDensity_24Agents regional.txt", comment.char="#")
workDensity24MS <- read.delim(" workDensity_24Agents slave.txt", comment.char="#")

# PLOT THE TIME NEEDED TO CLEAR THE ENVIRONMENT
pdf(file = "Clearing plots", width = 10)
boxplot(clumps10MS$Clear50, clumps10RP$Clear50, clumps10IS$Clear50,
        clumps10MS$Clear80, clumps10RP$Clear80, clumps10IS$Clear80,
        clumps10MS$Clear100, clumps10RP$Clear100, clumps10IS$Clear100
        ,names = c("MS 50%",  "RP 50%",  "IS 50%",
                   "MS 80%",  "RP 80%",  "IS 80%",
                   "MS 100%", "RP 100%", "IS 100%")
        , main = "Time needed to clear the environment on the clumps map with 10 agents"
        , xlab = "Number of cycles needed to clear the environment"
        , horizontal = 1,
        las = 1)

boxplot(clumps20MS$Clear50, clumps20RP$Clear50, clumps20IS$Clear50,
        clumps20MS$Clear80, clumps20RP$Clear80, clumps20IS$Clear80,
        clumps20MS$Clear100, clumps20RP$Clear100, clumps20IS$Clear100
        ,names = c("MS 50%",  "RP 50%",  "IS 50%",
                   "MS 80%",  "RP 80%",  "IS 80%",
                   "MS 100%", "RP 100%", "IS 100%")
        , main = "Time needed to clear the environment on the clumps map with 20 agents"
        , xlab = "Number of cycles needed to clear the environment"
        , horizontal = 1,
        las = 1)

boxplot(clumps30MS$Clear50, clumps30RP$Clear50, clumps30IS$Clear50,
        clumps30MS$Clear80, clumps30RP$Clear80, clumps30IS$Clear80,
        clumps30MS$Clear100, clumps30RP$Clear100, clumps30IS$Clear100
        ,names = c("MS 50%",  "RP 50%",  "IS 50%",
                   "MS 80%",  "RP 80%",  "IS 80%",
                   "MS 100%", "RP 100%", "IS 100%")
        , main = "Time needed to clear the environment on the clumps map with 30 agents"
        , xlab = "Number of cycles needed to clear the environment"
        , horizontal = 1,
        las = 1)

boxplot(ring16MS$Clear50, ring16RP$Clear50, ring16IS$Clear50,
        ring16MS$Clear80, ring16RP$Clear80, ring16IS$Clear80,
        ring16MS$Clear100, ring16RP$Clear100, ring16IS$Clear100
        ,names = c("MS 50%",  "RP 50%",  "IS 50%",
                   "MS 80%",  "RP 80%",  "IS 80%",
                   "MS 100%", "RP 100%", "IS 100%")
        , main = "Time needed to clear the environment on the ring map with 16 agents"
        , xlab = "Number of cycles needed to clear the environment"
        , horizontal = 1,
        las = 1)

boxplot(ring24MS$Clear50, ring24RP$Clear50, ring24IS$Clear50,
        ring24MS$Clear80, ring24RP$Clear80, ring24IS$Clear80,
        ring24MS$Clear100, ring24RP$Clear100, ring24IS$Clear100
        ,names = c("MS 50%",  "RP 50%",  "IS 50%",
                   "MS 80%",  "RP 80%",  "IS 80%",
                   "MS 100%", "RP 100%", "IS 100%")
        , main = "Time needed to clear the environment on the ring map with 24 agents"
        , xlab = "Number of cycles needed to clear the environment"
        , horizontal = 1,
        las = 1)

boxplot(ring32MS$Clear50, ring32RP$Clear50, ring32IS$Clear50,
        ring32MS$Clear80, ring32RP$Clear80, ring32IS$Clear80,
        ring32MS$Clear100, ring32RP$Clear100, ring32IS$Clear100
        ,names = c("MS 50%",  "RP 50%",  "IS 50%",
                   "MS 80%",  "RP 80%",  "IS 80%",
                   "MS 100%", "RP 100%", "IS 100%")
        , main = "Time needed to clear the environment on the ring map with 32 agents"
        , xlab = "Number of cycles needed to clear the environment"
        , horizontal = 1,
        las = 1)

boxplot(scattered15MS$Clear50, scattered15RP$Clear50, scattered15IS$Clear50,
        scattered15MS$Clear80, scattered15RP$Clear80, scattered15IS$Clear80,
        scattered15MS$Clear100, scattered15RP$Clear100, scattered15IS$Clear100
        ,names = c("MS 50%",  "RP 50%",  "IS 50%",
                   "MS 80%",  "RP 80%",  "IS 80%",
                   "MS 100%", "RP 100%", "IS 100%")
        , main = "Time needed to clear the environment on the scattered map with 15 agents"
        , xlab = "Number of cycles needed to clear the environment"
        , horizontal = 1,
        las = 1)

boxplot(scattered20MS$Clear50, scattered20RP$Clear50, scattered20IS$Clear50,
        scattered20MS$Clear80, scattered20RP$Clear80, scattered20IS$Clear80,
        scattered20MS$Clear100, scattered20RP$Clear100, scattered20IS$Clear100
        ,names = c("MS 50%",  "RP 50%",  "IS 50%",
                   "MS 80%",  "RP 80%",  "IS 80%",
                   "MS 100%", "RP 100%", "IS 100%")
        , main = "Time needed to clear the environment on the scattered map with 20 agents"
        , xlab = "Number of cycles needed to clear the environment"
        , horizontal = 1,
        las = 1)

boxplot(scattered25MS$Clear50, scattered25RP$Clear50, scattered25IS$Clear50,
        scattered25MS$Clear80, scattered25RP$Clear80, scattered25IS$Clear80,
        scattered25MS$Clear100, scattered25RP$Clear100, scattered25IS$Clear100
        ,names = c("MS 50%",  "RP 50%",  "IS 50%",
                   "MS 80%",  "RP 80%",  "IS 80%",
                   "MS 100%", "RP 100%", "IS 100%")
        , main = "Time needed to clear the environment on the scattered map with 25 agents"
        , xlab = "Number of cycles needed to clear the environment"
        , horizontal = 1,
        las = 1)

boxplot(workDensity8MS$Clear50, workDensity8RP$Clear50, workDensity8IS$Clear50,
        workDensity8MS$Clear80, workDensity8RP$Clear80, workDensity8IS$Clear80,
        workDensity8MS$Clear100, workDensity8RP$Clear100, workDensity8IS$Clear100
        ,names = c("MS 50%",  "RP 50%",  "IS 50%",
                   "MS 80%",  "RP 80%",  "IS 80%",
                   "MS 100%", "RP 100%", "IS 100%")
        , main = "Time needed to clear the environment on the workDensity map with 8 agents"
        , xlab = "Number of cycles needed to clear the environment"
        , horizontal = 1,
        las = 1)

boxplot(workDensity16MS$Clear50, workDensity16RP$Clear50, workDensity16IS$Clear50,
        workDensity16MS$Clear80, workDensity16RP$Clear80, workDensity16IS$Clear80,
        workDensity16MS$Clear100, workDensity16RP$Clear100, workDensity16IS$Clear100
        ,names = c("MS 50%",  "RP 50%",  "IS 50%",
                   "MS 80%",  "RP 80%",  "IS 80%",
                   "MS 100%", "RP 100%", "IS 100%")
        , main = "Time needed to clear the environment on the workDensity map with 16 agents"
        , xlab = "Number of cycles needed to clear the environment"
        , horizontal = 1,
        las = 1)

boxplot(workDensity24MS$Clear50, workDensity24RP$Clear50, workDensity24IS$Clear50,
        workDensity24MS$Clear80, workDensity24RP$Clear80, workDensity24IS$Clear80,
        workDensity24MS$Clear100, workDensity24RP$Clear100, workDensity24IS$Clear100
        ,names = c("MS 50%",  "RP 50%",  "IS 50%",
                   "MS 80%",  "RP 80%",  "IS 80%",
                   "MS 100%", "RP 100%", "IS 100%")
        , main = "Time needed to clear the environment on the workDensity map with 24 agents"
        , xlab = "Number of cycles needed to clear the environment"
        , horizontal = 1,
        las = 1)
dev.off()


# PLOTS FOR THE FAIL RATE
pdf(file = "Fail plots", width = 10)

boxplot(clumps10MS$Fail, clumps10RP$Fail, clumps10IS$Fail,
        clumps20MS$Fail, clumps20RP$Fail, clumps20IS$Fail,
        clumps30MS$Fail, clumps30RP$Fail, clumps30IS$Fail
        ,names = c("MS 10", "RP 10", "IS 10",
                   "MS 20", "RP 20", "IS 20",
                   "MS 30", "RP 30", "IS 30")
        , main = "The average number of failing agents on the clumps map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(ring16MS$Fail, ring16RP$Fail, ring16IS$Fail,
        ring24MS$Fail, ring24RP$Fail, ring24IS$Fail,
        ring32MS$Fail, ring32RP$Fail, ring32IS$Fail
        ,names = c("MS 16", "RP 16", "IS 16",
                   "MS 24", "RP 24", "IS 24",
                   "MS 32", "RP 32", "IS 32")
        , main = "The average number of failing agents on the ring map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(scattered15MS$Fail, scattered15RP$Fail, scattered15IS$Fail,
        scattered20MS$Fail, scattered20RP$Fail, scattered20IS$Fail,
        scattered25MS$Fail, scattered25RP$Fail, scattered25IS$Fail
        ,names = c("MS 15", "RP 15", "IS 15",
                   "MS 20", "RP 20", "IS 20",
                   "MS 25", "RP 25", "IS 25")
        , main = "The average number of failing agents on the scattered map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(workDensity8MS$Fail, workDensity8RP$Fail, workDensity8IS$Fail,
        workDensity16MS$Fail, workDensity16RP$Fail, workDensity16IS$Fail,
        workDensity24MS$Fail, workDensity24RP$Fail, workDensity24IS$Fail
        ,names = c("MS 8", "RP 8", "IS 8",
                   "MS 16", "RP 16", "IS 16",
                   "MS 24", "RP 24", "IS 24")
        , main = "The average number of failing agents on the workDensity map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)
dev.off()


# PLOTS FOR THE MANAGEMENT %
pdf(file = "timeManaged plots", width = 10)
boxplot(clumps10MS$timeManaged, clumps10RP$timeManaged, clumps10IS$timeManaged,
        clumps20MS$timeManaged, clumps20RP$timeManaged, clumps20IS$timeManaged,
        clumps30MS$timeManaged, clumps30RP$timeManaged, clumps30IS$timeManaged
        ,names = c("MS 10", "RP 10", "IS 10",
                   "MS 20", "RP 20", "IS 20",
                   "MS 30", "RP 30", "IS 30")
        , main = "Percentage of time agents are being managed in the clumps map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(ring16MS$timeManaged, ring16RP$timeManaged, ring16IS$timeManaged,
        ring24MS$timeManaged, ring24RP$timeManaged, ring24IS$timeManaged,
        ring32MS$timeManaged, ring32RP$timeManaged, ring32IS$timeManaged
        ,names = c("MS 16", "RP 16", "IS 16",
                   "MS 24", "RP 24", "IS 24",
                   "MS 32", "RP 32", "IS 32")
        , main = "Percentage of time agents are being managed in the ring map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(scattered15MS$timeManaged, scattered15RP$timeManaged, scattered15IS$timeManaged,
        scattered20MS$timeManaged, scattered20RP$timeManaged, scattered20IS$timeManaged,
        scattered25MS$timeManaged, scattered25RP$timeManaged, scattered25IS$timeManaged
        ,names = c("MS 15", "RP 15", "IS 15",
                   "MS 20", "RP 20", "IS 20",
                   "MS 25", "RP 25", "IS 25")
        , main = "Percentage of time agents are being managed in the scattered map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(workDensity8MS$timeManaged, workDensity8RP$timeManaged, workDensity8IS$timeManaged,
        workDensity16MS$timeManaged, workDensity16RP$timeManaged, workDensity16IS$timeManaged,
        workDensity24MS$timeManaged, workDensity24RP$timeManaged, workDensity24IS$timeManaged
        ,names = c("MS 8", "RP 8", "IS 8",
                   "MS 16", "RP 16", "IS 16",
                   "MS 24", "RP 24", "IS 24")
        , main = "Percentage of time agents are being managed in the workDensity map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)
dev.off()


# PLOTS FOR THE ENERGY SPENT
pdf(file = "EnergySpent plots", width = 10)
boxplot(clumps10MS$Energy, clumps10RP$Energy, clumps10IS$Energy,
        clumps20MS$Energy, clumps20RP$Energy, clumps20IS$Energy,
        clumps30MS$Energy, clumps30RP$Energy, clumps30IS$Energy
        ,names = c("MS 10", "RP 10", "IS 10",
                   "MS 20", "RP 20", "IS 20",
                   "MS 30", "RP 30", "IS 30")
        , main = "The average energy spent on the clumps map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(ring16MS$Energy, ring16RP$Energy, ring16IS$Energy,
        ring24MS$Energy, ring24RP$Energy, ring24IS$Energy,
        ring32MS$Energy, ring32RP$Energy, ring32IS$Energy
        ,names = c("MS 16", "RP 16", "IS 16",
                   "MS 24", "RP 24", "IS 24",
                   "MS 32", "RP 32", "IS 32")
        , main = "The average energy spent on the ring map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(scattered15MS$Energy, scattered15RP$Energy, scattered15IS$Energy,
        scattered20MS$Energy, scattered20RP$Energy, scattered20IS$Energy,
        scattered25MS$Energy, scattered25RP$Energy, scattered25IS$Energy
        ,names = c("MS 15", "RP 15", "IS 15",
                   "MS 20", "RP 20", "IS 20",
                   "MS 25", "RP 25", "IS 25")
        , main = "The average energy spent on the scattered map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(workDensity8MS$Energy, workDensity8RP$Energy, workDensity8IS$Energy,
        workDensity16MS$Energy, workDensity16RP$Energy, workDensity16IS$Energy,
        workDensity24MS$Energy, workDensity24RP$Energy, workDensity24IS$Energy
        ,names = c("MS 8", "RP 8", "IS 8",
                   "MS 16", "RP 16", "IS 16",
                   "MS 24", "RP 24", "IS 24")
        , main = "The average energy spent on the workDensity map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)
dev.off()


# PLOTS FOR THE RESERVATION OF THE CHARGERS
pdf(file = "Reservation plots", width = 10)
boxplot(clumps10MS$Reservation, clumps10RP$Reservation, clumps10IS$Reservation,
        clumps20MS$Reservation, clumps20RP$Reservation, clumps20IS$Reservation,
        clumps30MS$Reservation, clumps30RP$Reservation, clumps30IS$Reservation
        ,names = c("MS 10", "RP 10", "IS 10",
                   "MS 20", "RP 20", "IS 20",
                   "MS 30", "RP 30", "IS 30")
        , main = "The average percentage of time the charging stations were reserved on the clumps map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(ring16MS$Reservation, ring16RP$Reservation, ring16IS$Reservation,
        ring24MS$Reservation, ring24RP$Reservation, ring24IS$Reservation,
        ring32MS$Reservation, ring32RP$Reservation, ring32IS$Reservation
        ,names = c("MS 16", "RP 16", "IS 16",
                   "MS 24", "RP 24", "IS 24",
                   "MS 32", "RP 32", "IS 32")
        , main = "The average percentage of time the charging stations were reserved on the ring map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(scattered15MS$Reservation, scattered15RP$Reservation, scattered15IS$Reservation,
        scattered20MS$Reservation, scattered20RP$Reservation, scattered20IS$Reservation,
        scattered25MS$Reservation, scattered25RP$Reservation, scattered25IS$Reservation
        ,names = c("MS 15", "RP 15", "IS 15",
                   "MS 20", "RP 20", "IS 20",
                   "MS 25", "RP 25", "IS 25")
        , main = "The average percentage of time the charging stations were reserved on the scattered map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(workDensity8MS$Reservation, workDensity8RP$Reservation, workDensity8IS$Reservation,
        workDensity16MS$Reservation, workDensity16RP$Reservation, workDensity16IS$Reservation,
        workDensity24MS$Reservation, workDensity24RP$Reservation, workDensity24IS$Reservation
        ,names = c("MS 8", "RP 8", "IS 8",
                   "MS 16", "RP 16", "IS 16",
                   "MS 24", "RP 24", "IS 24")
        , main = "The average percentage of time the charging stations were reserved on the workDensity map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)
dev.off()


#PLOTS FOR THE SLOT QUALITY
pdf(file = "slotQuality plot", width = 10)
boxplot(clumps10MS$SlotQuality, clumps10RP$SlotQuality, clumps10IS$SlotQuality,
        clumps20MS$SlotQuality, clumps20RP$SlotQuality, clumps20IS$SlotQuality,
        clumps30MS$SlotQuality, clumps30RP$SlotQuality, clumps30IS$SlotQuality
        ,names = c("MS 10", "RP 10", "IS 10",
                   "MS 20", "RP 20", "IS 20",
                   "MS 30", "RP 30", "IS 30")
        , main = "The average quality of the given slots on the clumps map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(ring16MS$SlotQuality, ring16RP$SlotQuality, ring16IS$SlotQuality,
        ring24MS$SlotQuality, ring24RP$SlotQuality, ring24IS$SlotQuality,
        ring32MS$SlotQuality, ring32RP$SlotQuality, ring32IS$SlotQuality
        ,names = c("MS 16", "RP 16", "IS 16",
                   "MS 24", "RP 24", "IS 24",
                   "MS 32", "RP 32", "IS 32")
        , main = "The average quality of the given slots on the ring map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(scattered15MS$SlotQuality, scattered15RP$SlotQuality, scattered15IS$SlotQuality,
        scattered20MS$SlotQuality, scattered20RP$SlotQuality, scattered20IS$SlotQuality,
        scattered25MS$SlotQuality, scattered25RP$SlotQuality, scattered25IS$SlotQuality
        ,names = c("MS 15", "RP 15", "IS 15",
                   "MS 20", "RP 20", "IS 20",
                   "MS 25", "RP 25", "IS 25")
        , main = "The average quality of the given slots on the scattered map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(workDensity8MS$SlotQuality, workDensity8RP$SlotQuality, workDensity8IS$SlotQuality,
        workDensity16MS$SlotQuality, workDensity16RP$SlotQuality, workDensity16IS$SlotQuality,
        workDensity24MS$SlotQuality, workDensity24RP$SlotQuality, workDensity24IS$SlotQuality
        ,names = c("MS 8", "RP 8", "IS 8",
                   "MS 16", "RP 16", "IS 16",
                   "MS 24", "RP 24", "IS 24")
        , main = "The average quality of the given slots on the workDensity map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)
dev.off()

# PLOTS FOR THE MESSAGES SENT

# first determine the communication data

clumps10IS$SchedulerToSchedulerMessages <- 0
clumps10IS$AgentToSchedulerMessages <- 0
clumps10IS$SchedulerToAgentMessages <- 0
clumps10IS$AgentToAgentMessages <- clumps10IS$SlotReservedNotification
clumps10IS$TotalMessagesSent <- clumps10IS$AgentToAgentMessages + clumps10IS$SchedulerToAgentMessages + clumps10IS$AgentToSchedulerMessages + clumps10IS$SchedulerToSchedulerMessages

clumps10RP$SchedulerToSchedulerMessages <- clumps10RP$SchedulerSlotAnswerMail +clumps10RP$SchedulerSlotRequestMail +clumps10RP$SchedulerSlotAck
clumps10RP$AgentToSchedulerMessages <- clumps10RP$SlotRequestMail
clumps10RP$SchedulerToAgentMessages <- clumps10RP$SlotReservedMail
clumps10RP$AgentToAgentMessages <- 0
clumps10RP$TotalMessagesSent <- clumps10RP$AgentToAgentMessages + clumps10RP$SchedulerToAgentMessages + clumps10RP$AgentToSchedulerMessages + clumps10RP$SchedulerToSchedulerMessages

clumps10MS$SchedulerToSchedulerMessages <- 0
clumps10MS$AgentToSchedulerMessages <- clumps10MS$SlotRequestMail
clumps10MS$SchedulerToAgentMessages <- clumps10MS$SlotReservedMail
clumps10MS$AgentToAgentMessages <- 0
clumps10MS$TotalMessagesSent <- clumps10MS$AgentToAgentMessages + clumps10MS$SchedulerToAgentMessages + clumps10MS$AgentToSchedulerMessages + clumps10MS$SchedulerToSchedulerMessages

clumps20IS$SchedulerToSchedulerMessages <- 0
clumps20IS$AgentToSchedulerMessages <- 0
clumps20IS$SchedulerToAgentMessages <- 0
clumps20IS$AgentToAgentMessages <- clumps20IS$SlotReservedNotification
clumps20IS$TotalMessagesSent <- clumps20IS$AgentToAgentMessages + clumps20IS$SchedulerToAgentMessages + clumps20IS$AgentToSchedulerMessages + clumps20IS$SchedulerToSchedulerMessages

clumps20RP$SchedulerToSchedulerMessages <- clumps20RP$SchedulerSlotAnswerMail +clumps20RP$SchedulerSlotRequestMail +clumps20RP$SchedulerSlotAck
clumps20RP$AgentToSchedulerMessages <- clumps20RP$SlotRequestMail
clumps20RP$SchedulerToAgentMessages <- clumps20RP$SlotReservedMail
clumps20RP$AgentToAgentMessages <- 0
clumps20RP$TotalMessagesSent <- clumps20RP$AgentToAgentMessages + clumps20RP$SchedulerToAgentMessages + clumps20RP$AgentToSchedulerMessages + clumps20RP$SchedulerToSchedulerMessages

clumps20MS$SchedulerToSchedulerMessages <- 0
clumps20MS$AgentToSchedulerMessages <- clumps20MS$SlotRequestMail
clumps20MS$SchedulerToAgentMessages <- clumps20MS$SlotReservedMail
clumps20MS$AgentToAgentMessages <- 0
clumps20MS$TotalMessagesSent <- clumps20MS$AgentToAgentMessages + clumps20MS$SchedulerToAgentMessages + clumps20MS$AgentToSchedulerMessages + clumps20MS$SchedulerToSchedulerMessages

clumps30IS$SchedulerToSchedulerMessages <- 0
clumps30IS$AgentToSchedulerMessages <- 0
clumps30IS$SchedulerToAgentMessages <- 0
clumps30IS$AgentToAgentMessages <- clumps30IS$SlotReservedNotification
clumps30IS$TotalMessagesSent <- clumps30IS$AgentToAgentMessages + clumps30IS$SchedulerToAgentMessages + clumps30IS$AgentToSchedulerMessages + clumps30IS$SchedulerToSchedulerMessages

clumps30RP$SchedulerToSchedulerMessages <- clumps30RP$SchedulerSlotAnswerMail +clumps30RP$SchedulerSlotRequestMail +clumps30RP$SchedulerSlotAck
clumps30RP$AgentToSchedulerMessages <- clumps30RP$SlotRequestMail
clumps30RP$SchedulerToAgentMessages <- clumps30RP$SlotReservedMail
clumps30RP$AgentToAgentMessages <- 0
clumps30RP$TotalMessagesSent <- clumps30RP$AgentToAgentMessages + clumps30RP$SchedulerToAgentMessages + clumps30RP$AgentToSchedulerMessages + clumps30RP$SchedulerToSchedulerMessages

clumps30MS$SchedulerToSchedulerMessages <- 0
clumps30MS$AgentToSchedulerMessages <- clumps30MS$SlotRequestMail
clumps30MS$SchedulerToAgentMessages <- clumps30MS$SlotReservedMail
clumps30MS$AgentToAgentMessages <- 0
clumps30MS$TotalMessagesSent <- clumps30MS$AgentToAgentMessages + clumps30MS$SchedulerToAgentMessages + clumps30MS$AgentToSchedulerMessages + clumps30MS$SchedulerToSchedulerMessages

ring16IS$SchedulerToSchedulerMessages <- 0
ring16IS$AgentToSchedulerMessages <- 0
ring16IS$SchedulerToAgentMessages <- 0
ring16IS$AgentToAgentMessages <- ring16IS$SlotReservedNotification
ring16IS$TotalMessagesSent <- ring16IS$AgentToAgentMessages + ring16IS$SchedulerToAgentMessages + ring16IS$AgentToSchedulerMessages + ring16IS$SchedulerToSchedulerMessages

ring16RP$SchedulerToSchedulerMessages <- ring16RP$SchedulerSlotAnswerMail +ring16RP$SchedulerSlotRequestMail +ring16RP$SchedulerSlotAck
ring16RP$AgentToSchedulerMessages <- ring16RP$SlotRequestMail
ring16RP$SchedulerToAgentMessages <- ring16RP$SlotReservedMail
ring16RP$AgentToAgentMessages <- 0
ring16RP$TotalMessagesSent <- ring16RP$AgentToAgentMessages + ring16RP$SchedulerToAgentMessages + ring16RP$AgentToSchedulerMessages + ring16RP$SchedulerToSchedulerMessages

ring16MS$SchedulerToSchedulerMessages <- 0
ring16MS$AgentToSchedulerMessages <- ring16MS$SlotRequestMail
ring16MS$SchedulerToAgentMessages <- ring16MS$SlotReservedMail
ring16MS$AgentToAgentMessages <- 0
ring16MS$TotalMessagesSent <- ring16MS$AgentToAgentMessages + ring16MS$SchedulerToAgentMessages + ring16MS$AgentToSchedulerMessages + ring16MS$SchedulerToSchedulerMessages

ring24IS$SchedulerToSchedulerMessages <- 0
ring24IS$AgentToSchedulerMessages <- 0
ring24IS$SchedulerToAgentMessages <- 0
ring24IS$AgentToAgentMessages <- ring24IS$SlotReservedNotification
ring24IS$TotalMessagesSent <- ring24IS$AgentToAgentMessages + ring24IS$SchedulerToAgentMessages + ring24IS$AgentToSchedulerMessages + ring24IS$SchedulerToSchedulerMessages

ring24RP$SchedulerToSchedulerMessages <- ring24RP$SchedulerSlotAnswerMail +ring24RP$SchedulerSlotRequestMail +ring24RP$SchedulerSlotAck
ring24RP$AgentToSchedulerMessages <- ring24RP$SlotRequestMail
ring24RP$SchedulerToAgentMessages <- ring24RP$SlotReservedMail
ring24RP$AgentToAgentMessages <- 0
ring24RP$TotalMessagesSent <- ring24RP$AgentToAgentMessages + ring24RP$SchedulerToAgentMessages + ring24RP$AgentToSchedulerMessages + ring24RP$SchedulerToSchedulerMessages

ring24MS$SchedulerToSchedulerMessages <- 0
ring24MS$AgentToSchedulerMessages <- ring24MS$SlotRequestMail
ring24MS$SchedulerToAgentMessages <- ring24MS$SlotReservedMail
ring24MS$AgentToAgentMessages <- 0
ring24MS$TotalMessagesSent <- ring24MS$AgentToAgentMessages + ring24MS$SchedulerToAgentMessages + ring24MS$AgentToSchedulerMessages + ring24MS$SchedulerToSchedulerMessages

ring32IS$SchedulerToSchedulerMessages <- 0
ring32IS$AgentToSchedulerMessages <- 0
ring32IS$SchedulerToAgentMessages <- 0
ring32IS$AgentToAgentMessages <- ring32IS$SlotReservedNotification
ring32IS$TotalMessagesSent <- ring32IS$AgentToAgentMessages + ring32IS$SchedulerToAgentMessages + ring32IS$AgentToSchedulerMessages + ring32IS$SchedulerToSchedulerMessages

ring32RP$SchedulerToSchedulerMessages <- ring32RP$SchedulerSlotAnswerMail +ring32RP$SchedulerSlotRequestMail +ring32RP$SchedulerSlotAck
ring32RP$AgentToSchedulerMessages <- ring32RP$SlotRequestMail
ring32RP$SchedulerToAgentMessages <- ring32RP$SlotReservedMail
ring32RP$AgentToAgentMessages <- 0
ring32RP$TotalMessagesSent <- ring32RP$AgentToAgentMessages + ring32RP$SchedulerToAgentMessages + ring32RP$AgentToSchedulerMessages + ring32RP$SchedulerToSchedulerMessages

ring32MS$SchedulerToSchedulerMessages <- 0
ring32MS$AgentToSchedulerMessages <- ring32MS$SlotRequestMail
ring32MS$SchedulerToAgentMessages <- ring32MS$SlotReservedMail
ring32MS$AgentToAgentMessages <- 0
ring32MS$TotalMessagesSent <- ring32MS$AgentToAgentMessages + ring32MS$SchedulerToAgentMessages + ring32MS$AgentToSchedulerMessages + ring32MS$SchedulerToSchedulerMessages

scattered15IS$SchedulerToSchedulerMessages <- 0
scattered15IS$AgentToSchedulerMessages <- 0
scattered15IS$SchedulerToAgentMessages <- 0
scattered15IS$AgentToAgentMessages <- scattered15IS$SlotReservedNotification
scattered15IS$TotalMessagesSent <- scattered15IS$AgentToAgentMessages + scattered15IS$SchedulerToAgentMessages + scattered15IS$AgentToSchedulerMessages + scattered15IS$SchedulerToSchedulerMessages

scattered15RP$SchedulerToSchedulerMessages <- scattered15RP$SchedulerSlotAnswerMail +scattered15RP$SchedulerSlotRequestMail +scattered15RP$SchedulerSlotAck
scattered15RP$AgentToSchedulerMessages <- scattered15RP$SlotRequestMail
scattered15RP$SchedulerToAgentMessages <- scattered15RP$SlotReservedMail
scattered15RP$AgentToAgentMessages <- 0
scattered15RP$TotalMessagesSent <- scattered15RP$AgentToAgentMessages + scattered15RP$SchedulerToAgentMessages + scattered15RP$AgentToSchedulerMessages + scattered15RP$SchedulerToSchedulerMessages

scattered15MS$SchedulerToSchedulerMessages <- 0
scattered15MS$AgentToSchedulerMessages <- scattered15MS$SlotRequestMail
scattered15MS$SchedulerToAgentMessages <- scattered15MS$SlotReservedMail
scattered15MS$AgentToAgentMessages <- 0
scattered15MS$TotalMessagesSent <- scattered15MS$AgentToAgentMessages + scattered15MS$SchedulerToAgentMessages + scattered15MS$AgentToSchedulerMessages + scattered15MS$SchedulerToSchedulerMessages

scattered20IS$SchedulerToSchedulerMessages <- 0
scattered20IS$AgentToSchedulerMessages <- 0
scattered20IS$SchedulerToAgentMessages <- 0
scattered20IS$AgentToAgentMessages <- scattered20IS$SlotReservedNotification
scattered20IS$TotalMessagesSent <- scattered20IS$AgentToAgentMessages + scattered20IS$SchedulerToAgentMessages + scattered20IS$AgentToSchedulerMessages + scattered20IS$SchedulerToSchedulerMessages

scattered20RP$SchedulerToSchedulerMessages <- scattered20RP$SchedulerSlotAnswerMail +scattered20RP$SchedulerSlotRequestMail +scattered20RP$SchedulerSlotAck
scattered20RP$AgentToSchedulerMessages <- scattered20RP$SlotRequestMail
scattered20RP$SchedulerToAgentMessages <- scattered20RP$SlotReservedMail
scattered20RP$AgentToAgentMessages <- 0
scattered20RP$TotalMessagesSent <- scattered20RP$AgentToAgentMessages + scattered20RP$SchedulerToAgentMessages + scattered20RP$AgentToSchedulerMessages + scattered20RP$SchedulerToSchedulerMessages

scattered20MS$SchedulerToSchedulerMessages <- 0
scattered20MS$AgentToSchedulerMessages <- scattered20MS$SlotRequestMail
scattered20MS$SchedulerToAgentMessages <- scattered20MS$SlotReservedMail
scattered20MS$AgentToAgentMessages <- 0
scattered20MS$TotalMessagesSent <- scattered20MS$AgentToAgentMessages + scattered20MS$SchedulerToAgentMessages + scattered20MS$AgentToSchedulerMessages + scattered20MS$SchedulerToSchedulerMessages

scattered25IS$SchedulerToSchedulerMessages <- 0
scattered25IS$AgentToSchedulerMessages <- 0
scattered25IS$SchedulerToAgentMessages <- 0
scattered25IS$AgentToAgentMessages <- scattered25IS$SlotReservedNotification
scattered25IS$TotalMessagesSent <- scattered25IS$AgentToAgentMessages + scattered25IS$SchedulerToAgentMessages + scattered25IS$AgentToSchedulerMessages + scattered25IS$SchedulerToSchedulerMessages

scattered25RP$SchedulerToSchedulerMessages <- scattered25RP$SchedulerSlotAnswerMail +scattered25RP$SchedulerSlotRequestMail +scattered25RP$SchedulerSlotAck
scattered25RP$AgentToSchedulerMessages <- scattered25RP$SlotRequestMail
scattered25RP$SchedulerToAgentMessages <- scattered25RP$SlotReservedMail
scattered25RP$AgentToAgentMessages <- 0
scattered25RP$TotalMessagesSent <- scattered25RP$AgentToAgentMessages + scattered25RP$SchedulerToAgentMessages + scattered25RP$AgentToSchedulerMessages + scattered25RP$SchedulerToSchedulerMessages

scattered25MS$SchedulerToSchedulerMessages <- 0
scattered25MS$AgentToSchedulerMessages <- scattered25MS$SlotRequestMail
scattered25MS$SchedulerToAgentMessages <- scattered25MS$SlotReservedMail
scattered25MS$AgentToAgentMessages <- 0
scattered25MS$TotalMessagesSent <- scattered25MS$AgentToAgentMessages + scattered25MS$SchedulerToAgentMessages + scattered25MS$AgentToSchedulerMessages + scattered25MS$SchedulerToSchedulerMessages

workDensity8IS$SchedulerToSchedulerMessages <- 0
workDensity8IS$AgentToSchedulerMessages <- 0
workDensity8IS$SchedulerToAgentMessages <- 0
workDensity8IS$AgentToAgentMessages <- workDensity8IS$SlotReservedNotification
workDensity8IS$TotalMessagesSent <- workDensity8IS$AgentToAgentMessages + workDensity8IS$SchedulerToAgentMessages + workDensity8IS$AgentToSchedulerMessages + workDensity8IS$SchedulerToSchedulerMessages

workDensity8RP$SchedulerToSchedulerMessages <- workDensity8RP$SchedulerSlotAnswerMail +workDensity8RP$SchedulerSlotRequestMail +workDensity8RP$SchedulerSlotAck
workDensity8RP$AgentToSchedulerMessages <- workDensity8RP$SlotRequestMail
workDensity8RP$SchedulerToAgentMessages <- workDensity8RP$SlotReservedMail
workDensity8RP$AgentToAgentMessages <- 0
workDensity8RP$TotalMessagesSent <- workDensity8RP$AgentToAgentMessages + workDensity8RP$SchedulerToAgentMessages + workDensity8RP$AgentToSchedulerMessages + workDensity8RP$SchedulerToSchedulerMessages

workDensity8MS$SchedulerToSchedulerMessages <- 0
workDensity8MS$AgentToSchedulerMessages <- workDensity8MS$SlotRequestMail
workDensity8MS$SchedulerToAgentMessages <- workDensity8MS$SlotReservedMail
workDensity8MS$AgentToAgentMessages <- 0
workDensity8MS$TotalMessagesSent <- workDensity8MS$AgentToAgentMessages + workDensity8MS$SchedulerToAgentMessages + workDensity8MS$AgentToSchedulerMessages + workDensity8MS$SchedulerToSchedulerMessages

workDensity16IS$SchedulerToSchedulerMessages <- 0
workDensity16IS$AgentToSchedulerMessages <- 0
workDensity16IS$SchedulerToAgentMessages <- 0
workDensity16IS$AgentToAgentMessages <- workDensity16IS$SlotReservedNotification
workDensity16IS$TotalMessagesSent <- workDensity16IS$AgentToAgentMessages + workDensity16IS$SchedulerToAgentMessages + workDensity16IS$AgentToSchedulerMessages + workDensity16IS$SchedulerToSchedulerMessages

workDensity16RP$SchedulerToSchedulerMessages <- workDensity16RP$SchedulerSlotAnswerMail +workDensity16RP$SchedulerSlotRequestMail +workDensity16RP$SchedulerSlotAck
workDensity16RP$AgentToSchedulerMessages <- workDensity16RP$SlotRequestMail
workDensity16RP$SchedulerToAgentMessages <- workDensity16RP$SlotReservedMail
workDensity16RP$AgentToAgentMessages <- 0
workDensity16RP$TotalMessagesSent <- workDensity16RP$AgentToAgentMessages + workDensity16RP$SchedulerToAgentMessages + workDensity16RP$AgentToSchedulerMessages + workDensity16RP$SchedulerToSchedulerMessages

workDensity16MS$SchedulerToSchedulerMessages <- 0
workDensity16MS$AgentToSchedulerMessages <- workDensity16MS$SlotRequestMail
workDensity16MS$SchedulerToAgentMessages <- workDensity16MS$SlotReservedMail
workDensity16MS$AgentToAgentMessages <- 0
workDensity16MS$TotalMessagesSent <- workDensity16MS$AgentToAgentMessages + workDensity16MS$SchedulerToAgentMessages + workDensity16MS$AgentToSchedulerMessages + workDensity16MS$SchedulerToSchedulerMessages

workDensity24IS$SchedulerToSchedulerMessages <- 0
workDensity24IS$AgentToSchedulerMessages <- 0
workDensity24IS$SchedulerToAgentMessages <- 0
workDensity24IS$AgentToAgentMessages <- workDensity24IS$SlotReservedNotification
workDensity24IS$TotalMessagesSent <- workDensity24IS$AgentToAgentMessages + workDensity24IS$SchedulerToAgentMessages + workDensity24IS$AgentToSchedulerMessages + workDensity24IS$SchedulerToSchedulerMessages

workDensity24RP$SchedulerToSchedulerMessages <- workDensity24RP$SchedulerSlotAnswerMail +workDensity24RP$SchedulerSlotRequestMail +workDensity24RP$SchedulerSlotAck
workDensity24RP$AgentToSchedulerMessages <- workDensity24RP$SlotRequestMail
workDensity24RP$SchedulerToAgentMessages <- workDensity24RP$SlotReservedMail
workDensity24RP$AgentToAgentMessages <- 0
workDensity24RP$TotalMessagesSent <- workDensity24RP$AgentToAgentMessages + workDensity24RP$SchedulerToAgentMessages + workDensity24RP$AgentToSchedulerMessages + workDensity24RP$SchedulerToSchedulerMessages

workDensity24MS$SchedulerToSchedulerMessages <- 0
workDensity24MS$AgentToSchedulerMessages <- workDensity24MS$SlotRequestMail
workDensity24MS$SchedulerToAgentMessages <- workDensity24MS$SlotReservedMail
workDensity24MS$AgentToAgentMessages <- 0
workDensity24MS$TotalMessagesSent <- workDensity24MS$AgentToAgentMessages + workDensity24MS$SchedulerToAgentMessages + workDensity24MS$AgentToSchedulerMessages + workDensity24MS$SchedulerToSchedulerMessages

pdf(file = "TotalMessages plot", width = 10)
boxplot(clumps10MS$TotalMessagesSent, clumps10RP$TotalMessagesSent, clumps10IS$TotalMessagesSent,
        clumps20MS$TotalMessagesSent, clumps20RP$TotalMessagesSent, clumps20IS$TotalMessagesSent,
        clumps30MS$TotalMessagesSent, clumps30RP$TotalMessagesSent, clumps30IS$TotalMessagesSent
        ,names = c("MS 10", "RP 10", "IS 10",
                   "MS 20", "RP 20", "IS 20",
                   "MS 30", "RP 30", "IS 30")
        , main = "The total number of messages sent on the clumps map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(ring16MS$TotalMessagesSent, ring16RP$TotalMessagesSent, ring16IS$TotalMessagesSent,
        ring24MS$TotalMessagesSent, ring24RP$TotalMessagesSent, ring24IS$TotalMessagesSent,
        ring32MS$TotalMessagesSent, ring32RP$TotalMessagesSent, ring32IS$TotalMessagesSent
        ,names = c("MS 16", "RP 16", "IS 16",
                   "MS 24", "RP 24", "IS 24",
                   "MS 32", "RP 32", "IS 32")
        , main = "The total number of messages sent on the ring map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(scattered15MS$TotalMessagesSent, scattered15RP$TotalMessagesSent, scattered15IS$TotalMessagesSent,
        scattered20MS$TotalMessagesSent, scattered20RP$TotalMessagesSent, scattered20IS$TotalMessagesSent,
        scattered25MS$TotalMessagesSent, scattered25RP$TotalMessagesSent, scattered25IS$TotalMessagesSent
        ,names = c("MS 15", "RP 15", "IS 15",
                   "MS 20", "RP 20", "IS 20",
                   "MS 25", "RP 25", "IS 25")
        , main = "The total number of messages sent on the scattered map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)

boxplot(workDensity8MS$TotalMessagesSent, workDensity8RP$TotalMessagesSent, workDensity8IS$TotalMessagesSent,
        workDensity16MS$TotalMessagesSent, workDensity16RP$TotalMessagesSent, workDensity16IS$TotalMessagesSent,
        workDensity24MS$TotalMessagesSent, workDensity24RP$TotalMessagesSent, workDensity24IS$TotalMessagesSent
        ,names = c("MS 8", "RP 8", "IS 8",
                   "MS 16", "RP 16", "IS 16",
                   "MS 24", "RP 24", "IS 24")
        , main = "The total number of messages sent on the workDensity map"
        , xlab = "The instantiated pattern and the number of agents present in the map"
        , las = 1)
dev.off()
